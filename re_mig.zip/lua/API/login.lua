local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")

ngx.req.read_body()
local res,reqerr= ngx.req.get_post_args()
if  res == nil then
  ngx.say("err:", reqerr)
end
local userName = ""
local passWord = ""
for k,v in pairs(res) do
	k = cjson.decode(k)
	userName = k.userName
	passWord = k.passWord
end
--core.log.info("userName:",userName)
--core.log.info("passWord:",passWord)

local sql = "select * from t_user where f_uname = '" .. userName .. "' and f_passwd = '" .. passWord .. "'"
local userData = db.selectBySql(sql)
if next(userData) == nil then
	core.response.exit(201, "uname or upass is error")
end
userData = userData[1]
userData.f_passwd = nil
--local createSession = session.setData(core.json.encode(userData[1]),"userData")
local session_key, sserr = session.set(userData)
    if not session_key then
        core.response.exit(500, "failed to save session in shdict: " .. sserr)
        --return 500, {error_msg = "failed to save session in shdict: " .. sserr}
    end
local ck = require "resty.cookie"
local cookie, ckerr = ck:new()
if not cookie then
    core.response.exit(500, "failed to create cookie object: " .. err)
    --return 500, {error_msg = "failed to create cookie object: " .. ckerr}
end

core.log.info("session-key: ", session_key)
local ok, err = cookie:set({
    key = "session_id", 
    value = session_key,
    path = "/", 
    --domain = "localhost", 
    expires = ngx.cookie_time(ngx.time() + 60 * 240),
})
if not ok then
    core.response.exit(500, "failed to generate session id: " .. err)
    --return 500, {error_msg = "failed to generate session id: " .. err}
end

--return 200, {success = true, msg = "login success"}
core.response.exit(200, "success login")