local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")

ngx.req.read_body()
local res,reqerr= ngx.req.get_post_args()
if  res == nil then
  ngx.say("err:", reqerr)
end
local userName = ""
--local eMail = ""
local MD5 = ""
local passWord = ""
for k,v in pairs(res) do
	k = cjson.decode(k)
	userName = k.userName
	--eMail = k.eMail
  MD5 = k.md5
  passWord = k.passWord
end
--core.log.info("userName:",userName)
--core.log.info("passWord:",passWord)

local sql = "select * from t_user where f_uname = '" .. userName .. "' and f_md5 = '" .. MD5 .. "'"
local userData = db.selectBySql(sql)
if next(userData) == nil or userData[1].f_md5 == '' then
	core.response.exit(204, "uname or reset code is error")
end

sql = "update t_user set f_passwd='" .. passWord .. "', f_md5='' where f_uname='" .. userName .. "'"
local res_upd, err_upd = db.selectBySql(sql)
if res_upd == nil then
	core.response.exit(204, "reset password failed")
end

core.response.exit(200, "password reset")