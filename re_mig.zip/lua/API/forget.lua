local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")

ngx.req.read_body()
local res,reqerr= ngx.req.get_post_args()
if  res == nil then
  ngx.say("err:", reqerr)
end
local userName = ""
local eMail = ""
for k,v in pairs(res) do
	k = cjson.decode(k)
	userName = k.userName
	eMail = k.eMail
end
--core.log.info("userName:",userName)
--core.log.info("passWord:",passWord)

local sql = "select * from t_user where f_uname = '" .. userName .. "' and f_email = '" .. eMail .. "'"
local userData = db.selectBySql(sql)
if next(userData) == nil then
	core.response.exit(204, "uname or email is invalid")
end
local MD5 = ngx.md5(os.clock)
--UPDATE user_tbl set name='李四'WHERE name= '张三';
sql = "update t_user set f_md5='" .. MD5 .. "' where f_uname='" .. userName .. "'"
local res_upd, err_upd = db.selectBySql(sql)
if res_upd == nil then
	core.response.exit(204, "url is timeout")
end
local headers_tab = ngx.req.get_headers()
--send Email to user for reseting

---[[
local mail = require "resty.mail"

local mailer, err_mail = mail.new({
  host = "smtp.qiye.aliyun.com",
  domain = "chinasofttech.com",
  port = 465,
  ssl = true,
  starttls = false,
  auth_type = "login",
  username = "support@chinasofttech.com",
  password = "Ytk123456",
})
if err_mail then
  core.log.info("mail.new error: ", err_mail)
  core.response.exit(204, ngx.HTTP_INTERNAL_SERVER_ERROR)
  --return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end

local send_ok, send_err = mailer:send({
  from = "User_Support<support@chinasofttech.com>",
  to = { userData[1].f_email },
  --cc = { "leo@example.com", "Raphael <raph@example.com>", "donatello@example.com" },
  subject = "[Support] Use this link to reset password",
  text = headers_tab.origin .. "/resetPW.html?code=" .. MD5,
  --html = "<h1>.</h1>",
})
--]]
-----------------------------------------
--[[
--local config = require("config")
local smtp = require("resty.smtp")
local mime = require("resty.smtp.mime")
local ltn12 = require("resty.smtp.ltn12")

-- ...
-- Suppose your mail data in table `args` and default settings
-- in table `config.mail`
-- ...
local args = {
  from="yetk@chinasofttech.com",
  user="yetk@chinasofttech.com",
  password="Ok112233",
  server="smtp.qiye.aliyun.com",
  --domain="mail.chinasofttech.com",
  subject="Support - Use this link to reset password",
  body = headers_tab.origin .. "/resetPW.html?id=" .. userName .. "&code=" .. MD5,
  }
local config = {}
core.log.info(args.body)
local rcpts = {
    userData[1].f_email,
  }
local mesgt = {
    headers= {
        subject= mime.ew(args.subject or config.mail.SUBJECT, nil,
                         { charset= "utf-8" }),
        ["content-transfer-encoding"]= "BASE64",
        ["content-type"]= "text/plain;charset='utf-8'",
    },
    --body= mime.b64(args.body),
    body= mime.qp("hello cloud"),
}

local ret, send_err = smtp.send {
    from= args.from or config.mail.FROM,
    rcpt= rcpts,
    user= args.user or config.mail.USER,
    password= args.password or config.mail.PASSWORD,
    server= args.server or config.mail.SERVER,
    port=465,
    ssl = { enable= true, verify_cert= false },
    --domain= args.domain or config.mail.DOMAIN,
    --create= socket.tcp,
    source= smtp.message(mesgt),
}

--------------------------------------------------
--]]
if send_err then
  core.log.info("smtp:send error: ", send_err)
  core.response.exit(204, ngx.HTTP_INTERNAL_SERVER_ERROR)
  --return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end

core.response.exit(200, "reset url generated")