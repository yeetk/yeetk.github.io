local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")

local ok, err = session.check()
if not ok then
    core.response.exit(401, err)
end
local getSession = session.getData("userData")
local userId = getSession.f_id
local iSql = "select d.f_authid,d.f_authname,d.f_authurl,d.f_requestmethod,d.f_desc from t_user as a left join t_user_role as b on a.f_id = b.f_user_id left join t_role_auth as c on b.f_role_id = c.f_role_id left join t_auth as d on c.f_auth_id = d.f_authid where a.f_id = '" .. userId .. "';"
local authData = db.selectBySql(iSql)

local result = {}
if next(authData) ~= nil then
  result.auth = authData
else
  core.response.exit(204, "no data")
end
iSql = "select u.f_company, co.f_shortname, co.f_href, co.f_logosrc from t_user as u inner join t_cfg_coinf as co on u.f_company = co.f_company where u.f_id = '" .. userId .. "';"
local coinfo = db.selectBySql(iSql)
if next(coinfo) ~= nil then
  result.coInfo = coinfo[1]
end

core.response.exit(200, core.json.encode(result))