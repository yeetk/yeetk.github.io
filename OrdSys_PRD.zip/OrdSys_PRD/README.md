# OrdSys

```shell
$ make
Makefile rules:

    init:         System Initialization
    run:          Start service
    stop:         Stop service
    reload:       Reload service
    deps:         Installation dependencies
    help:         Show Makefile rules
```
