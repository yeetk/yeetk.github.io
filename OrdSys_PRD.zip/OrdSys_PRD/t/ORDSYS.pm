package t::ORDSYS;

use lib 'lib';
use Cwd qw(cwd);
use Test::Nginx::Socket::Lua::Stream -Base;

repeat_each(1);
log_level('info');
no_long_string();
no_shuffle();
worker_connections(128);

my $pwd = cwd();

sub read_file($) {
    my $infile = shift;
    open my $in, $infile
        or die "cannot open $infile for reading: $!";
    my $cert = do { local $/; <$in> };
    close $in;
    $cert;
}

my $yaml_config = read_file("conf/config.yaml");


add_block_preprocessor(sub {
    my ($block) = @_;

    my $main_config = $block->main_config // <<_EOC_;
worker_rlimit_core  500M;
working_directory   $pwd;
_EOC_

    $block->set_value("main_config", $main_config);

    my $init_by_lua_block = $block->init_by_lua_block // <<_EOC_;
    require "resty.core"
    ordsys = require("ordsys")
_EOC_

    my $login_role = $block->login_role;
    if ($login_role && $login_role eq "admin") {
        $init_by_lua_block .= <<_EOC_;

    local session = require("admin.session")
    session.set({f_id = 1, f_uname = "admin", f_group = "admin", f_fullname = "fullname", f_language = "zh"}, "session_admin")
_EOC_
    }

    my $http_config = $block->http_config // '';
    $http_config .= <<_EOC_;
    lua_package_path "$pwd/deps/share/lua/5.1/?.lua;$pwd/deps/share/lua/5.1/?/init.lua;$pwd/lua/?.lua;$pwd/t/?.lua;/usr/share/lua/5.1/?.lua;;";
    lua_package_cpath "$pwd/deps/lib/lua/5.1/?.so;$pwd/deps/lib64/lua/5.1/?.so;/usr/lib64/lua/5.1/?.so;;";

    lua_shared_dict session 32m;

    resolver 8.8.8.8 114.114.114.114 ipv6=off;
    resolver_timeout 5;
    lua_socket_log_errors off;

    init_by_lua_block {
        $init_by_lua_block
    }

    init_worker_by_lua_block {
        ordsys.init_worker()
    }
_EOC_

    $block->set_value("http_config", $http_config);

    my $config = $block->config // '';
    $config .= <<_EOC_;
    location /ordsys/admin/ {
        content_by_lua_block {
            ordsys.http_admin()
        }
    }
_EOC_

    $block->set_value("config", $config);

    my $user_yaml_config = $block->yaml_config // $yaml_config;
    my $user_files = $block->user_files;
    $user_files .= <<_EOC_;
>>> ../conf/config.yaml
$user_yaml_config
_EOC_

    $block->set_value("user_files", $user_files);

    $block;
});

1;
