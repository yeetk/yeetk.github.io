local pgmoon = require("pgmoon")
local config = require("apisix.core.config_local")

local _M = {
    version = 0.1,
    quote_pgsql_str = ndk.set_var.set_quote_pgsql_str,
}


function _M.query(sql)
    local local_conf = config.local_conf()
    local db = local_conf.db

    local pg, err = pgmoon.new({
        host = db.ip,
        port = db.port,
        database = db.database,
        user = db.username,
        password = db.password,
      })
    if not pg then
        return nil, err
    end

    local ok, err = pg:connect()
    if not ok then
        return nil, err
    end

    local res, err = pg:query(sql)
    if not res then
        return nil, err
    end

    pg:keepalive()

    return res, err
end


return _M
