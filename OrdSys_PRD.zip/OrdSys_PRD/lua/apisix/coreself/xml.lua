local load = require("xml").load
local pcall = pcall


local _M = {}

function _M.load(str)
    local ok, res = pcall(load, str)
    if not ok then
        return nil, res
    end

    return res
end


return _M
