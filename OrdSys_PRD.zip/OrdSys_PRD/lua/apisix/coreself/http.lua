local apisix_http = require("apisix.core.http")
local http = require("resty.http")
local log = require("apisix.core.log")


local _M = {
    version = 0.1,
    request_self = apisix_http.request_self,
}


function _M.request_uri(...)
    -- log.error(require("cjson").encode({...}))
    local httpc = http.new()
    local res, err = httpc:request_uri(...)
    return res, err
end


return _M
