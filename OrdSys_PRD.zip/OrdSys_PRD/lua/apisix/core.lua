local log = require("apisix.core.log")

return {
    version  = require("apisix.core.version"),
    config   = require("apisix.core.config_local"),
    log      = log,
    json     = require("apisix.core.json"),
    table    = require("apisix.core.table"),
    request  = require("apisix.core.request"),
    response = require("apisix.core.response"),
    lrucache = require("apisix.core.lrucache"),
    ctx      = require("apisix.core.ctx"),
    timer    = require("apisix.core.timer"),
    utils    = require("apisix.core.utils"),
    http     = require("apisix.coreself.http"),
    tablepool= require("tablepool"),
    pg       = require("apisix.coreself.pghelper"),
    xml      = require("apisix.coreself.xml"),
}
