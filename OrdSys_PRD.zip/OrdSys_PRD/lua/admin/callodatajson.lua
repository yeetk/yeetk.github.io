local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local cjson = require("cjson")

local _M = {version = 0.1}


function _M.post(api_name, conf, segs)

    local user_config = core.config.local_conf().user_config
    
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    
    local sql = "select f_group from t_user where f_id = " .. pgsql_str(session_val.f_id)
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end
    if res[1].f_group ~= "admin" then
      
      --read components and cdsview name
      sql = "select * from t_comp_cds where f_callodata = '" .. api_name .. "'"
      --sql = "select * from t_role_value where f_role_id = any(array(select f_role_id from t_user_role where (CURRENT_DATE between f_from and f_to) and f_user_id = " .. pgsql_str(session_val.f_id) .. "))"
    	local compres, err = core.pg.query(sql)
    	if compres then
    	--if have records in t_comp_cds, then run authorization check
          --read role components values
        sql = "select * from t_role_value where f_role_id = any(array(select f_role_id from t_user_role where (CURRENT_DATE between f_from and f_to) and f_user_id = " .. pgsql_str(session_val.f_id) .. "))"
        local roleres, err = core.pg.query(sql)
        if not roleres then
            return 500, {errmsg = err}
        end
        
        --call cdsview to read components master data
        for i, item in ipairs(compres) do
            if conf[item.f_component] and (item.f_cds_view ~= item.f_callodata) then
              local condition = "?$format=json&$filter="
              condition = condition .. item.f_field .. "%20eq%20'" .. conf[item.f_component] .. "'"
              local uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. item.f_cds_view .. "/" .. item.f_cds_entity .. condition
              --local uri = "https://my300054-api.saps4hanacloud.cn/sap/opu/odata/sap/API_SALES_ORDER_SRV/?$format=json"
              core.log.info("uri: ", uri)
              local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
              local cdsres, err = core.http.request_uri(uri, {
                  method = "GET",
                  headers = {
                      ["Authorization"] = "Basic " .. basic_auth,
                      ["Accept"] = "application/json",
                      --["content-type"] = "application/json",
                  },
                  ssl_verify = false,
              })

              if not cdsres then
                return 500, err
              end

              if cdsres.status >= 300 then
                core.log.info("Error Code from CDS call:",cdsres.status)
                return cdsres.status, cdsres.body
              end
              
              
              local iAuth = 0
              --core.log.info("cdsres body:",cdsres.body)
              for j, v in ipairs(core.json.decode(cdsres.body).d.results) do
                for k, rolerow in ipairs(roleres) do
                  --core.log.info("results:",j,"~,roleres:",k,"~,:rolerow's value",rolerow.f_values[1].value,'~,cds-results[rolerow.f_values[1].field]:',v[rolerow.f_values[1].field])
                  --core.log.info(core.json.decode(rolerow.f_values)[1].field)
                  --core.log.info(rolerow.f_values[1].field)
                  if v[rolerow.f_values[1].field] then
                    if string.find(rolerow.f_values[1].value,v[rolerow.f_values[1].field]) then
                      iAuth = iAuth + 1
                    end
                  end
                end
              end
              if iAuth == 0 then
                return 200, {msg="No Authorization"}
              end
            end --of if
        end --of for
      end
      
    
      
      
    end --of if




    local user_config = core.config.local_conf().user_config
    local sub_path = table.concat(segs, "/")
    local args = ngx.req.get_uri_args() or {}
    
    --local uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. api_name .. "/" .. sub_path
    local uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. api_name .. "/" .. "?$format=json"
    --local uri = "https://my300054-api.saps4hanacloud.cn/sap/opu/odata/sap/API_SALES_ORDER_SRV/?$format=json"
    --core.log.info("uri: ", uri)
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Accept"] = "application/json",
            ["X-CSRF-Token"] = "fetch",
        },
        ssl_verify = false,
    })

    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end

    --core.log.info("fetch res: ", res.body)
    -- todo: 根据管理员类型，做数据过滤

    local uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. api_name .. "/" .. sub_path
    --local uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. api_name .. "/" .. sub_path .. "?" .. ngx.encode_args(args)
    local token = res.headers["X-CSRF-Token"]
    --core.log.info(res.headers["X-CSRF-Token"])
    --local setcookie = core.json.encode(res.headers["set-cookie"][2])
    local setcookie = res.headers["set-cookie"][2]
    --core.log.info(setcookie)

    --core.log.info(token)
    --core.log.info(uri)
    --core.log.info(cjson.encode_sparse_array(conf))
    --cjson.encode_empty_table_as_object(false)
    
    --core.log.info(cjson.encode(conf))
    
    ngx.req.read_body()
    local req_body = ngx.req.get_body_data()
    
    local res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Content-Type"] = "application/json;odata=verbose",
            ["Accept"] = "application/json",
            --["DataServiceVersion"] = "2.0",
            ["X-CSRF-Token"] = token,
            ["Cookie"] = setcookie,
            ["set-cookie"] = setcookie,
        },
        --body = core.json.encode(conf),
        body = cjson.encode(conf),
        body = req_body,
        ssl_verify = false,
    })
    
    --core.log.info(core.json.encode(res.headers))
    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end

    --core.log.info("res: ", res.body)

    return 200, res.body
end

function _M.options()
    return 204
end

return _M
