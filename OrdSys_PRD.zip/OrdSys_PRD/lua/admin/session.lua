local core = require("apisix.core")
local ngx = ngx
local session = ngx.shared.session


local _M = {version = 0.1}



function _M.setData(vals, key)
    local ms5_key = ngx.md5(vals)
    local ok, err = session:set(md5_key, vals, 60 * 240)
    if not ok then
        return false, err		
    end
    return key
end

function _M.getData(key)
    --local session_id = ngx.ctx.var.cookie_session_id
    core.ctx.set_vars_meta(ngx.ctx)
    return _M.get()
end


function _M.set(vals, key)
    if type(vals) ~= "table" then
        return false, "invalid arguments"
    end

    local session_vals = {}
    for _, name in ipairs({"f_id", "f_uname", "f_group", "f_fullname", "f_email", "f_company", "f_sap_format", "f_sap_client", "f_sap_url",
                            "f_language"}) do
        session_vals[name] = vals[name]
    end

    local sess_val = core.json.encode(session_vals)
    key = key or ngx.md5(sess_val)

    local ok, err = session:set(key, sess_val, 60 * 240)
    if not ok then
        return false, err
    end

    return key
end


function _M.check()
    core.ctx.set_vars_meta(ngx.ctx)
    local session_id = ngx.ctx.var.cookie_session_id

    if type(session_id) ~= "string" then
        return false, "invalid session key"
    end

    local val, err = session:get(session_id)
    if not val then
        return false, err .. "missing invalid session"
    end

    val = core.json.decode(val)

    _M.set(val, session_id)

    return true
end


function _M.get()
    core.ctx.set_vars_meta(ngx.ctx)
    local session_id = ngx.ctx.var.cookie_session_id

    if type(session_id) ~= "string" then
        return false, "invalid session key"
    end

    local val, err = session:get(session_id)
    if not val then
        return false, err .. "missing invalid session"
    end

    val = core.json.decode(val)

    --_M.set(val, session_id)

    return val
end


return _M
