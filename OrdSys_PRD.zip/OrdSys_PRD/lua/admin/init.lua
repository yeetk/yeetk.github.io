local core = require("apisix.core")
local route = require("resty.radixtree")
local session = require("admin.session")
local get_method = ngx.req.get_method
local str_lower = string.lower
local require = require
local ngx = ngx
local ngx_re = require "ngx.re"


local admin_rights = {
    user = true,
}


local _M = {version = 0.2}
local router


local function run()
    core.ctx.set_vars_meta(ngx.ctx)
			  
    local uri_segs = core.utils.split_uri(ngx.var.uri)
    
    -- /ordsys/admin/callodata/api_name
    local seg_res, seg_id = uri_segs[4], uri_segs[5]
    local ok, resource = pcall(require, "admin." .. seg_res)
	
    
    if not ok then
        core.log.info("init.lua ~ Line:29 ", resource)
        --core.response.exit(404)
    end
    

    local method = str_lower(get_method())
--	core.log.info("method:",method)
    if not resource[method] then
        core.log.info("init.lua ~ Line:35 ", method)
        --core.response.exit(404)
    end
    
	--获取访问的url	  	  
	  local headers_tab = ngx.req.get_headers()
    --分割字符串
      local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
    --拿到最后一部分  
      local myurl = split_res[table.maxn(split_res)] 
    --  core.log.info("myurl:",myurl)	  
    --check session for all user
    if seg_res ~= "user_login" and seg_res ~= "odata" and seg_res ~= "createtable" and seg_res ~= "hello" then	  
      --将url存入session
      local res = session.seturl(myurl,"url")   
      local ok, err = session.check()	  	 
      if not ok then
          core.response.exit(401, err)
      end
    end
  
    --check session for administrator
    if admin_rights[seg_res] then
        local session_val, err = session.get()
        if session_val.f_group ~= "admin" then
            core.response.exit(403, "No Administrator's Rights")
        end
    end

    ngx.req.read_body()
    local req_body = ngx.req.get_body_data()
    local req_head = ngx.req.get_headers()
    --core.log.info(core.json.encode(req_head))
    if req_body and req_head["content-type"] == "application/json" then
        local data, err = core.json.decode(req_body)
        if not data then
            core.log.error("invalid request body: ", req_body, " err: ", err)
            core.response.exit(400, {error_msg = "invalid request body",
                                     req_body = req_body})
        end
        req_body = data
    end

    local segs = {}
    for i = 6, #uri_segs do
        segs[i - 5] = uri_segs[i]
    end

    local code, data = resource[method](seg_id, req_body, segs)
    if code then
        core.response.exit(code, data)
    end
	
end


local uri_route = {
    {
        paths = [[/ordsys/admin/*]],
        methods = {"GET", "PUT", "POST", "DELETE", "PATCH","OPTIONS"},
        handler = run,
    },
}


function _M.init_worker()
    router = route.new(uri_route)
end


function _M.get()
    return router
end

function _M.post()
    return router
end


return _M
