--������������ݿ�����ƣ���ѯ�����������Լ����ȣ��ֶ�����
local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str

local _M = {version = 0.1}
function _M.post(api_name, conf, segs)
end
function _M.get(api_name, conf, segs)
--��ѯ���������ֶκ�����
local sql_table = conf.tableName 
core.log.info("tablename:":sql_table)

 --��ѯ���ṹ������is_nullable���Ƿ�������ֵ��": 0,"data_type": "date", "length": -1,"ordinal_position(�������)": 1,"column_name": "mdate","is_pk": 1
local sql = "SELECT A.ordinal_position,A.column_name,CASE A.is_nullable WHEN 'NO' THEN 0 ELSE 1 END AS is_nullable,A.data_type,coalesce(A.character_maximum_length, A.numeric_precision, -1) as length,A.numeric_scale,CASE WHEN length(B.attname) > 0 THEN 1 ELSE 0 END AS is_pk FROM information_schema.columns A LEFT JOIN (SELECT pg_attribute.attname FROM pg_index,pg_class,pg_attribute WHERE pg_class.oid = '" .. sql_table .. "' :: regclass AND pg_index.indrelid = pg_class.oid AND pg_attribute.attrelid = pg_class.oid AND pg_attribute.attnum = ANY (pg_index.indkey)) B ON A.column_name = b.attname WHERE A.table_schema = 'public' AND A.table_name = '" .. sql_table .. "' ORDER BY ordinal_position ASC;"	

local function selectdata(sql)
local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
     ngx.say("error: ", err)
  end 
  local res, err = pg:query(sql) 
  if not res then
      ngx.say("error: ", err)
  end 
   pg:keepalive()    
  return res
end
local ret = selectdata(sql)
local msg = "�ñ�������"
if next(ret) ~= nil then
core.response.exit(200, core.json.encode(ret))
else
core.response.exit(200, core.json.encode(msg))
end

end
return _M










