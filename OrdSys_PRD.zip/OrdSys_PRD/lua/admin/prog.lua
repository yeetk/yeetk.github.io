local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str

local _M = {version = 0.1}


function _M.get(typ, conf, segs)
    if typ ~= "name" then
        return 400, {errmsg = "invalid request path"}
    end

    --read session data
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    
    local result = {}
    
    --read user data
    local sql = "select f_uname,f_full_name,f_email from t_user where f_id = " .. pgsql_str(session_val.f_id)
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end
    result.user = res

    
    local name = segs[1]
    sql = "select * from t_prog where f_prog = " .. pgsql_str(name)
    res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end

    result.prog = res

    local prog_id = res[1].f_id
    sql = "select * from t_screen where f_prog_id = " .. pgsql_str(prog_id) .. " ORDER BY f_screen_id"
    res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end

    result.t_screen = res

    sql = "select t_prog_section.f_screen_id, t_prog_section.f_section_id, t_prog_section.f_section_sorter, t_section.f_section, t_section.f_section_title, t_section.f_section_type from t_prog_section LEFT OUTER JOIN t_section ON t_prog_section.f_section_id = t_section.f_section_id where t_prog_section.f_prog_id = " .. pgsql_str(prog_id) .. " ORDER BY t_prog_section.f_screen_id, t_prog_section.f_section_sorter"
    res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end

    result.t_prog_section = res

   -- local section_id = res[1].f_section_id
    sql = "select * from t_section where f_section_id = any(array(select f_section_id from t_prog_section where f_prog_id = " .. pgsql_str(prog_id) .. ")) ORDER BY f_section_id"
    res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end

    result.t_section = res

    sql = "select * from t_section_field where f_section_id = any(array(select f_section_id from t_prog_section where f_prog_id = " .. pgsql_str(prog_id)  .. ")) ORDER BY f_section_id, f_row, f_cell"
    res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end

    result.t_section_field = res

    return 200, result
end


return _M
