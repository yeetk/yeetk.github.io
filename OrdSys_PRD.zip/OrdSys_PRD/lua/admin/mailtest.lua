--[[
local mail = require "resty.mail"

local mailer, err = mail.new({
  host = "mail.chinasofttech.com",
  port = 587,
  --starttls = true,
  username = "yetk",
  password = "Szhr@20191919",
})
if err then
  ngx.log(ngx.ERR, "mail.new error: ", err)
  return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end

local ok, err = mailer:send({
  from = "Tingkai Ye <yetk@chinasofttech.com>",
  to = { "yetk@msn.com" },
  cc = { "libero@yeah.net", "Libero <libero@sina.com>"},
  subject = "test Lua smtp client!",
  text = "There's text in the Content.",
  html = "<h1>There's link in the body.</h1>",
  
  attachments = {
  
  {
      filename = "toppings.txt",
      content_type = "text/plain",
      content = "1. Cheese\n2. Pepperoni",
    },
  
  },

})
if err then
  ngx.log(ngx.ERR, "mailer:send error: ", err)
  return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end
]]

--local config = require("config")
local smtp = require("resty.smtp")
local mime = require("resty.smtp.mime")
local ltn12 = require("resty.smtp.ltn12")

-- ...
-- Suppose your mail data in table `args` and default settings
-- in table `config.mail`
-- ...
local args = {
  from="yetk@chinasofttech.com",
  user="yetk",
  password="Szhr@20191919",
  server="mail.chinasofttech.com",
  --domain="mail.chinasofttech.com",
  subject="Test title",
  body="text body"
  }
local config = {}
local rcpts = {
    "<9995202@qq.com>",
  }
local mesgt = {
    headers= {
        subject= mime.ew(args.subject or config.mail.SUBJECT, nil,
                         { charset= "utf-8" }),
        ["content-transfer-encoding"]= "BASE64",
        ["content-type"]= "text/plain; charset='utf-8'",
    },

    body= mime.b64(args.body)
}

local ret, err = smtp.send {
    from= args.from or config.mail.FROM,
    rcpt= rcpts,
    user= args.user or config.mail.USER,
    password= args.password or config.mail.PASSWORD,
    server= args.server or config.mail.SERVER,
    port=587,
    --domain= args.domain or config.mail.DOMAIN,
    source= smtp.message(mesgt),
}
if err then
  ngx.log(ngx.ERR, "smtp:send error: ", err)
  return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end
ngx.say(ret)