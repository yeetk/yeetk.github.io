local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str

local _M = {version = 0.1}


function _M.post(api_name, conf, segs)

    local user_config = core.config.local_conf().user_config
    
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    
    local sql = "select f_group from t_user where f_id = " .. pgsql_str(session_val.f_id)
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end
    
    local user_config = core.config.local_conf().user_config
    local sub_path = table.concat(segs, "/")
    local args = ngx.req.get_uri_args() or {}
    
    ngx.req.read_body()
    local req_body = ngx.req.get_body_data()
    --SOAP URI /sap/bc/srt/scs_ext/sap/ecc_outbounddeliverycwrrc?sap-client=100
    local uri = user_config.home_uri .. "/sap/bc/srt/scs_ext/sap/" .. api_name .. "?" .. "sap-client=100"
    core.log.info("uri: ", uri)
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["content-type"] = "text/xml",
            ["Accept"] = "text/xml",
            --["X-CSRF-Token"] = "fetch",
        },
        body = req_body,
        ssl_verify = false,
    })

    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end

    core.log.info("res: ", res.body)

    return 200, res.body
end

function _M.options()
    return 204
end

return _M
