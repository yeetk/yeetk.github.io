local core = require("apisix.core")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"

local _M = {version = 0.1}

--
function _M.post(api_name, conf, segs)
    if type(api_name) ~= "string" then
        return 204, {errmsg = "missing API name"}
    end
    
    --read session data
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    
    --initial uri variable
    local user_config = core.config.local_conf().user_config
    local sub_path = table.concat(segs, "/")
    local args = ngx.req.get_uri_args() or {}
    
    --read components for cdsview
    local sql = "select * from t_comp_cds where f_callodata = '" .. api_name .. "' and f_cds_entity = '" .. sub_path .. "'"
    
    local compres, err = core.pg.query(sql)
    if not compres then
        return 500, {errmsg = err}
    end
    
    --read role components values
    sql = "select * from t_role_value where f_role_id = any(array(select f_role_id from t_user_role where (CURRENT_DATE between f_from and f_to) and f_user_id = " .. pgsql_str(session_val.f_id) .. "))"
    local roleres, err = core.pg.query(sql)
    if not roleres then
        return 500, {errmsg = err}
    end
    
    --read authorization check CDS view
    if conf[compres[1].f_component] then
      local condition = "?$format=json&$filter="
      condition = condition .. compres[1].f_field .. "%20eq%20'" .. conf[compres[1].f_component] .. "'"
      local uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. compres[1].f_cds_view .. "/" .. compres[1].f_cds_entity .. condition
      --local uri = "https://my300054-api.saps4hanacloud.cn/sap/opu/odata/sap/API_SALES_ORDER_SRV/?$format=json"
      core.log.info("uri: ", uri)
      local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
      local cdsres, err = core.http.request_uri(uri, {
          method = "GET",
          headers = {
              ["Authorization"] = "Basic " .. basic_auth,
              ["Accept"] = "application/xml",
              --["content-type"] = "application/json",
          },
          ssl_verify = false,
      })

      if not cdsres then
        return 500, err
      end

      if cdsres.status >= 300 then
        core.log.info("Error Code from CDS call:",cdsres.status)
        return cdsres.status, cdsres.body
      end
      
      local iAuth = 0
      core.log.info("cdsres body:",cdsres.body)
      for j, v in ipairs(core.json.decode(cdsres.body).d.results) do
        for k, rolerow in ipairs(roleres) do
          --core.log.info("results:",j,"~,roleres:",k,"~,:rolerow's value",rolerow.f_values.value,'~,cds-results[rolerow.f_values.field]:',v[rolerow.f_values.field])
          --core.log.info(core.json.decode(rolerow.f_values)[1].field)
          --core.log.info(rolerow.f_values[1].field)
          if v[rolerow.f_values[1].field] then
            if string.find(rolerow.f_values[1].value,v[rolerow.f_values[1].field]) then
              iAuth = iAuth + 1
            end
          end
        end
      end
      if iAuth == 0 then
        return 204, {msg="No Authorization"}
      end
    
    end --of if L41
    
    --(read CDS View data) or (get data from request body)
    local uri = user_config.home_uri .. "/sap/opu/odata/sap/YY1_SALESORDERITEM_ALL_CDS/YY1_SalesOrderItem_All?$format=json&$filter=SalesDocument eq '" .. conf["SalesDocument"] .. "'"
    --core.log.info("uri: ", uri)
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local order_res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Accept"] = "application/json",
            ["X-CSRF-Token"] = "fetch",
            --["content-type"] = "application/json",
        },
        ssl_verify = false,
    })

    if not cdsres then
      return 500, err
    end

    if cdsres.status >= 300 then
      core.log.info("Error Code from CDS call:",cdsres.status)
      return cdsres.status, cdsres.body
    end
    
    local token = res.headers["X-CSRF-Token"]
    
    --read DB table fields
    sql = "SELECT attname,typname,attnum FROM pg_class c,pg_attribute attr WHERE relname  = 't_yy1_salesorderitem_all_cds' AND c.oid = attr.attrelid"
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {errmsg = err}
    end
    
    --insert data to table: t_yy1_salesorderitem_all_cds
    local isql = new_tab(5,0)
    local subsql = new_tab(6,0)
    local towone = new_tab(2,0)--for concat tow string
    local threeone = new_tab(3,0)-- fpr concat three string
    local reslength = #res
    local cdsreslength = #core.json.decode(cdsres.body).d.results
    for j, v in ipairs(core.json.decode(cdsres.body).d.results) do
      isql[1] = "INSERT INTO t_yy1_salesorderitem_all_cds ("
      isql[2] = "f_action,f_odata,f_entity,"
      subsql[1] = "('delete','YY1_SALESORDERITEM_ALL_CDS','YY1_SalesOrderItem_All',"
      for k, row in ipairs(res) do
        --core.log.info("results:",j,"~,roleres:",k,"~,:rolerow's value",rolerow.f_values.value,'~,cds-results[rolerow.f_values.field]:',v[rolerow.f_values.field])
        --core.log.info(core.json.decode(rolerow.f_values)[1].field)
        --core.log.info(rolerow.f_values[1].field)
        towone[1] = isql[2]
        towone[2] = row.attname
        isql[2] = table.concat(towone,"")
        threeone[1] = subsql[2]
        if v[row.attname] then
          threeone[2] = pgsql_str(v[row.attname])
          if k == reslength then
            threeone[3] = ""
          elseif
            threeone[3] = ","
          end
        elseif
          threeone[2] = "''"
          if k == reslength then
            threeone[3] = ""
          elseif
            threeone[3] = ","
        end
        subsql[2] = table.concat(threeone,"")
      end --of for loop on res
      if j == cdsreslength then
        subsql[3] = ")"
      elseif
        subsql[3] = "),"
      end
      
      isql[3] = ") VALUES "
      towone[1] = isql[4]
      towone[2] = table.concat(subsql,"")
      isql[4] = table.concat(towone,"")
      
    end --of for loop on cdsres
    sql = table.concat(isql,"")
    local insres, err = core.pg.query(sql)
    if not insres then
        return 500, {errmsg = err}
    end
    
    --delete Sales Order
    uri = user_config.home_uri .. "/sap/opu/odata/sap/API_SALES_ORDER_SRV/A_SalesOrder('" .. conf["SalesDocument"] .. "')"
    local res, err = core.http.request_uri(uri, {
        method = "DELETE",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Content-Type"] = "application/json;odata=verbose",
            ["Accept"] = "application/json",
            --["DataServiceVersion"] = "2.0",
            ["X-CSRF-Token"] = token,
            --["Cookie"] = setcookie,
            --["set-cookie"] = setcookie,
        },
        --body = core.json.encode(conf),
        --body = cjson.encode(conf),
        --body = req_body,
        ssl_verify = false,
    })
    
    --core.log.info(core.json.encode(res.headers))
    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return 204, res.body
    end

    core.log.info("res: ", res.body)

    return 200, res.body
    
    --send notification Email
end


return _M
