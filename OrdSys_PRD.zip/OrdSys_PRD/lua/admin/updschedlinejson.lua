local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local cjson = require("cjson")
local ffi = require("ffi")

ffi.cdef[[
   int changeSched(int argc, const char** argv);
   int nlsui_main(int argc, const char** argv);
]]
local cfunc = ffi.load('ChangeSchedLinesFFI')


local _M = {version = 0.1}

function _M.post(api_name, conf, segs)

    local user_config = core.config.local_conf().user_config
    
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    --conf[item.f_component]

    local argStr = {conf[SalesOrder], conf[SalesOrderItem], conf[RequestedDeliveryDate]}

    --local arg = ffi.new("const char*[4]", {"0000000726","000010","20200312"})
    local arg = ffi.new("const char*[4]", argStr)

    local ret = cfunc.changeSched(4,arg)
    
    core.log.info("ret: ", ret)
    if not 0 then
        return 204, err
    end
    return 200, "Sales Order:" .. conf[SalesOrder] .. ", item:" .. conf[SalesOrderItem] .. "updated"
end

function _M.options()
    return 204
end

return _M
