local core = require("apisix.core")
--local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"

local _M = {version = 0.1}


function _M.get(api_name, conf, segs)
    local user_config = core.config.local_conf().user_config
    --local sub_path = table.concat(segs, "/")
    --local args = ngx.req.get_uri_args() or {}
    
    --collect uri
    local uri = ""
    --https://my300054-api.saps4hanacloud.cn/sap/opu/odata/sap/API_BUSINESS_PARTNER/A_BusinessPartnerAddress?$format=json&$expand=to_EmailAddress,to_MobilePhoneNumber,to_PhoneNumber
    uri = user_config.home_uri .. "/sap/opu/odata/SAP/API_BUSINESS_PARTNER/A_BusinessPartnerAddress" .. "?" .. ngx.encode_args("$format=json&$expand=to_EmailAddress,to_MobilePhoneNumber,to_PhoneNumber")
    --core.log.info("res_uri: ", uri)
    -- GET request cdsview call
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Accept"] = "application/xml",
        },
        ssl_verify = false,
    })

    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end
    
    --core.log.info("uri: ", uri)
    --core.log.info("res: ", res.body)
    local isql = new_tab(99,0)
    for i, row in ipairs(core.json.decode(res.body).d.results) do
      --insert into t_oms_bpadr (f_sysnr, f_bp, f_addressid, f_uuid, f_carename, f_mobile, f_phone, f_street, f_housenumber, f_country, f_region, f_city, f_streetprefix, f_additionalstreetprefix, f_streetsuffix, f_additionalstreetsuffix) values( 300054, 8800186, 1000000, '', '代收人', '13902900755', '0755-88888888', '街道1', '发货地址', 'CN', 'GD', '深圳', '街道2', '街道3', '街道4', '街道5') ON CONFLICT(f_sysnr, f_addressid) do update set  f_bp=8800186, f_uuid='', f_carename='代收人', f_mobile='13902900755', f_phone='0755-88888888', f_street='街道1', f_housenumber='发货地址', f_country='CN', f_region='GD', f_city='深圳', f_streetprefix='街道2', f_additionalstreetprefix='街道3', f_streetsuffix='街道4', f_additionalstreetsuffix='街道5'
      isql[1] = "insert into t_oms_bpadr (f_sysnr, f_bp, f_addressid, f_uuid, f_carename, f_mobile, f_phone, f_street, f_housenumber, f_country, f_region, f_city, f_streetprefix, f_additionalstreetprefix, f_streetsuffix, f_additionalstreetsuffix) values( "
      isql[2] = "300054"
      isql[3] = ", "
      isql[4] = row.BusinessPartner
      isql[5] = ", "
      isql[6] = row.AddressID
      isql[7] = ", "
      isql[8] = pgsql_str(row.AddressUUID)
      isql[9] = ", "
      isql[10] = pgsql_str(row.CareOfName)
      isql[11] = ", "
      
      if row.to_MobilePhoneNumber.results# > 0 then
        isql[12] = pgsql_str(row.to_MobilePhoneNumber.results[1].PhoneNumber)
        isql[40] = pgsql_str(row.to_MobilePhoneNumber.results[1].PhoneNumber)
      else
        isql[12] = pgsql_str("")
        isql[40] = pgsql_str("")
      end
      
      isql[13] = ", "
      
      if row.to_PhoneNumber.results# > 0 then
        isql[14] = pgsql_str(row.to_PhoneNumber.results[1].PhoneNumber)
        isql[42] = pgsql_str(row.to_PhoneNumber.results[1].PhoneNumber)
      else
        isql[14] = pgsql_str("")
        isql[42] = pgsql_str("")
      end
      isql[15] = ", "
      isql[16] = pgsql_str(row.StreetName)
      isql[17] = ", "
      isql[18] = pgsql_str(row.HouseNumber)
      isql[19] = ", "
      isql[20] = pgsql_str(row.Country)
      isql[21] = ", "
      isql[22] = pgsql_str(row.Region)
      isql[23] = ", "
      isql[24] = pgsql_str(row.CityName)
      isql[25] = ", "
      isql[26] = pgsql_str(row.StreetPrefixName)
      isql[27] = ", "
      isql[28] = pgsql_str(row.AdditionalStreetPrefixName)
      isql[29] = ", "
      isql[30] = pgsql_str(row.StreetSuffixName)
      isql[31] = ", "
      isql[32] = pgsql_str(row.AdditionalStreetSuffixName)
      isql[33] = " ) ON CONFLICT(f_sysnr, f_addressid) do update set f_bp="
      isql[34] = row.BusinessPartner
      isql[35] = ", f_uuid="
      isql[36] = pgsql_str(row.AddressUUID)
      isql[37] = ", f_carename="
      isql[38] = pgsql_str(row.CareOfName)
      isql[39] = ", f_mobile="
      
      isql[41] = ", f_phone="
      isql[42] = pgsql_str(row.to_PhoneNumber.results[1].PhoneNumber)
      isql[43] = ", f_street="
      isql[44] = pgsql_str(row.StreetName)
      isql[45] = ", f_housenumber="
      isql[46] = pgsql_str(row.HouseNumber)
      isql[47] = ", f_country="
      isql[48] = pgsql_str(row.Country)
      isql[49] = ", f_region="
      isql[50] = pgsql_str(row.Region)
      isql[51] = ", f_city="
      isql[52] = pgsql_str(row.CityName)
      isql[53] = ", f_streetprefix="
      isql[54] = pgsql_str(row.StreetPrefixName)
      isql[55] = ", f_additionalstreetprefix="
      isql[56] = pgsql_str(row.AdditionalStreetPrefixName)
      isql[57] = ", f_streetsuffix="
      isql[58] = pgsql_str(row.StreetSuffixName)
      isql[59] = ", f_additionalstreetsuffix="
      isql[60] = pgsql_str(row.AdditionalStreetSuffixName)

      local sql = table.concat(isql,"")
      
      core.log.info("insert sql: ", sql)
      local insres, err = core.pg.query(sql)
      if not insres then
          return 204, {errmsg = err}
      end
      
      --core.log.info("res: ", insres)
      return 200, insres
    end
end

return _M
