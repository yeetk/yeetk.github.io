local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str

local _M = {version = 0.1}


function _M.get(api_name, conf, segs)
    local user_config = core.config.local_conf().user_config
    local sub_path = table.concat(segs, "/")
    local args = ngx.req.get_uri_args() or {}

    --read session data
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    
    --collect uri
    local uri = ""
      --admin condition
        uri = user_config.home_uri .. "/sap/opu/odata/SAP/" .. api_name .. "/" .. sub_path .. "?" .. ngx.encode_args(args)
    
    --core.log.info("uri: ", uri)
    
    -- GET request cdsview call
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Accept"] = "application/xml",
        },
        ssl_verify = false,
    })

    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end

    --core.log.info("res: ", res.body)

    return 200, res.body
end


return _M
