local core = require("apisix.core")
local pgsql_str = core.pg.quote_pgsql_str


local _M = {version = 0.1}


function _M.get(user_name, conf, segs)
    if type(user_name) ~= "string" then
        return 400, {errmsg = "missing user name"}
    end

    local sql = "select * from t_user "
                .. "where f_uname = " .. pgsql_str(user_name)
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {error_msg = err}
    end
    res = res[1]
    res.f_passwd = nil

    return 200, res
end


function _M.put(user_name, conf, segs)
    if type(user_name) ~= "string" then
        return 400, {errmsg = "missing user name"}
    end

    local sql = "select f_id from t_user "
                .. "where f_uname = " .. pgsql_str(user_name)
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {error_msg = err}
    end

    if #res ~= 1 then
        return 500, {error_msg = "failed to find user: " .. user_name}
    end

    local new_values = {}
    for k, v in pairs(conf or {}) do
        table.insert(new_values, "f_".. k .. " = " .. pgsql_str(v))
    end

    if #new_values < 1 then
        return 400, {error_msg = "missing valid field"}
    end

    new_values = table.concat(new_values, ", ")

    sql = "update t_user set " .. new_values .. " where f_id == " .. res[1].f_id

    res, err = core.pg.query(sql)
    if not res then
        return 500, {error_msg = err}
    end

    return 200, res
end


function _M.post(user_name, conf, segs)
    if type(user_name) ~= "string" then
        return 400, {errmsg = "missing user name"}
    end

    if not conf then
        return 400, {error_msg = "missing valid arguments"}
    end

    local fields = {"f_uname"}
    local values = {pgsql_str(user_name)}
    for k, v in pairs(conf) do
        table.insert(fields, "f_" .. k)
        table.insert(values, pgsql_str(v))
    end
    fields = table.concat(fields, ", ")
    values = table.concat(values, ", ")

    local sql = "insert into t_user(" .. fields .. ") values (" .. values .. ")"
    core.log.info("post sql: ", sql)

    local res, err = core.pg.query(sql)
    if not res then
        return 500, {error_msg = err}
    end

    return 200, res
end


function _M.delete(user_name, conf, segs)
    local sql = "delete from t_user "
                .. "where f_uname = " .. pgsql_str(user_name)

    local res, err = core.pg.query(sql)
    if not res then
        return 500, {error_msg = err}
    end

    return 200, res
end


return _M
