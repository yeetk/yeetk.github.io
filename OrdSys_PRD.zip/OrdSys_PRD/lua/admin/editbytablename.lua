--�����ύ�ı����������ݿ��б�����
local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local session = require("admin.session")


local _M = {version = 0.1}

function _M.get(api_name, conf, segs)
end

function _M.post(api_name, conf, segs)	

	--��ȡpost����
	--ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
	--local res,reqerr= ngx.req.get_post_args() --��ȡpost
	local sql_tablename = conf.tableName 
--	core.log.info("sql_tablename: ", sql_tablename)
	local sql_tabledata = conf.dataSet 
--	core.log.info("sql_tabledata: ", sql_tablename)
	--ȥ��dataSet�еĿ�ֵ
	local sql_tabledata1 = {}
	for k,v in pairs(sql_tabledata) do
	   if v ~= "" then
		  sql_tabledata1[k] = v
	   end
	end

	local function selectdata(sql)
	local pg, err = pgmoon.new({
		host = "127.0.0.1",
		port = "5432",
		database = "hydb",
		user = "postgres",
		password = "112233"
	  })
	if not pg then
		  --return nil, err
		  --core.log.info("error: ", err)
		  ngx.say("error: ", err)
	  end
	  local ok, err = pg:connect()
	  if not ok then
		 ngx.say("error: ", err)
	  end 
	  local res, err = pg:query(sql) 
	  if not res then
		  ngx.say("error: ", err)
	  end  
	  pg:keepalive()
	  return res
	end
	local table_k = {}
	local table_v = {}
	local table_update = {}

	--ȷ��sql����ѯ���������ֶκ�����
	local sql = " SELECT a.attnum, a.attname AS field, t.typname AS mtype, a.attlen AS length, a.atttypmod AS lengthvar, a.attnotnull AS notnull, b.description AS comment FROM pg_class c, pg_attribute a LEFT JOIN pg_description b ON a.attrelid = b.objoid  AND a.attnum = b.objsubid, pg_type t WHERE c.relname = '" .. sql_tablename .. "' AND a.attnum > 0 AND a.attrelid = c.oid AND a.atttypid = t.oid  ORDER BY a.attnum"	
	local ret = selectdata(sql)
	--�����ֶηǿռ���
		for i=1,table.maxn(ret) do
		   if ret[i].notnull == true then
			 local l = 0
			   for  k,v in pairs(sql_tabledata1) do
					 if k==ret[i].field then
					 l=l+1
					 end				 
			   end
			 if l==0 then
			    local msg = {}
				msg["msg"] = ret[i].field.." is null"
				core.response.exit(200,cjson.encode(msg))
			 end		 
		   end	
		end	
		
	--��ѯ����
	local sql_selectkey ="SELECT string_agg(DISTINCT t3.attname,',')  AS primaryKeyColumn,t4.tablename AS tableName, string_agg(cast(obj_description(relfilenode,'pg_class') as varchar),'') as comment FROM pg_constraint t1 INNER JOIN pg_class t2 ON t1.conrelid = t2.oid INNER JOIN pg_attribute t3 ON t3.attrelid = t2.oid AND array_position(t1.conkey,t3.attnum) is not null INNER JOIN pg_tables t4 on t4.tablename = t2.relname INNER JOIN pg_index t5 ON t5.indrelid = t2.oid AND t3.attnum = ANY (t5.indkey) LEFT JOIN pg_description t6 on t6.objoid=t3.attrelid and t6.objsubid=t3.attnum WHERE  t1.contype = 'p' AND length(t3.attname) > 0 AND  t2.oid = '".. sql_tablename.."' :: regclass group by t4.tablename"
	local rkey = selectdata(sql_selectkey)	
		  rkey = rkey[1].primarykeycolumn --��ȡ������s���� mdate,mid  
	 
	 for  k,v in pairs(sql_tabledata1) do
	-- ����kֵѭ��ret�õ���������
		  for m = 1,table.maxn(ret) do
			 if ret[m].field == k then
				 if ret[m].mtype == "date" or ret[m].mtype == "char" or ret[m].mtype == "varchar" or ret[m].mtype == "bpchar" or ret[m].mtype == "time" then 
				 v = "'" .. v .. "'"
				 end
			  end		 
		  end
	--׼��һ��k�����飬��׼��һ��v������
		 table.insert(table_k,k)
		 table.insert(table_v,v)
		 table.insert(table_update,k .. "=" .. v)	  
	end
	--�õ�sql
	local mySql = "insert into " .. sql_tablename .." (" .. table.concat(table_k,",") .. ") values (" .. table.concat(table_v,",") .. ") on conflict(" .. rkey ..") do update set " .. table.concat(table_update,",")	
	core.log.info("sql: ", mySql)
	local mysqlRes = selectdata(mySql)  --����sql

	local msg = "success run"
	core.response.exit(200, core.json.encode(msg))
	
end
return _M  

   








