local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str

local _M = {version = 0.1}


function _M.get(api_name, conf, segs)
    local user_config = core.config.local_conf().user_config
    local sub_path = table.concat(segs, "/")
    local args = ngx.req.get_uri_args() or {}

    --read session data
    local session_val, err = session.get()
    if not session_val then
        return 401, err
    end
    
    --read user data
    local sql = "select f_group from t_user where f_id = " .. pgsql_str(session_val.f_id)
    local ures, err = core.pg.query(sql)
    if not ures then
        return 500, {errmsg = err}
    end
    
    --collect uri
    local uri = ""
    uri = user_config.home_uri .. "/sap/opu/odata/SAP/" .. api_name .. "/" .. sub_path .. "?" .. ngx.encode_args(args)
    --core.log.info("res_uri: ", uri)
    -- GET request cdsview call
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Accept"] = "application/xml",
        },
        ssl_verify = false,
    })

    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end
    
    --core.log.info(res.body)
    
    --when user is not admin user then read role authorization CDS View data
    if ures[1].f_group ~= "admin" then
        
        --read components for cdsview
        sql = "select * from t_comp_cds where f_callodata = '" .. api_name .. "'"
        
        local compres, err = core.pg.query(sql)
        if not compres then
            return 500, {errmsg = err}
        end
      
        --read role components values
        sql = "select * from t_role_value where f_role_id = any(array(select f_role_id from t_user_role where (CURRENT_DATE between f_from and f_to) and f_user_id = " .. pgsql_str(session_val.f_id) .. "))"
        local roleres, err = core.pg.query(sql)
        if not roleres then
            return 500, {errmsg = err}
        end
        
        --temp table for results filter
        local res_tab = {}
        
        for i, item in ipairs(compres) do
          local condition = ""
          for k, rolerow in ipairs(roleres) do
            if item.f_component == rolerow.f_component then
              --core.log.info(rolerow.f_values[1].field,"=",rolerow.f_values[1].value)
              condition = condition .. rolerow.f_values[1].field .. " eq '" .. rolerow.f_values[1].value .. "'"
              if k ~= #roleres then
                condition = condition .. " or "
              end
            end --of if L69
          end --of for L68
        
          --read authorization master data
          
          uri = user_config.home_uri .. "/sap/opu/odata/sap/" .. item.f_cds_view .. "/" .. item.f_cds_entity .. "?$format=json&$filter=" .. ngx.escape_uri(condition)
          --local uri = "https://my300054-api.saps4hanacloud.cn/sap/opu/odata/sap/API_SALES_ORDER_SRV/?$format=json"
          core.log.info("uri: ", uri)
          local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
          local cdsres, err = core.http.request_uri(uri, {
              method = "GET",
              headers = {
                  ["Authorization"] = "Basic " .. basic_auth,
                  ["Accept"] = "application/xml",
                  --["content-type"] = "application/json",
              },
              ssl_verify = false,
          })

          if not cdsres then
            return 500, err
          end

          if cdsres.status >= 300 then
            core.log.info("Error Code from CDS call:",cdsres.status)
            return cdsres.status, cdsres.body
          end
          --core.log.info(cdsres.body)

          --check data entry authorization
          
          local x = 1
          --core.log.info("cdsres body:",cdsres.body)
          for j, res in ipairs(core.json.decode(res.body).d.results) do
            local iAuth = 0
            for k, auth in ipairs(core.json.decode(cdsres.body).d.results) do
              if res[item.f_fieldodata] == auth[item.f_field] then
                iAuth = iAuth + 1
                --[[
                core.log.info(item.f_component)
                core.log.info(item.f_field)
                core.log.info(res[item.f_component])
                core.log.info(auth[item.f_field])
                --]]
              end
            end --of for loop at res
            
            if iAuth > 0 then
              --table.insert(res_tab,res)
              res_tab[x] = res
              x = x + 1
            end
          end --of for loop at cdsres
          --core.log.info(core.json.encode(res_tab))
        end --of for loop at comres
        return 200, core.json.encode(res_tab)
    else
      --admin condition
        return 200, res.body
    end
    --core.log.info("uri: ", uri)
    --core.log.info("res: ", res.body)
    --return 200, core.json.encode(res_tab)
end

return _M
