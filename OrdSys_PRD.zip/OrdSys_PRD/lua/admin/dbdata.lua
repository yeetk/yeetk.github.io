local core = require("apisix.core")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"

local _M = {version = 0.1}


function _M.get(id, conf, sub_path)
    core.log.info('conf: ', conf)
    if type(conf) ~= "table" then
        return 400, {errmsg = "missing valid request table"}
    end

    local values = {"true"}
    for field, vals in pairs(conf.where or {}) do
        if vals[1] == vals[2] then
            if type(vals[1]) == "string" then
                table.insert(values, field .. " = " .. pgsql_str(vals[1]))
            elseif type(vals[1]) == "boolean" then
                table.insert(values, field .. " = " .. tostring(vals[1]))
            else
                table.insert(values, field .. " = " .. vals[1])
            end
        else
            table.insert(values, "( " .. field .. " >= " .. pgsql_str(vals[1])
                                 .. " and "
                                 .. field .. " <= " .. pgsql_str(vals[1])
                                 .. " )")
        end
    end

    local sql = "select * from " .. conf.from_table .. " "
                .. "where " .. table.concat(values, " and ")
    core.log.info('sql: ', sql)

    local res, err = core.pg.query(sql)
    if not res then
        return nil, {error_msg = err}
    end

    core.log.info("succ: ", core.json.delay_encode(res))
    return 200, res
end

function _M.post(tabname, conf, sub_path)
    --core.log.info('conf: ', conf)
    if type(conf) ~= "table" then
        return 400, {errmsg = "missing valid request table"}
    end

    local isql = new_tab(10,0)
    local subsql = new_tab(3,0)
    local threeone = new_tab(3,0)
    local values = {"true"}
    for field, vals in pairs(conf.where or {}) do
        if vals[1] == vals[2] then
            if type(vals[1]) == "string" then
                table.insert(values, field .. " = " .. pgsql_str(vals[1]))
            elseif type(vals[1]) == "boolean" then
                table.insert(values, field .. " = " .. tostring(vals[1]))
            else
                table.insert(values, field .. " = " .. vals[1])
            end
        else
            isql[1] = "("
            isql[2] = field
            isql[3] = "= ANY (VALUES"
            
            isql[5] = " ))"
            subsql[1] = ""
            local len = #vals
            for k, v in ipairs(vals) do
              threeone[1] = "("
              threeone[2] = pgsql_str(v)
              threeone[3] = ")"
              subsql[2] = table.concat(threeone,"")
              if k ~= len then
                subsql[3] = ","
              else
                subsql[3] = ""
              end
              subsql[1] = table.concat(subsql,"")
              
            end
            isql[4] = subsql[1]
            
            table.insert(values, table.concat(isql, " "))
        end
    end

    local sql = "select * from " .. tabname .. " "
                .. "where " .. table.concat(values, " and ")
    core.log.info('sql: ', sql)

    local res, err = core.pg.query(sql)
    if not res then
        return nil, {error_msg = err}
    end

    core.log.info("succ: ", core.json.delay_encode(res))
    return 200, res
end

return _M
