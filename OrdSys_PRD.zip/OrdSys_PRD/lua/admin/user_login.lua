local core = require("apisix.core")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str


local _M = {version = 0.1}


function _M.post(user_name, conf, segs)
	
    if type(user_name) ~= "string" then
        return 400, {errmsg = "missing user name"}
    end

    if not conf then
        return 400, {errmsg = "missing body"}
    end

    local sql = "select * from t_user "
                .. "where f_uname = " .. pgsql_str(user_name)
                .. " and f_passwd = " .. pgsql_str(conf.passwd)
--	core.log.info("sql:",sql)
    local res, err = core.pg.query(sql)
    if not res then
        return 500, {error_msg = err}
    end

    if #res ~= 1 then
        return 200, {error_msg = "invalid password"}
    end

    res = res[1]
    res.f_passwd = nil

    local session_key, err = session.set(res)
    if not session_key then
        return 500, {error_msg = "failed to save session in shdict: " .. err}
    end

    local ck = require "resty.cookie"
    local cookie, err = ck:new()
    if not cookie then
        return 500, {error_msg = "failed to create cookie object: " .. err}
    end

--    core.log.info("session-key: ", session_key)
    local ok, err = cookie:set({
        key = "session_id", 
        value = session_key,
        path = "/", 
        --domain = "localhost", 
        expires = ngx.cookie_time(ngx.time() + 60 * 240),
    })
    if not ok then
        return 500, {error_msg = "failed to generate session id: " .. err}
    end	
--获取session中的url
    local url1 = session.geturl("url")
    if url1 ~= nil then    	
    return 200, {success = true, msg = "login success",url = url1}
	else
	return 200, {success = true, msg = "login success"}
	end
end


return _M
