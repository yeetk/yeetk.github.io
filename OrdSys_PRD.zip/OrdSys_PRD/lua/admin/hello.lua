local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local session = require("admin.session")


local _M = {version = 0.1}

function _M.get()
  core.response.exit(200, "Hello, hot reload World")
end

function _M.post(api_name, conf, segs)	

	local msg = "success run"
	core.response.exit(200, core.json.encode(msg))
	
end
return _M  

   








