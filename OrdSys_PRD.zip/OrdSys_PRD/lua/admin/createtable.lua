local core = require("apisix.core")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re   = require("ngx.re")

local _M = {version = 0.1}

--create DB table according t_api_field
function _M.put(api_name, conf, seg)
    if type(api_name) ~= "string" then
        return 204, {errmsg = "missing API name"}
    end

    local user_config = core.config.local_conf().user_config


    local apispl = ngx_re.split(api_name, ";")
    core.log.info("apispl: ", apispl[1])
    --read  data
    
    local sql = "select f_id from t_api where f_api = " .. pgsql_str(apispl[1])
    local res, err = core.pg.query(sql)
    if not res then
        return 204, {errmsg = err}
    end
    if res[1].f_id then
      --sql = "select f_property,f_type,f_length,f_label,f_precision,f_scale from t_api_field where f_apiid = " .. pgsql_str(res[1].f_id)
      sql = "select f_property,f_type,f_length,f_label,f_precision,f_scale from t_api_field where f_apiid = " .. pgsql_str(apispl[1]) .. "and f_entity = " .. pgsql_str(seg[1] .. "Type")
      
      res, err = core.pg.query(sql)
      if not res then
          return 204, {errmsg = err}
      end
      local csql = new_tab(6, 0)
      --local entityspl = ngx_re.split(seg[1], "Type")
      csql[1] = "CREATE TABLE public.t_"
      csql[2] = seg[1]
      csql[3] = " ( f_time timestamp without time zone NOT NULL DEFAULT LOCALTIMESTAMP, f_action character varying(20) COLLATE pg_catalog.\"default\", f_sysno character varying(60) COLLATE pg_catalog.\"default\" NOT NULL, f_entity character varying(90) COLLATE pg_catalog.\"default\" NOT NULL, "
      
      local rowsql = new_tab(3, 0)
      for k, row in ipairs(res) do
        rowsql[1] = csql[3]
        rowsql[2] = row.f_property
        rowsql[3] = " text COLLATE pg_catalog.\"default\", "
        --[[
        if row.f_type == "Edm.String"
          rowsql[3] = "varchar("
          rowsql[4] = row.f_length
          rowsql[5] = ""
          rowsql[6] = ""
        elseif row.f_type == "Edm.Decimal"
          rowsql[3] = "numeric("
          rowsql[4] = row.f_precision
          rowsql[5] = ","
          rowsql[6] = row.f_scale
        elseif row.f_type == "Edm.DateTime"
        
        elseif row.f_type == "Edm.Time"
          
        elseif row.f_type == "Edm.Double"
          
        end
        
        rowsql[7] = "),"
        ]]
        csql[3] = table.concat(rowsql,"")
      end
      csql[4] = "CONSTRAINT t_"
      csql[5] = seg[1]
      csql[6] = "_pkey PRIMARY KEY (f_time, f_sysno, f_entity) )"
      --csql[7] = 
      --csql[8] = "))"
      sql = table.concat(csql,"")
      core.log.info("SQL: ", sql)
      res, err = core.pg.query(sql)
      if not res then
          core.log.info("Error: ", err)
          return 204, {errmsg = err}
      end
      core.log.info("Results: ", res)
      return 200, {success = res}
    end
end


return _M
