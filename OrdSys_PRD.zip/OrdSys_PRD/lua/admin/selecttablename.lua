--��ѯ���ݿ�hydb�еı������б�
local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str

local _M = {version = 0.1}
function _M.post(api_name, conf, segs)
end
function _M.get(api_name, conf, segs)

local function selectdata(sql)
local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
     ngx.say("error: ", err)
  end 
  local res, err = pg:query(sql) 
  if not res then
      ngx.say("error: ", err)
  end  
   pg:keepalive()
  return res
 
end
local sql  = "SELECT pg_catalog.pg_relation_filenode(c.oid) as Filenode, relname as TableName FROM  pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace  LEFT JOIN pg_catalog.pg_database d ON d.datname ='hydb' WHERE  relkind IN ('r') AND n.nspname NOT IN ('pg_catalog', 'information_schema') AND n.nspname !~ '^pg_toast' ORDER BY relname"

core.response.exit(200, core.json.encode(selectdata(sql)))

end
return _M 

   








