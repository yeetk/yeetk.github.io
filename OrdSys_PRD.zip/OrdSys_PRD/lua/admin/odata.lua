local core = require("apisix.core")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str


local function parse_t_api(data_service)
    local api = data_service.Namespace
    local api_type = "ODATA"
    local version = data_service["sap:schema-version"]

    local sql = "INSERT INTO t_api(f_api, f_api_type, f_version) "
                .. format(" values(%s, %s, %s)", pgsql_str(api),
                          pgsql_str(api_type),
                          pgsql_str(version))
                .. " returning f_id"
    core.log.info("sql: ", sql)
    local res, err = core.pg.query(sql)
    if not res then
        return nil, err
    end

    core.log.info("succ: ", core.json.delay_encode(res))
    return res[1].f_id
end


local function parse_t_api_field(api_id, entity_name, entity)
    local values = {}
    local keys = {}
    for i, item in ipairs(entity) do
        if item.xml == "Key" then
            for _, key in ipairs(item) do
                if key.xml == "PropertyRef" then
                    keys[key.Name] = "true"
                end
            end
        end

        if item.xml == "Property" then
            local vals = {
                    api_id,

                    pgsql_str(entity.Name),
                    pgsql_str(item.Name),
                    pgsql_str(item.Type),
                    keys[item.Name] or "false",

                    item.Nullable or "false",
                    item.MaxLength or 0,
                    pgsql_str(item["sap:display-format"] or ""),
                    pgsql_str(item["sap:label"] or ""),

                    item["Precision"] or 0,
                    item["Scale"] or 0,
                    pgsql_str(item["sap:unit"] or ""),
                    pgsql_str(item["sap:quickinfo"] or ""),

                    item["sap:creatable"] or "false",
                    item["sap:updatable"] or "false",
                    pgsql_str(item["sap:concurrencymode"] or ""),
                    pgsql_str(item["sap:semantics"] or ""),
            }
            table.insert(values, "(" .. table.concat(vals, ", ") .. ")")
        end
    end

    local sql = "INSERT INTO t_api_field(f_apiid, "
                .. "f_entity, f_property, f_type, f_key, "
                .. "f_nullable, f_length, f_format, f_label, "
                .. "f_precision, f_scale, f_unit, f_quickinfo, "
                .. "f_creatable, f_updatable, f_concurrencymode, f_semantics)"
                .. " values " .. table.concat(values, ", ")
    core.log.info('sql: ', sql)
    local res, err = core.pg.query(sql)
    if not res then
        return nil, err
    end

    core.log.info("succ: ", core.json.delay_encode(res))
    return res
end


local function parse_t_api_entity(api_id, data_service)
    local values = {}
    for i, entity in ipairs(data_service) do
        if entity.xml == "EntityType" then
            local sql = format("(%s, %s, %s, %s)",
                    api_id,
                    pgsql_str(entity.Name),
                    pgsql_str(entity["sap:label"]),
                    pgsql_str(entity["sap:content-version"])
            )
            table.insert(values, sql)
            local res, err = parse_t_api_field(api_id, entity.Name, entity)
            if not res then
                return nil, "failed to parse t_api_field: " .. err
            end
            -- core.log.info("entity ", i, " : ", sql)
            -- core.log.warn("entity: ", core.json.encode(entity))
        end
    end

    local sql = "INSERT INTO t_api_entity(f_api_id, f_entity, f_label, f_entity_version) "
                .. "values" .. table.concat(values, ", ")
    core.log.info('sql: ', sql)
    local res, err = core.pg.query(sql)
    if not res then
        return nil, err
    end

    core.log.info("succ: ", core.json.delay_encode(res))
    return res
end


local _M = {version = 0.1}


function _M.put(api_name, conf, sub_path)
    if type(api_name) ~= "string" then
        return 400, {errmsg = "missing API name"}
    end

    local user_config = core.config.local_conf().user_config

    local uri = user_config.home_uri .. "/sap/opu/odata/SAP/" .. api_name
                .."/$metadata"
    local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Authorization"] = "Basic " .. basic_auth,
            ["Accept"] = "application/xml",
        },
        ssl_verify = false,
    })

    if not res then
        return 500, err
    end

    if res.status >= 300 then
        return res.status, res.body
    end

    -- todo: need to cache error
    local data = core.xml.load(res.body)
    local data_service
    for _, row in ipairs(data) do
        if row.xml == "edmx:DataServices" then
            data_service = row[1]
        end
    end

    if not data_service then
        return 400, {error_msg = "failed to found valid data service"}
    end

    local insert_id, err = parse_t_api(data_service)
    if not insert_id then
        return 500, {error_msg = err}
    end

    local res, err = parse_t_api_entity(insert_id, data_service)
    if not res then
        return 500, {error_msg = err}
    end

    return 200, {message = "success to fetch ODATA"}
end


return _M
