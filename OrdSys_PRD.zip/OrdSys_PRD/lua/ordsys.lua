local admin_init = require("admin.init")
local get_var = require("resty.ngxvar").fetch
local ngx = ngx
local ngx_exit = ngx.exit


local _M = {version = 0.1}


function _M.init_worker()
    admin_init.init_worker()
end


do
    local router

function _M.http_admin()
    if not router then
        router = admin_init.get()
    end

    -- core.log.info("uri: ", get_var("uri"), " method: ", get_method())
    local ok = router:dispatch(get_var("uri"), {method = ngx.req.get_method()})
    if not ok then
        ngx_exit(404)
    end
end

end -- do


return _M
