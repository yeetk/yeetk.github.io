local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
--计算当季收入

local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      --core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

--[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select * from t_stock_idx"
local selres, selerr = stockdb(isql)

--local uri = "http://www.cninfo.com.cn/data/project/commonInterface"
--local fieldmap = {营业收入="f_yysr", 营业成本="f_yycb", 营业利润="f_yylr", 利润总额="f_lrze", 所得税="f_sds", 净利润="f_jlr"}

for k, row in ipairs(selres) do

  if row.f_yysr then
    
    
    if row.f_rtype == 1 then
      --获取上期数据
      isql = "select * from t_stock_idx where f_code=" .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year-1 .. " and f_rtype=" .. 4
      res, err = stockdb(isql)
      if res[1] and res[1].f_yysr then
        local yysrq = row.f_yysr - res[1].f_yysr
        isql = "UPDATE t_stock_idx SET f_yysrq=" .. yysrq .. " where f_code = " .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year .. " and f_rtype=" .. row.f_rtype
        local updres, upderr = stockdb(isql)
      end
    else
      --获取上期数据
      isql = "select * from t_stock_idx where f_code=" .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year .. " and f_rtype=" .. row.f_rtype-1
      res, err = stockdb(isql)
      if res[1] and res[1].f_yysr then
        local yysrq = row.f_yysr - res[1].f_yysr
        isql = "UPDATE t_stock_idx SET f_yysrq=" .. yysrq .. " where f_code = " .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year .. " and f_rtype=" .. row.f_rtype
        local updres, upderr = stockdb(isql)
      end
    end
    

  end
end
return 200, {msg = "successful run"}