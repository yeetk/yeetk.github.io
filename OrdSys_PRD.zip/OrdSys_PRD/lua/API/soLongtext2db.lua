local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"

ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()

local user_config = core.config.local_conf().user_config
local api_name = "t_oms_so"
--collect uri
--local uri = user_config.home_uri .. "/sap/opu/odata/SAP/" ..  ngx.escape_uri("API_SALES_ORDER_SRV/A_SalesOrderText/?$format=json")
local uri = user_config.home_uri .. "/sap/opu/odata/SAP/API_SALES_ORDER_SRV/A_SalesOrderText/?$format=json"

core.log.info("uri: ", uri)

-- GET request cdsview call
local basic_auth = ngx.encode_base64(user_config.username .. ":" .. user_config.password)
local res, err = core.http.request_uri(uri, {
    method = "GET",
    headers = {
        ["Authorization"] = "Basic " .. basic_auth,
        ["Accept"] = "application/xml",
    },
    body = req_body,
    ssl_verify = false,
})

if not res then
    return 500, err
end

if res.status >= 300 then
    return res.status, res.body
end

core.log.info("res: ", res.body)
--local conf = {}
local i = 0
for k, row in ipairs(core.json.decode(res.body).d.results) do
  if row.Language == "ZH" and row.LongTextID == "TX01" then

    local isql = new_tab(10,0)
    local subsql = new_tab(3,0)
    
    local fieldsql = new_tab(2,0)
    local valuesql = new_tab(2,0)
    local keysql = new_tab(2,0)
    local setsql = new_tab(2,0)
    local wheresql = new_tab(2,0)
    
    local towone = new_tab(2,0)--for concat tow string
    local threeone = new_tab(3,0)-- for concat three string

    --core.log.info("conf: ", core.json.encode(conf))
    --local obj = core.json.decode(conf)
    --local obj = conf
    --core.log.info("obj: ", obj)
    ---[[
    local oKey = {}
    oKey[1] = "f_salesorder"
      local obj = { 
        keys = oKey,
        data = {
          f_salesorder = row.SalesOrder,
          f_tx01 = row.LongText,
          f_ybhd = "",
          f_fae = "",
        }
      }
    --]]

    
    fieldsql[1] = ""
    valuesql[1] = ""
    keysql[1] = ""
    setsql[1] = ""
    wheresql[1] = ""
    
    --insert into t_oms_so (f_salesorder, f_tx01, f_ybhd, f_fae) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_salesorder) do update set f_tx01='', f_ybhd='', f_fae='' where f_salesorder='1';
    
    for k in pairs(obj.data) do
      fieldsql[2] = k
      if fieldsql[1] ~= "" then
        fieldsql[1] = table.concat(fieldsql,", ")
      else
        -- do not concat when first field
        fieldsql[1] = k
      end
      
      valuesql[2] = pgsql_str(obj.data[k])
      if valuesql[1] ~= "" then
        valuesql[1] = table.concat(valuesql,", ")
      else
        -- do not concat when first field
        valuesql[1] = valuesql[2]
      end
      
      
      if string.find(core.json.encode(obj.keys),k) then
        --when field is key field
        keysql[2] = k
        if keysql[1] ~= "" then
          keysql[1] = table.concat(keysql,", ")
        else
          -- do not concat when first field
          keysql[1] = k
        end
        --concat where condition
        subsql[1] = k
        subsql[2] = "="
        subsql[3] = pgsql_str(obj.data[k])
        
        wheresql[2] = table.concat(subsql,"")
        if wheresql[1] ~= "" then
          wheresql[1] = table.concat(wheresql," AND ")
        else
          -- do not concat when first field
          wheresql[1] = wheresql[2]
        end
      else
        --concat set fields
        subsql[1] = k
        subsql[2] = "="
        subsql[3] = pgsql_str(obj.data[k])
        
        setsql[2] = table.concat(subsql,"")
        if setsql[1] ~= "" then
          setsql[1] = table.concat(setsql,", ")
        else
          -- do not concat when first field
          setsql[1] = setsql[2]
        end
      end
    end
    
    isql[1] = "INSERT INTO "
    isql[2] = api_name
    isql[3] = " ("
    isql[4] = fieldsql[1]
    isql[5] = ") VALUES ("
    isql[6] = valuesql[1]
    isql[7] = ") ON CONFLICT("
    isql[8] = keysql[1]
    isql[9] = ") DO UPDATE SET "
    isql[10] = setsql[1]
    --isql[11] = " WHERE "
    --isql[12] = wheresql[1]

    local sql = table.concat(isql,"")
    core.log.info("insert sql: ", sql)
    local insres, err = core.pg.query(sql)
    if not insres then
        return 204, {errmsg = err}
    end
    
    --core.log.info("res: ", insres)
    i = i + 1
  end
end
return 200, i