local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

--更新数据库
local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.log.info("sql: ", sql)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

--[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select * from t_stock_list"
local selres, selerr = stockdb(isql)

local preuri = "https://data.gtimg.cn/flashdata/hushen/latest/daily/"

---[[
for k, row in ipairs(selres) do
  --for i=1,4 do
    --获取百日价格数据
    --core.log.info("updating:",row.f_code)
    local uri = preuri .. string.lower(string.sub(row.f_market,1,2)) .. row.f_code .. ".js"
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Content-Type"] = "application/javascript",
            ["Referer"] = "http://data.gtimg.cn/",
            --["mcode"] = value.mcode,
        },
        --body = "mergerMark=sysapi1075&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if not res then
      --return 500, err
      core.log.info(500, err, '~code=', row.f_code)
    end

--[[
    if res.status >= 300 then
      --return res.status, res.body
      core.log.info(res.status, res.body)
    end
  ]]
    --core.log.info("res: ", res.body)
    local split_res, split_err = ngx_re.split(res.body,"\n")

    local i = 0 --过去60日跳空天数
    local j = 0 --过去60日上涨天数
    local m = 0 --过去13天成交量计算计数器
    local last13tab = {} --过去13天的成交量数据
    local sumvolume = 0 --过去13天成交量累计
    local avgvolume = 0 --过去13天平均成交量
    local variance = 0 --过去13天成交量方差
    local std_deviation = 0 --过去13天成交量标准差
    local volume_jump = 1 --当天成交量与过去13天成交量比值
    
    local jump_prob = 0 --过去13周跳空概率
    local sumjumprate = 0 --累计跳空比例
    local averagejumprate = 0 --过去13周平均跳空比例
    local t1_rise_prob65 = 0 --过去13周上涨概率
    local sumriserate = 0 --过去13周累计上涨比例
    local sumdroprate = 0 --过去13周累计下跌比例
    local t1_average_rise_rate = 0 --过去13周平均上涨比率
    local t1_average_drop_rate = 0 --过去13周平均上涨比率
    
    local sum_volat60 = 0 --真实波幅累计
    local efficiency19 = 0
    local efficiency60 = 0
    
    local istreak = 0 --连涨天数
    local risestop = 0 --壹字涨停天数
    local breakout = nil --连涨标识
    local breakout19 = "" --19天突破标识
    local breakout65 = "" --65天突破标识
    local highprice19 = 0
    local highprice65 = 0
    local lowprice19 = 999999
    local lowprice65 = 999999
    
    --local startprice = 0
    local split_lastday, lastday_err = ngx_re.split(string.sub(split_res[#split_res-1],1,-4)," ")
    local endprice = tonumber(split_lastday[3])
    local lastdayhighprice = tonumber(split_lastday[4])
    
    --[[
    if k == 1 then
      core.log.info(core.json.encode(split_res))
      --core.log.info(res)
    end
    --]]
    if #split_res < 68 then
    --上市不满65天的股票
      for l=#split_res-1,3,-1 do
        local split_day, day_err = ngx_re.split(string.sub(split_res[l],1,-4)," ")
        --split_day = {日期，开，收，高，低，量}
        --core.log.info(split_day)
        local split_yesterday, yesterday_err = ngx_re.split(string.sub(split_res[l-1],1,-4)," ")
        
        local todaystart = tonumber(split_day[2]) or 0
        local todayhigh = tonumber(split_day[4]) or 0
        local todayend = tonumber(split_day[3]) or 0
        local todaylow = tonumber(split_day[5]) or 0
        local yesterdayend = tonumber(split_yesterday[3]) or 0
        --local yesterdayhigh = tonumber(split_yesterday[4]) or 0
        
        --计算区间最高价
        if todayhigh >= highprice19 and l >= #split_res-19 then
          highprice19 = todayhigh
        end
        if todayhigh >= highprice65 then
          highprice65 = todayhigh
        end
        
        --计算跳空开盘天数
        if todaystart >= yesterdayend and l > 3 then
          i = i + 1
          sumjumprate = sumjumprate + ( todaystart - yesterdayend ) / yesterdayend
        end
        
        
        if l > 3 then
          --计算60天内上涨天数、判断连涨
          if todayend >= yesterdayend then
            j = j + 1
            sumriserate = sumriserate + ( todayend - yesterdayend ) / yesterdayend
            if not breakout then
              istreak = istreak + 1
              if todayhigh == todaylow then
                --如果当日最高价与最低价相等，说明是一字涨停
                risestop = risestop + 1
              end
            else
              
            end
          else
            sumdroprate = sumdroprate + ( yesterdayend - todayend ) / yesterdayend
            breakout = 1
          end
          
          --计算真实波幅累计
          if todaylow > yesterdayend then
              sum_volat60 = todayhigh - yesterdayend + sum_volat60
          else
            if yesterdayend > todayhigh then
              sum_volat60 = yesterdayend - todaylow + sum_volat60
            else 
              sum_volat60 = todayhigh - todaylow + sum_volat60
            end
          end
        end
      end
      
      --跳空概率、平均跳空比例
      jump_prob = i / ( #split_res - 3 )
      
      if i ~= 0 then
        averagejumprate = sumjumprate * 100 / i
      end
      
      --T+1上涨概率、平均上涨比例
      t1_rise_prob65 = j / ( #split_res - 3 )
      if j ~= 0 then
        t1_average_rise_rate = sumriserate * 100 / j
        t1_average_drop_rate = sumdroprate * 100 / ( #split_res - 3 - j )
      end
      
      --首日开盘价
      local split_firstday, firstday_err = ngx_re.split(string.sub(split_res[3],1,-4)," ")
      local startprice = tonumber(split_firstday[2])
      local avarage_volat60 = sum_volat60 / ( #split_res - 3 )
      efficiency60 = ( endprice - startprice ) / avarage_volat60
      
    else
    --上市满65天的股票
      for l=#split_res-1,#split_res-65,-1 do
        local split_day, day_err = ngx_re.split(string.sub(split_res[l],1,-4)," ")
        --split_day = {日期，开，收，高，低，量}
        --core.log.info(split_day)
        local split_yesterday, lastday_err = ngx_re.split(string.sub(split_res[l-1],1,-4)," ")
        
        local todaystart = tonumber(split_day[2]) or 0
        local todayhigh = tonumber(split_day[4]) or 0
        local todayend = tonumber(split_day[3]) or 0
        local todaylow = tonumber(split_day[5]) or 0
        local yesterdayend = tonumber(split_yesterday[3]) or 0
        --local yesterdayhigh = tonumber(split_yesterday[4]) or 0
        
        
        
        --计算区间最高价格
        if todayhigh >= highprice19 and l >= #split_res-19 then
          highprice19 = todayhigh
        end
        if todayhigh >= highprice65 and l >= #split_res-65 then
          highprice65 = todayhigh
        end
        
        --计算区间最低价格
        if todaylow < lowprice19 and l >= #split_res-19 then
          lowprice19 = todaylow
        end
        if todaylow < lowprice65 and l >= #split_res-65 then
          lowprice65 = todaylow
        end
        
        --计算跳空开盘天数
        if todaystart >= yesterdayend and l > #split_res-65 then
          i = i + 1
          sumjumprate = sumjumprate + ( todaystart - yesterdayend ) / yesterdayend
        end
        
        --计算13周内上涨天数、判断连涨状态
        if l  > #split_res-65 then
          if todayend >= yesterdayend and l  > #split_res - 65 then
            j = j + 1
            sumriserate = sumriserate + ( todayend - yesterdayend ) / yesterdayend
            if not breakout then
              istreak = istreak + 1
              if todayhigh == todaylow then
                --如果当日最高价与最低价相等，说明是一字涨停
                risestop = risestop + 1
              end
            else
              
            end
          else
            sumdroprate = sumdroprate + ( yesterdayend - todayend ) / yesterdayend
            breakout = 1
          end
        end
        
        --计算真实波幅累计
        if l > #split_res-60 then
          if todaylow > yesterdayend then
            sum_volat60 = todayhigh - yesterdayend + sum_volat60
          else
            if yesterdayend > todayhigh then
              sum_volat60 = yesterdayend - todaylow + sum_volat60
            else
              sum_volat60 = todayhigh - todaylow + sum_volat60
            end
          end
        end
        
        --计算过去13天总成交量
        if m < 14 then
          m = m + 1
          last13tab[m] = tonumber(split_day[6]) or 0
          if m > 1 then
            sumvolume = sumvolume + last13tab[m]
          end
          
        end
        
      end --end of for loop
      
      --计算过去13天平均成交量
      avgvolume = sumvolume / 13
      for l=2,14,1 do
      --for l, v in ipairs(last13tab) do
        variance = variance + ( last13tab[l] - avgvolume ) ^ 2
      end
      
      --跳空概率、平均跳空比例
      jump_prob = i / 65
      if i ~= 0 then
        averagejumprate = sumjumprate * 100 / i
      end
      
      --T+1上涨概率、平均上涨比例、下跌比率
      t1_rise_prob65 = j / 65
      if j ~= 0 then
        t1_average_rise_rate = sumriserate * 100 / j
        t1_average_drop_rate = sumdroprate * 100 / ( 65 - j )
      end
      
      --首日开盘价
      local split_firstday, firstday_err = ngx_re.split(string.sub(split_res[#split_res-60],1,-4)," ")
      local startprice = tonumber(split_firstday[2])
      
      local avarage_volat60 = sum_volat60 / 60
      efficiency60 = ( endprice - startprice ) / avarage_volat60
    
    end -- end of if  < 60 days
    
    if avgvolume ~= 0 then
      std_deviation = variance ^ 0.5 / avgvolume --计算过去13天成交量标准差
    else
      std_deviation = 0
    end
    if last13tab[1] and avgvolume then
      volume_jump =  last13tab[1] / avgvolume --计算当天成交量比过去13天平均成交量变动情况
    else
      volume_jump = 1
    end
    
    if highprice19 == endprice then
      breakout19 = "x"
    else
      breakout19 = " "
    end
    
    if highprice65 == endprice then
      breakout65 = "x"
      --core.log.info(row.f_code)
    else
      breakout65 = " "
    end
    efficiency60 = efficiency60 - efficiency60 % 0.001
    --core.log.info(core.json.encode(efficiency60))
    local firstday_arr, firstday_err = ngx_re.split(string.sub(split_res[3],1,-4)," ")
    local firstdate = "20" .. string.sub(firstday_arr[1],1,2) .. "-" .. string.sub(firstday_arr[1],3,4)  .. "-" ..  string.sub(firstday_arr[1],5,6)
    isql = "UPDATE t_stock_list SET f_date=" .. pgsql_str(firstdate) .. ", f_lzts=" .. istreak .. ", f_breakout19=" .. pgsql_str(breakout19) .. ", f_breakout65=" .. pgsql_str(breakout65) .. ", f_price_n=" .. endprice .. ", f_efficiency60=" .. efficiency60 .. ", f_jump_prob65=" .. string.format("%0.3f", jump_prob) .. ", f_jump_average_rate65=" .. string.format("%0.3f", averagejumprate)  .. ", f_t1_rise_prob65=" .. string.format("%0.3f", t1_rise_prob65) .. ", f_t1_average_rise_rate65=" .. string.format("%0.3f", t1_average_rise_rate) .. ", f_highprice19=" .. string.format("%0.3f", highprice19) .. ", f_lowprice19=" .. string.format("%0.3f", lowprice19) .. ", f_highprice65=" .. string.format("%0.3f", highprice65) .. ", f_lowprice65=" .. string.format("%0.3f", lowprice65) .. ", f_t1_average_drop_rate65=" .. string.format("%0.3f", t1_average_drop_rate)  .. ", f_std_deviation=" .. string.format("%0.4f", std_deviation)  .. ", f_volume_jump=" .. string.format("%0.3f", volume_jump) ..  ", f_linerisestop=" .. risestop ..  " where f_code = " .. pgsql_str(row.f_code)
    --f_linerisestop
    --core.log.info("code-%s: %s", row.f_code,isql)
    local updres, upderr = stockdb(isql)
    
    local tdate = "20" .. string.sub(split_lastday[1],1,2) .. "-" .. string.sub(split_lastday[1],3,4)  .. "-" ..  string.sub(split_lastday[1],5,6)
    isql = "insert into t_stock_daily (f_code, f_date, f_open, f_close, f_high, f_low, f_volume, f_efficiency60, f_std_deviation, f_volume_jump) values(" .. pgsql_str(row.f_code) .. "," .. pgsql_str(tdate) .. "," .. split_lastday[2] .. "," .. split_lastday[3] .. "," .. split_lastday[4] .. "," .. split_lastday[5]  .. "," .. split_lastday[6]  .. "," .. string.format("%0.3f", efficiency60) .. "," .. string.format("%0.3f", std_deviation) .. "," .. string.format("%0.3f", volume_jump) .. ") ON CONFLICT(f_code, f_date) do update set f_efficiency60=" .. string.format("%0.3f", efficiency60) .. ", f_std_deviation=" .. string.format("%0.4f", std_deviation) .. ", f_volume_jump=" .. string.format("%0.3f", volume_jump)
    --core.log.info("code-%s: %s", row.f_code,isql)
    local insres, inserr = stockdb(isql)
    
end
--]]
--core.response.exit(200, core.json.encode(selres))