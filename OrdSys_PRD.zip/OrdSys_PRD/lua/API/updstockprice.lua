local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

--更新价格连涨天数

local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

--[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select * from t_stock_list"
local selres, selerr = stockdb(isql)

local preuri = "https://data.gtimg.cn/flashdata/hushen/latest/daily/"
--local fieldmap = {营业收入="f_yysr", 营业成本="f_yycb", 营业利润="f_yylr", 利润总额="f_lrze", 所得税="f_sds", 净利润="f_jlr"}
--[[
local uri = "http://data.gtimg.cn/flashdata/hushen/latest/daily/sh600881.js"
local res, err = core.http.request_uri(uri, {
    method = "GET",
    headers = {
        ["Content-Type"] = "application/x-www-form-urlencoded",
        ["Referer"] = "http://data.gtimg.cn/",
        --["mcode"] = value.mcode,
    },
    --body = "mergerMark=sysapi1075&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
    ssl_verify = false,
})
--core.log.info(res.body)
local split_res, split_err = ngx_re.split(res.body,"\n")
--core.log.info(split_res)
for l=#split_res-1,3,-1 do
  
  ngx.say(string.sub(split_res[l],1,-4),"</br>")
end
--]]

---[[
for k, row in ipairs(selres) do
  --for i=1,4 do
    --获取百日价格数据
    --core.log.info(row.f_market,row.f_code)
  if row.f_code == "300076" then --debug
    
    local uri = preuri .. string.lower(string.sub(row.f_market,1,2)) .. row.f_code .. ".js"
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Content-Type"] = "application/javascript",
            ["Referer"] = "http://data.gtimg.cn/",
            --["mcode"] = value.mcode,
        },
        --body = "mergerMark=sysapi1075&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if not res then
      --return 500, err
      core.log.info(500, err)
    end

--[[
    if res.status >= 300 then
      --return res.status, res.body
      core.log.info(res.status, res.body)
    end
  ]]
    --core.log.info("res: ", res.body)
    local split_res, split_err = ngx_re.split(res.body,"\n")
    local i = 0 --过去100日上涨天数
    local istreak = 0 --连涨天数
    local breakout = nil --连涨标识
    local breakout20 = "" --20天突破标识
    local breakout60 = "" --60天突破标识
    local highprice20 = 0
    local highprice60 = 0
    local lastdayhighprice = 0
    if k == 1 then
      core.log.info(core.json.encode(split_res))
      --core.log.info(res)
    end
    for l=#split_res-1,3,-1 do
      local split_day, day_err = ngx_re.split(string.sub(split_res[l],1,-4)," ")
      --split_day = {开，收，高，低}
      --core.log.info(split_day)
      local split_lastday, lastday_err = ngx_re.split(string.sub(split_res[l-1],1,-4)," ")
      
      local todayhigh = tonumber(split_day[4]) or 0
      local todayend = tonumber(split_day[3]) or 0
      local yestedayhigh = tonumber(split_lastday[4]) or 0
      local yestedayend = tonumber(split_lastday[3]) or 0
      if todayend >= yestedayend then
        i = i + 1
        if not breakout then
          istreak = istreak + 1
        else
          
        end
      else
        breakout = 1
      end
      if todayhigh >= highprice20 and l >= #split_res-20 then
        highprice20 = todayhigh
      end
      if todayhigh >= highprice60 and l >= #split_res-60 then
        highprice60 = todayhigh
      end
      if l == #split_res-1 then
        lastdayhighprice = todayhigh
      end
    end
    if highprice20 == lastdayhighprice then
      selres[k]["f_breakout20"] = "x"
      breakout20 = "x"
    else
      breakout20 = " "
    end
    if highprice60 == lastdayhighprice then
      
      breakout60 = "x"
      core.log.info(row.f_code)
    else
      breakout60 = " "
    end
    selres[k]["f_lzts"] = istreak

    isql = "UPDATE t_stock_list SET f_lzts=" .. istreak .. ", f_breakout20=" .. pgsql_str(breakout20) .. ", f_breakout60=" .. pgsql_str(breakout60) .. " where f_code = " .. pgsql_str(row.f_code)
    core.log.info("code-%s: %s", isql)
    local updres, upderr = stockdb(isql)
    
    
    core.log.info(highprice60)
    core.log.info(lastdayhighprice)
  end --debug
end
--]]
core.response.exit(200, "successful run!")