local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })

--��ѯ���������ֶκ�����
local sql_table = "" 

local arg = ngx.req.get_uri_args()

for k,v in pairs(arg) do
   if k == "tablename"  then
    sql_table = v
 end
 end
local sql = " SELECT a.attnum,a.attname AS field "
  .." FROM pg_class c, pg_attribute a LEFT JOIN pg_description b ON a.attrelid = b.objoid  AND a.attnum = b.objsubid, pg_type t"
  .." WHERE c.relname = '"..sql_table.."' AND a.attnum > 0 AND a.attrelid = c.oid AND a.atttypid = t.oid  ORDER BY a.attnum"

local function selectdata(sql)
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
     ngx.say("error: ", err)
  end 
  local res, err = pg:query(sql) 
  if not res then
      ngx.say("error: ", err)
  end 
  return res
end

local ret = selectdata(sql)
ngx.say(cjson.encode(ret))
 pg:keepalive()    










