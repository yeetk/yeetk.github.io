local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

--��һ��sql���ݱ���������mid��ȡhymlog������ѯ����pid��ѯhyplayer, �ڶ���sql���ݶ�������ȡhymatch������ʷ�������
local function selectsql(sql)
local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      --core.log.info("error: ", err)
     ngx.say("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
      --core.response.exit(204, err)
  end
  pg:keepalive()  
  return res  
 end 
local spl_mdate = ""
local spl_mid = ""
local spl_vs = ""

local arg = ngx.req.get_uri_args()
for k,v in pairs(arg) do
if k == "mdate"  then
    spl_mdate = "\'"..v.."\'"
 end
 if k == "mid"  then
    spl_mid = v
 end
 --sql_k = sql_k .. "" .. k .. ","
 --sql_v = sql_v ..v .. ","
end
--core.log.info("season: ", sql_season)
local sql ="select hymatch.*,hymrepo.mreport,hymrepo.mchat,hymrepo.mbrief from hymatch left outer join hymrepo on   hymatch.mdate = hymrepo.mdate and hymatch.mid = hymrepo.mid where hymatch.mdate = " .. spl_mdate .. " and hymatch.mid = " .. spl_mid 

local sql1 ="select hymlog.*,hyplayer.nick from hymlog left outer join hyplayer on hymlog.pid = hyplayer.id  where hymlog.mdate = " .. spl_mdate .. " and hymlog.mid = " ..spl_mid .. " order by hymlog.minute asc"
--core.log.info("sql: ", sql)
--core.log.info("res: ", res)
--ngx.say(res)
local res0= selectsql(sql)
local res1= selectsql(sql1)
local spl_vs = res0[1].vs

-- and (mdate <> " .. spl_mdate .. " and mid <> " .. spl_mid .. ") 
local sql2 ="select * from hymatch where mdate != ".. spl_mdate .. "and vs = '" .. spl_vs ..  "' order by mdate desc "

local res2= selectsql(sql2)
--[[
local res21={}
local index = 1
for i =1,table.maxn(res2) do
   if res2[i].mdate ~= spl_mdate and res2[i].mid ~= mid then
        res21[index]=res2[i]
   end	
   index =index+1
end
--]]
local msg = "no data"
local res3 = {}
if res0 ~= nil then
   res3["match"] = res0[1]
else
   res3["match"] = msg
end
if next(res1) ~= nil then
   res3["playergoal"] = res1
else
   res3["playergoal"] = msg
end


if next(res2) ~= nil then
   res3["historymatchdata"] = res2
else
   res3["historymatchdata"] = msg
end

core.response.exit(200, core.json.encode(res3))


