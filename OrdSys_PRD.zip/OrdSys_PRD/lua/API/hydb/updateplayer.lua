local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
--��ȡget����


local sql ="update hyplayer set "
local sql_id = " "

  local arg = ngx.req.get_uri_args()
for k,v in pairs(arg) do
if k == "id"  then
    sql_id = "\'"..v.."\'"
end
 if k == "sn"  then
    v = "\'"..v.."\'"
 end
 if k == "nick"  then
    v = "\'"..v.."\'"
 end
 if k == "active"  then
    v = "\'"..v.."\'"
 end
  if k == "ename"  then
    v = "\'"..v.."\'"
 end
 if k == "name"  then
    v = "\'"..v.."\'"
 end
 if k == "active"  then
    v = "\'"..v.."\'"
 end
if k ~= "id" then 
 sql = sql .. k .. "=" .. v ..","
 end
 --sql_k = sql_k .. "" .. k .. ","
 --sql_v = sql_v ..v .. ","
end
--ȥ�����һ������
sql = string.sub(sql,1,-2)
sql = sql .. " where id = " ..sql_id
 ngx.say(sql)

if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      --core.log.info("error: ", err)
     ngx.say("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
      --core.response.exit(204, err)
  else
  local ret = {}
     ret["ret"] = ok  
   ngx.say(cjson.encode(ret))
  end
  pg:keepalive()    
  --core.log.info("res: ", res)










