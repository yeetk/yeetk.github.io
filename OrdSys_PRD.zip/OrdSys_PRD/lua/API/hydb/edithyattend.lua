local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
--��ȡget����
--��ѯhyattend
local sql1 = "select * from hyattend where" 
--��ѯhynatch��hymatch
local sql2 = "select season from hymatch where"
local sql3 = "select sn,nick from hyplayer where"
--����hyattend
local sql ="insert into hyattend ("
local sql_k = " "
local sql_v = " "
local sql_mdate = ""
local sql_mid = ""
local sql_playerid = ""

local arg = ngx.req.get_uri_args()
for k,v in pairs(arg) do
 if k == "mdate"  then
    v = "\'"..v.."\'"
	sql_mdate = v
 end
 if k == "mid"  then
	sql_mid = v
 end
 if k == "playerid"  then
    v = "\'"..v.."\'"
	sql_playerid = v
 end

 sql_k = sql_k .. "" .. k .. ","
 sql_v = sql_v ..v .. ","
end
sql1 = sql1 .." mdate = "..sql_mdate.." and mid = "..sql_mid.." and playerid = "..sql_playerid
sql2 = sql2 .." mdate = "..sql_mdate.." and mid = "..sql_mid
sql3 = sql3 .." id = "..sql_playerid

--ȥ�����һ������
--sql_k = string.sub(sql_k,1,-2)
--sql_v = string.sub(sql_v,1,-2)


local function selectdata(sql)
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
     ngx.say("error: ", err)
  end 
  local res, err = pg:query(sql) 
  if not res then
      ngx.say("error: ", err)
  end
  return res
end
 
 local res1 = selectdata(sql1)
 local res2 = selectdata(sql2)
 local res3 = selectdata(sql3)

 local sql_season = res2[1].season
 local sql_sn = res3[1].sn
 local sql_nick = res3[1].nick
--�¹�hyattend�з��ص�������ֵ�������޸ģ�����ֵ��������   
if res1[1] ~= nil then 
  --�޸�
  ngx.say(res1[1].plan)
  if res1[1].plan == 1 then
  local sql_update0 = "update hyattend set plan = 0 where playerid ="..sql_playerid .." and mdate = " .. sql_mdate .. " and mid = " ..sql_mid 
  ngx.say(sql_update0)
 ngx.say(selectdata(sql_update0))
  end
  if res1[1].plan == 0 then
  local sql_update1 = "update hyattend set plan = 1 where playerid ="..sql_playerid .." and mdate = " .. sql_mdate .. " and mid = " ..sql_mid 
  ngx.say(sql_update1)
  ngx.say(selectdata(sql_update1))
  end
else
  --����
    sql = sql ..sql_k .. " season , sn , nick ) values (" ..sql_v .. sql_season..","..sql_sn..",\'".. sql_nick.."\')"
	ngx.say(sql)
	ngx.say(selectdata(sql))
end	   
  
  pg:keepalive()    











