local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })

--local sql ="select hymatch.*,hymrepo.mreport from hymatch left outer join hymrepo on hymatch.mdate = hymrepo.mdate and  hymatch.mid = hymrepo.mid where season =  "
local sql_season = ""

local arg = ngx.req.get_uri_args()
for k,v in pairs(arg) do
if k == "season"  then
    sql_season = "\'"..v.."\'"
 end
 --sql_k = sql_k .. "" .. k .. ","
 --sql_v = sql_v ..v .. ","
end
--core.log.info("season: ", sql_season)
local sql ="select hymatch.*,hymrepo.mbrief from hymatch left outer join hymrepo on hymatch.mdate = hymrepo.mdate and  hymatch.mid = hymrepo.mid where season = " .. sql_season .. "and hymatch.goal is not null and hymatch.goaled is not null order by mdate desc"
--core.log.info("sql: ", sql)
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      --core.log.info("error: ", err)
     ngx.say("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
      --core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
--ngx.say(res)
local msg= sql_season .. "赛季没有比赛信息"
if next(res) ~= nil then
core.response.exit(200, core.json.encode(res))
else 
core.response.exit(200, core.json.encode(msg))
end