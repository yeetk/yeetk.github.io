local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")


local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })


--ȥ�����һ������
--sql_k = string.sub(sql_k,1,-2)
--sql_v = string.sub(sql_v,1,-2)


--��ȡpost����
ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
--local arg = ngx.req.get_post_args() --��ȡpost
local data = ngx.req.get_body_data() 
--local obj = cjson.decode(data)
--ngx.say(data)
--��һ�� �õ�"tablename =hymatch ��dataset = 2013-08-03...."
--��������
local sql_tablename = ""
--��������
local sql_tabledata = ""

local split_res, split_err = ngx_re.split(data,"&")
for k, row in ipairs(split_res) do
     if k == 1 then 
--��ڶ���	 
      	 local split_res1, split_err1 = ngx_re.split(row,"=")
		 sql_tablename = split_res1[2]
	 else
--��ڶ���	 
         local split_res2, split_err2 = ngx_re.split(row,"=")
		 sql_tabledata = split_res2[2]	          		 
		 end
end
--sql_tabledata��������õ�����
local split_res3, split_err3 = ngx_re.split(sql_tabledata,"n")
      sql_tabledata = split_res3 

	  
	  
--ȷ��sql����ѯ���������ֶκ�����
local sql = " SELECT a.attnum, a.attname AS field, t.typname AS mtype, a.attlen AS length, a.atttypmod AS lengthvar, a.attnotnull AS notnull, b.description AS comment"
  .." FROM pg_class c, pg_attribute a LEFT JOIN pg_description b ON a.attrelid = b.objoid  AND a.attnum = b.objsubid, pg_type t"
  .." WHERE c.relname = '"..sql_tablename.."' AND a.attnum > 0 AND a.attrelid = c.oid AND a.atttypid = t.oid  ORDER BY a.attnum"	  

local function selectdata(sql)
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
     ngx.say("error: ", err)
  end 
  local res, err = pg:query(sql) 
  if not res then
      ngx.say("error: ", err)
  end 
  return res
end
local addsql = "insert into "..sql_tablename.." ("
local ret = selectdata(sql)
--ngx.say(cjson.encode(ret))


local delete = sql_tabledata[1]
delete = string.sub(delete,1,-2)
local split_res5, split_err5 = ngx_re.split(delete,",")
		 delete = split_res5	          		 
		
local sql_update = {}
--׼�����µ��ֶ�
local update_i = 1
local ret_new = {}
--����kֵ
for i = 1,table.maxn(ret) do
--���˵�\N
  if delete[i] ~= "\\".."\\N" and  delete[i] ~= nil then
     addsql = addsql .. ret[i].field ..","
	 sql_update[update_i] = ret[i].field
	 ret_new[update_i] = ret[i]
	 update_i = update_i+1
	 end 	  
--����valueֵ,��������ֶ�˳��ѭ����ƴ�ӵ�һ���ַ���
 end
 --ngx.say(addsql)

addsql = string.sub(addsql,1,-2)..") values("

--��ѯ����
local sql_selectkey ="SELECT string_agg(DISTINCT t3.attname,',')  AS primaryKeyColumn,t4.tablename AS tableName, string_agg(cast(obj_description(relfilenode,'pg_class') as varchar),'') as comment"
.." FROM pg_constraint t1 INNER JOIN pg_class t2 ON t1.conrelid = t2.oid INNER JOIN pg_attribute t3 ON t3.attrelid = t2.oid AND array_position(t1.conkey,t3.attnum) is not null"
.." INNER JOIN pg_tables t4 on t4.tablename = t2.relname INNER JOIN pg_index t5 ON t5.indrelid = t2.oid AND t3.attnum = ANY (t5.indkey) LEFT JOIN pg_description t6 on t6.objoid=t3.attrelid and t6.objsubid=t3.attnum"
.." WHERE  t1.contype = 'p' AND length(t3.attname) > 0 AND  t2.oid = '"..sql_tablename.."' :: regclass group by t4.tablename"
local rkey = selectdata(sql_selectkey)	
       rkey = rkey[1].primarykeycolumn --��ȡ�����ַ��� mdate,mid  
 
--����keyֵ   

for j = 1 , table.maxn(sql_tabledata)  do 

--����vֵ
local sql_v = ""
local upsql = ""
--ȥ�����һ��\
     local mydata = string.sub(sql_tabledata[j],1,-2)	 
--�ٴ��и�,��ʱsplit_res4Ϊʵ�ʵ�ÿһ�е�ֵ������   
     local split_res4, split_err4 = ngx_re.split(mydata,",")
	 split_res4[1] = string.gsub(split_res4[1], "^%s*(.-)%s*$","%1")
	 ngx.say(split_res4[1])
--����һ���µ����飬������û�С�/N��
     local table_value = {}
	 local table_i = 1
     for m = 1,table.maxn(split_res4) do
	      if split_res4[m] ~= "\\".."\\N" and  split_res4[m] ~= nil then
		    table_value[table_i] = split_res4[m]
		--	ngx.say(split_res4[m])
			table_i = table_i+1	 
	      end
	  end   	 
  for l = 1,table.maxn(ret_new) do
          --ngx.say(ret_new[l].mtype)  
	     if ret_new[l].mtype == "date" or ret_new[l].mtype == "char" or ret_new[l].mtype == "varchar" or ret_new[l].mtype == "bpchar" or ret_new[l].mtype == "time" 
		 then		     
               sql_v = sql_v.."\'"..table_value[l].."\'"..","   
    --ƴupdate
               upsql = upsql..sql_update[l].."=".."\'"..table_value[l].."\'"..","	
			 else 
               sql_v = sql_v..table_value[l]..","
			   upsql = upsql..sql_update[l].."="..table_value[l]..","
             end         			 
  end	   	     
  sql_v = string.sub(sql_v,1,-2)
  upsql = string.sub(upsql,1,-2)

  local myaddsql = addsql..sql_v .. ")".." ON CONFLICT ("..rkey..") do update set "..upsql
  ngx.say(myaddsql)
  local abc = selectdata(addsql)
end
  
--��������
 -- 
 
  pg:keepalive()    








