local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
--��ȡget����
--ɾ������
local sql ="delete from hyplayer where id = "
--��ɾ�����ݣ���delete״̬��0��Ϊ1
--local sql ="update hyplayer set deleteif = 1 where id = "
local sql_k = " "
local sql_v = " "

local arg = ngx.req.get_uri_args()
for k,v in pairs(arg) do
if k == "id"  then
    v = "\'"..v.."\'"
 end
 sql_k = k
 sql_v = v
 --sql_k = sql_k .. "" .. k .. ","
 --sql_v = sql_v ..v .. ","
end
sql = sql .. sql_v

 ngx.say(sql_k)
 ngx.say(sql_v)
 ngx.say(sql)

if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      --core.log.info("error: ", err)
     ngx.say("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
      --core.response.exit(204, err) 
  else
  local ret = {}
     ret["ret"] = ok  
   ngx.say(cjson.encode(ret))
  end
  pg:keepalive()    
  --core.log.info("res: ", res)











