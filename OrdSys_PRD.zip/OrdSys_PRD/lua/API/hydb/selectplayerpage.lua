local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "hydb",
    user = "postgres",
    password = "112233"
  })
--offset为偏移量，假设每页为5条数据，查询第二页，则偏移量为5，公式为（查询页数-1）*偏移量
--local sql ="select * from hyplayer where deleteif = 0 limit 5 offset 2"
local sql ="select * from hyplayer where deleteif = 0 "
--每页展示的条数，默认展示5条
local sql_limit =5
--查询页数，默认显示第一页
local sql_page=1
--获取get请求
local arg = ngx.req.get_uri_args()
for k,v in pairs(arg) do
if k == "page"  then
    sql_page = v
 end
if k == "limit"  then
    sql_limit = v
 end 
end
local sql_offset =(sql_page-1)*sql_limit

sql = sql .. " limit " .. sql_limit .. " offset " .. sql_offset

ngx.say(sql_limit)
ngx.say(sql_page)
ngx.say(sql_offset)
ngx.say(sql)
if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      --core.log.info("error: ", err)
     ngx.say("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
      --core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
--ngx.say(res)
local player = cjson.encode(res)
ngx.say(player)

