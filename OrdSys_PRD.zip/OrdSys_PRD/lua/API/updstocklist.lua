local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local function stock2db (list)
  local pg, err = pgmoon.new({
  host = "127.0.0.1",
  port = "5432",
  database = "stockdb",
  user = "postgres",
  password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  
  local i = 0
  for k, row in ipairs(list) do
    if row["证券代码"] ~= "" then
      local re_res, re_err = ngx_re.split(row["证券代码"], "-")
      --insert into t_stock_list (f_code, f_market, f_date, f_name) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_code) do update set f_market='', f_date='', f_name='';
      local sql = "insert into t_stock_list (f_code, f_market, f_date, f_name, f_price_n) values(" .. pgsql_str(re_res[1]) .. "," .. pgsql_str(row["交易所"]) .. "," .. pgsql_str(row["交易日期"]) .. "," .. pgsql_str(row["证券简称"]) .. "," .. row["收盘价"] .. ") ON CONFLICT(f_code) do update set f_market=" .. pgsql_str(row["交易所"]) .. ", f_date=" .. pgsql_str(row["交易日期"]) .. ", f_name=" .. pgsql_str(row["证券简称"]) .. ", f_price_n=" .. row["收盘价"]


      --core.log.info("insert sql: ", sql)
      local insres, err = pg:query(sql)
      --local insres, err = core.pg.query(sql)
      
      if not insres then
          return 204, {errmsg = err}
      end
      
      --core.log.info("res: ", insres)
      i = i + 1
    end
  end
  
  pg:keepalive()
  pg = nil
  
  return i
end

ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()

--core.log.info("value.mcode: ", value["mcode"])
--core.log.info("value.tdate: ", value.tdate)
if not value.mcode then
    return 204, {msg = "wrong args"}
end

local uri = "http://webapi.cninfo.com.cn//api/sysapi/p_sysapi1007"

--获取深证列表
local res, err = core.http.request_uri(uri, {
    method = "POST",
    headers = {
        ["Content-Type"] = "application/x-www-form-urlencoded",
        ["Referer"] = "http://webapi.cninfo.com.cn/",
        ["mcode"] = value.mcode,
    },
    body = "tdate=" .. value.tdate .. "&market=SZE",
    ssl_verify = false,
})

if not res then
    return 500, err
end

if res.status >= 300 then
    return res.status, res.body
end

--core.log.info("res: ", res.body)
stock2db(core.json.decode(res.body).records)

--获取上证列表
local res, err = core.http.request_uri(uri, {
    method = "POST",
    headers = {
        ["Content-Type"] = "application/x-www-form-urlencoded",
        ["Referer"] = "http://webapi.cninfo.com.cn/",
        ["mcode"] = value.mcode,
    },
    body = "tdate=" .. value.tdate .. "&market=SHE",
    ssl_verify = false,
})

if not res then
    return 500, err
end

if res.status >= 300 then
    return res.status, res.body
end

--core.log.info("res: ", res.body)
stock2db(core.json.decode(res.body).records)

return 200, {msg = "successful run"}