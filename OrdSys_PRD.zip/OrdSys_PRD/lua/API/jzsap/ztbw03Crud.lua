--action = add ztbw03 ���ص�������dn
--action = delete ztbw03 ���ص���ɾ��dn
--action = unlock ztbw03 ���ص�dn���
local core = require("apisix.core")
local pgsql_str = core.pg.quote_pgsql_str
local session = require("admin.session")
local ngx = ngx
local config = require("apisix.core.config_local")
local sap_conf = config.sap_conf()
--local getSession = core.json.decode(session.getData("userData"))
local getSession = session.get()

if getSession == nil then
	--��ȡ���ʵ�url	  	  
	  local headers_tab = ngx.req.get_headers()
    --�ָ��ַ���
      local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
    --�õ����һ����  
      local myurl = split_res[table.maxn(split_res)] 
    --  core.log.info("myurl:",myurl)	    
	--��url����session
	  local res = session.setData(myurl,"url")   
	  local msg = {}
	  msg["msg"] = "no login"
	  core.response.exit(401, core.json.encode(msg))
else  
		-- ��ȡbody��Ϣ
		ngx.req.read_body()
--		local myData = ngx.req.get_body_data()
       local sapurl = sap_conf[getSession.f_company].home_uri
	   local sapClient = getSession.f_sap_client
       local sapFormat = getSession.f_sap_format

       local myData,argserr= ngx.req.get_post_args() 
		if myData == nil then
			 core.response.exit(400, argserr)
		end
		
		core.log.info("myData:",core.json.encode(myData))
		
		-- ��ȡǰ�˴������
		local dn = myData.dn               --DN
--		core.log.info("dn:",myData.dn)
		local zbglsh = myData.zbglsh           --���زݵ�
--		core.log.info("zbglsh:",myData.zbglsh)
		local action = myData.action           --����
--		core.log.info("action:",myData.action)
		
		
		local uname = ""
		if getSession.f_uname == nil then
			uname = "ZZH"
		else
			uname = getSession.f_uname
		end	
	
		local unamepass = "SAP_RFC_USR:Gp.1234567"

		-- ��ȡztbw03��token
		local url= sapurl.."ZSD_ODTAA_CRUD_SRV/ZTBW03_CRUDSet?$format=json"..sapClient
--			core.log.info("url: ", url)
  			local basic_auth = ngx.encode_base64(unamepass)
--			core.log.info("auth: ", basic_auth)
			local function getMethod(url,basic_auth)
				local res, err = core.http.request_uri(url, {
					  method = "GET",
					  headers = {
									["Authorization"] = "Basic " .. basic_auth,
									["Accept"] = "application/xml",
									["X-CSRF-Token"] = "fetch",                          --�ȸ���get��ʽ��ȡtoken
								},
					  ssl_verify = false,
				  })
				  
				  if not res then
					return 500, err
				  end
				  
				  if res.status >= 300 then
					core.log.info("Error Code from CDS call:",res.status)
					core.log.info("Error Code from CDS call:",err)
					return res.status, res.body
				  end
				  return res
		     end		  
--���dn��ֻ�����Ӳ���Ҫ���dn
		  if action == "add" then	 
			 local url1 = sapurl..'Z_LIKP_CDS/Z_LIKP?$filter=DeliveryDocument%20eq%20%27'..dn..'%27'..sapFormat..sapClient			 
			 local checkDn = getMethod(url1,basic_auth)
			 local checkDnData = core.json.decode(checkDn.body) 
			 if checkDnData.d.results[1] == nil then
				core.response.exit(400, "dn not in sap")
			 end		  	
		  end	 
			 local getData = getMethod(url,basic_auth)
			          			 
			 local token = getData.headers["X-CSRF-Token"]         --�õ�token	 
			 local setcookie = getData.headers["set-cookie"][2]    --��cookie �����ǲ�ȷ���Ƿ���Ҫ			 
					 
			local function ztbw03Crud(token,setcookie,confItem) 
				local urlztbw03a = sapurl.."ZSD_ODTAA_CRUD_SRV/ZTBW03_CRUDSet?"..sapClient
--�õ�token��ʹ��post��ʽ���������ص�̧ͷ			 
			 local res, err = core.http.request_uri(urlztbw03a, {
					method = "POST",
					headers = {
						["Authorization"] = "Basic " .. basic_auth,
						["content-type"] = "application/json",
					  --["Accept"] = "application/xml",
						["X-CSRF-Token"] = token,
						["Cookie"] = setcookie,
						["set-cookie"] = setcookie,
					},
					body = core.json.encode(confItem),
					ssl_verify = false,
				})
				                   
				if not res then
					return 500, err
				end

				if res.status >= 300 then
					return res.status, res.body
				end					
			end
--�������			
--�������ص�����Ŀ	action = add Zernam��Ϊ�գ�action = unlock Zlernam��Ϊ�գ�action = delete ��Ϊ��	
           local confItem = {}
             confItem["Zbglsh"] = zbglsh             --������ˮ�� 		                    
			 confItem["Posnr"] = ""                  --����Ŀ���ţ���sap���洦��                   
			 confItem["Zposnr"] = ""                 --���   
			 confItem["Zsddn"] = ""                  --�󶨱�ʶ 		
			 confItem["Zeerdat"] = nil
			 confItem["Zerzet"] = "PT00H00M00S"
			 confItem["Zleerdat"] = nil
			 confItem["Zlerzet"] = "PT00H00M00S"
			 confItem["Zbatchdn"] = ""	
			 
		   if action == "add" then
		     confItem["Zernam"] = uname 
		     confItem["Zlernam"] = ""
		   elseif  action == "unlock" then	
		     confItem["Zernam"] = ""
			 confItem["Zlernam"] = uname 
		   else
			 confItem["Zernam"] = ""
			 confItem["Zlernam"] = "" 
		   end	
			 
--		   for i=1,table.maxn(dn) do
			 confItem["Vbeln"] = dn                        --DN
			 if dn == nil then
				confItem["Vbeln"] = "XXX" 
			 end
			 core.log.info("dn:",confItem["Vbeln"])
		     
			 ztbw03Crud(token,setcookie,confItem) 
--		   end        	
			 
		core.response.exit(200,"success")	
			
		
end			
			 
			 