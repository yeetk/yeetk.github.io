local core = require("apisix.core")
local pgsql_str = core.pg.quote_pgsql_str
local session = require("admin.session")
local ngx_re = require "ngx.re"

local config = require("apisix.core.config_local")
local sap_conf = config.sap_conf()
--local getSession = core.json.decode(session.getData("userData"))
local getSession = session.get()
	
-- ��ȡǰ�˴������
	if getSession == nil then
	--��ȡ���ʵ�url	  	  
	  local headers_tab = ngx.req.get_headers()
	--�ָ��ַ���
	  local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
	--�õ����һ����  
	  local myurl = split_res[table.maxn(split_res)] 
	--  core.log.info("myurl:",myurl)	    
	--��url����session
	  local res = session.setData(myurl,"url")   
	  local msg = {}
	  msg["msg"] = "no login"
--	  core.response.exit(401, core.json.encode(msg))
	else  
		-- ��ȡbody��Ϣ
		ngx.req.read_body()		
		local sapurl = sap_conf[getSession.f_company].home_uri
--		core.log.info("Session",core.json.encode(getSession))
--��ʽ https://223.243.99.172:19443/sap/opu/odata/sap/		
--���� https://223.243.99.172:39443/sap/opu/odata/sap/
        local sapClient = getSession.f_sap_client
        local sapFormat = getSession.f_sap_format
--		core.log.info("sapClient:",sapClient)
--		core.log.info("sapFormat:",sapFormat)	   
--		core.log.info("sapurl:",sapurl)
		
		local myData,argserr= ngx.req.get_post_args() 
		if myData == nil then
			 core.response.exit(400, argserr)
		end
--		core.log.info("data:",core.json.encode(myData))
		
	    local uname = ""
		if getSession.f_uname == nil then
			uname = "ZZH"
		else
			uname = getSession.f_uname
		end
--       data = 	core.json.decode(data)	
		local dn = myData.DN                 --DN���ж��
		local TradeTerm = myData.TradeTerm          --ó�׷�ʽ
		local TrspMode = myData.TrspMode          --���䷽ʽ
		

--		core.log.info("DN:",core.json.encode(DN))
--		core.log.info("TradeTerm:",TradeTerm)
--		core.log.info("TrspMode:",TrspMode)


		--ngx.say("hello world")
		local unamepass = "SAP_RFC_USR:Gp.1234567"
		-- ��ȡztbw02��token
		local url= sapurl.."ZSD_ODTAA_CRUD_SRV/ZTBW02_CRUDSet?$format=json"..sapClient
--			core.log.info("url: ", url)
  			local basic_auth = ngx.encode_base64(unamepass)
--			core.log.info("auth: ", basic_auth)
            
			local function getMethod(url,basic_auth)
				local res, err = core.http.request_uri(url, {
					  method = "GET",
					  headers = {
									["Authorization"] = "Basic " .. basic_auth,
									["Accept"] = "application/xml",
									["X-CSRF-Token"] = "fetch",                          --�ȸ���get��ʽ��ȡtoken
								},
					  ssl_verify = false,
				  })
				  
				  if not res then
					return 500, err
				  end
				  
				  if res.status >= 300 then
					core.log.info("Error Code from CDS call:",res.status)
					core.log.info("Error Code from CDS call:",err)
					return res.status, res.body
				  end
					return res
			  end
--dn���ж���ö��ŷָ�
             local dnUrl = ""
			 local split_res, split_err = ngx_re.split(dn,",")
			 local dnNum = table.maxn(split_res)		 
			 for i=1,dnNum do			    
				if i==1 then
					dnUrl = split_res[i].."%27"
				else
					dnUrl = dnUrl.."%20or%20DeliveryDocument%20eq%20%27"..split_res[i].."%27"
				end				
			 end						 
--����֤dn�Ƿ���ڣ���dn�����ж�dn�����������˻��ǳ������ɲ�ͬ����ˮ��
		     local url1 = sapurl.."Z_LIKP_CDS/Z_LIKP?$filter=DeliveryDocument%20eq%20%27"..dnUrl..sapFormat..sapClient
--             core.log.info("url1:",url1)			 
			 local checkDn = getMethod(url1,basic_auth)			 
	         
			 local checkDnData = core.json.decode(checkDn.body).d.results			 
--��֤���͵�dn��ȡ���Ľ�������Ŀ�Ƿ�һ��,���в��죬�ҵ������ڵ��Ǹ�dn
			 local DnData = {}
--��鷵�������Ƿ�Ϊ��,��Ϊ��ֱ�ӷ���ʧ��
			 if checkDnData[1] == nil then
				core.response.exit(204, "dn"..dn.."not exist in sap")
			 end
--ȡ��һ��dntype			 
			 local dnType = checkDnData[1].DeliveryDocumentType
			 
--׼��һ��k��v���齫dn��dntype��ȡ����			 
			 for j=1,table.maxn(checkDnData) do
				 DnData[checkDnData[j].DeliveryDocument] = checkDnData[j].DeliveryDocumentType
--�����ڲ�ͬ��dntype�򷵻�ʧ��
				 if dnType ~= checkDnData[j].DeliveryDocumentType then
					core.response.exit(204, "Delivery DN and Return DN cannot exist at the same time")
				 end
			 end
			 
             if dnNum ~= table.maxn(checkDnData) then
				for i=1,dnNum do
					if DnData[split_res[i]] == nil then
						core.response.exit(204, "dn"..split_res[i].."not exist in sap")
					end										
				end
			 end	
			  
			 local getData = getMethod(url,basic_auth)
			 local getDataBody = {}
			 if getData ~= nil then
			  getDataBody = core.json.decode(getData.body) 
			 end
			 
			 local num = ""			 
--      		 core.log.info("res:",getData.body)
			 local lastZbglsh = ""
			 
             if getDataBody.d.results[1] ~= nil then
			 
			   local ztbw02Data = getDataBody.d.results 
--������������ȡ�����������µ���ˮ��  string.find(dn,",") Zbglsh
--���ݽ���������ȡ���˻����ͽ�������Zbglsh
               local a = 1
               local ZbglshData = {}
			   if dnType == "ZLF" then       --������
					for i=1,table.maxn(ztbw02Data) do
						if  string.find(ztbw02Data[i].Zbglsh,"T") == nil then
                            ZbglshData[a] = ztbw02Data[i].Zbglsh
							a = a+1
                        end                               												
					end
				else
					for i=1,table.maxn(ztbw02Data) do
						if  string.find(ztbw02Data[i].Zbglsh,"T") ~= nil then
							ZbglshData[a] = ztbw02Data[i].Zbglsh
							a = a+1
                        end                               												
					end					
				end
--				core.log.info("ZbglshData:",core.json.encode(ZbglshData))
--�������Ϊ�գ���num = 001
				local ZbglshData1 = {}
 				if ZbglshData == nil then
					num = "001"
				else						
--׼��һ���µ����飬���������������ִ������                			
					for i=1,table.maxn(ZbglshData) do
						ZbglshData1[i] = tonumber(string.sub(ZbglshData[i],-3))						
					end
			    
--               core.log.info("num:",core.json.encode(ZbglshData1))				
--����keyֵ��С��������
					for i = 1, #ZbglshData1 do
						for j = 1, #ZbglshData1-i do
							if ZbglshData1[j] > ZbglshData1[j+1] then
								local b = ZbglshData1[j]
								ZbglshData1[j] = ZbglshData1[j+1]
								ZbglshData1[j+1] = b
							end
						end
					end

		--                core.log.info("num:",core.json.encode(ZbglshData1))				
					for i=1,#ZbglshData1 do
						if i ~= ZbglshData1[i] then
							num = i
							break
						end
					end
					if num == "" then
						num = #ZbglshData1+1
					end
                end	      		   
				if num < 10  then
				   num = "00"..num
--				elseif num == 10 then
--				   num = "0"..num
				elseif 10 <= num  and num < 100 then
				   num = "0"..num
				end	
--[[			   
				if dnType == "ZLF" then       --������
					for i=1,table.maxn(ztbw02Data) do
						if  string.find(ztbw02Data[i].Zbglsh,"T") == nil then
							lastZbglsh = ztbw02Data[i].Zbglsh
							break
                        end                               												
					end
				else
					for i=1,table.maxn(ztbw02Data) do
						if  string.find(ztbw02Data[i].Zbglsh,"T") ~= nil then
							lastZbglsh = ztbw02Data[1].Zbglsh
							break
                        end                               												
					end					
				end
				
			   if lastZbglsh ~= "" then	
                   core.log.info("lastZbglsh1:",lastZbglsh)			   
				   num =  string.sub(lastZbglsh,-3)        --��ȡ��ˮ�ź���λ				   
				   num = tonumber(num) + 1                       --��ˮ��+1			   
					if num/10 < 1  then
					   num = "00"..num
					else
					   num = "0"..num
					end	
				else
					num = "001"
				end
--]]				
			else
				num = "001"
			end
	         core.log.info("num:",num)		 
			 local token = getData.headers["X-CSRF-Token"]         --�õ�token	 
			 local setcookie = getData.headers["set-cookie"][2]    --��cookie �����ǲ�ȷ���Ƿ���Ҫ			 
			 local mydate = os.date("%Y%m%d")  --��ȡ������
			 local newZbglsh = ""    --�����µı�����ˮ��
             core.log.info("dntype:",dnType)
			 if dnType == "ZLF" then   --����
				newZbglsh = "JZ"..mydate..num
			 else
               	newZbglsh = "JZT"..mydate..num
             end				
			 
			 
			 

--�������			 
			 local confHeader = {} 
			 confHeader["Zbglsh"] = newZbglsh           --������ˮ�� JZ+��+��+��+��λ��ˮ��
			 confHeader["Zsbrq"] = nil 
			 confHeader["Bokno"] = ""                   --���ص��Ȳ���
			 confHeader["Zbgdh"] = ""
			 confHeader["Zhzqd"] = ""
			 confHeader["Zmyfs"] = TradeTerm            --�걨��ʽ ���ݴ��λ�ȡ
			 confHeader["Zysfs"] = TrspMode             --ó�׷�ʽ ���ݴ��λ�ȡ
			 confHeader["Zbgh"] =  ""            --������
			 confHeader["Zjgzt"] = ""             --���״̬
			 confHeader["Zernam"] = uname               --������   ����session��ȡ������
			 confHeader["Zeerdat"] = nil
			 confHeader["Zerzet"] = "PT00H00M00S"
			 confHeader["Zlernam"] = ""
			 confHeader["Zleerdat"] = nil
			 confHeader["Zlerzet"] = "PT00H00M00S"
			 
--			 core.log.info("conf:",core.json.encode(conf))
			 
			 local urlCreate = sapurl.."ZSD_ODTAA_CRUD_SRV/ZTBW02_CRUDSet?"..sapClient
--�õ�token��ʹ��post��ʽ���������ص�̧ͷ			 
			 local res, err = core.http.request_uri(urlCreate, {
					method = "POST",
					headers = {
						["Authorization"] = "Basic " .. basic_auth,
						["content-type"] = "application/json",
					  --["Accept"] = "application/xml",
						["X-CSRF-Token"] = token,
						["Cookie"] = setcookie,
						["set-cookie"] = setcookie,
					},
					body = core.json.encode(confHeader),
					ssl_verify = false,
				})
				
                   
				if not res then
					return 500, err
				end

				if res.status >= 300 then
					return res.status, res.body
				end		

--�������ص�����Ŀ		
           local confItem = {}
             confItem["Zbglsh"] = newZbglsh           --������ˮ�� JZ+��+��+��+��λ��ˮ��
			 confItem["Vbeln"] = ""                   --DN
			 confItem["Posnr"] = ""                   --����Ŀ���ţ���sap���洦��                   
			 confItem["Zposnr"] = ""                 --���   
			 confItem["Zsddn"] = ""                  --�󶨱�ʶ 
             confItem["Zbatchdn"] = "" 
			 confItem["Zernam"] = uname               --������   ����session��ȡ������
			 confItem["Zeerdat"] = nil
			 confItem["Zerzet"] = "PT00H00M00S"
			 confItem["Zlernam"] = ""
			 confItem["Zleerdat"] = nil
			 confItem["Zlerzet"] = "PT00H00M00S"	
			 
			local function ztbw03Create(confItem) 
				local urlztbw03a = sapurl.."ZSD_ODTAA_CRUD_SRV/ZTBW03_CRUDSet?"..sapClient
	--�õ�token��ʹ��post��ʽ���������ص�̧ͷ			 
				 local res, err = core.http.request_uri(urlztbw03a, {
						method = "POST",
						headers = {
							["Authorization"] = "Basic " .. basic_auth,
							["content-type"] = "application/json",
						    ["Accept"] = "application/json",
							["X-CSRF-Token"] = token,
							["Cookie"] = setcookie,
							["set-cookie"] = setcookie,
						},
						body = core.json.encode(confItem),
						ssl_verify = false,
					})
									   
					if not res then
						return 500, err
					end

					if res.status >= 300 then
						return res.status, res.body
					end	
--				core.log.info("res:",res.body)	
--				core.log.info("res:",res.status)	
		

		   end

		  
		  if(string.find(dn,",") ~= nil) then			                        
			 confItem["Zbatchdn"] = dn
		  else
			 confItem["Vbeln"] = dn 
	      end
--          core.log.info("vbeln:",confItem["Vbeln"])		  
		  
			 
--		   end  
		  ztbw03Create(confItem) 
		   
								
--����DN��			
			core.response.exit(200,"success:"..newZbglsh)
end			
			 
			 