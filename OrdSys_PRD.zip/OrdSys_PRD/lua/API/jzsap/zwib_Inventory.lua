local core = require("apisix.core")
local pgsql_str = core.pg.quote_pgsql_str
local session = require("admin.session")
local ngx_re = require "ngx.re"

local config = require("apisix.core.config_local")
local sap_conf = config.sap_conf()
--local getSession = core.json.decode(session.getData("userData"))
local getSession = session.get()
	
-- ��ȡǰ�˴������
	if getSession == nil then
	--��ȡ���ʵ�url	  	  
	  local headers_tab = ngx.req.get_headers()
	--�ָ��ַ���
	  local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
	--�õ����һ����  
	  local myurl = split_res[table.maxn(split_res)] 
	--  core.log.info("myurl:",myurl)	    
	--��url����session
	  local res = session.setData(myurl,"url")   
	  local msg = {}
	  msg["msg"] = "no login"
--	  core.response.exit(401, core.json.encode(msg))
	else  
		-- ��ȡbody��Ϣ
--		ngx.req.read_body()
--       core.log.info("getSession:",getSession)	
	    local sapurl = ""
	    local sapClient = ""
		if getSession ~= false then
		 
			sapurl = sap_conf[getSession.f_company].home_uri
	--		core.log.info("Session",core.json.encode(getSession))
	--��ʽ https://223.243.99.172:19443/sap/opu/odata/sap/		
	--���� https://223.243.99.172:39443/sap/opu/odata/sap/
		    sapClient = getSession.f_sap_client
			local sapFormat = getSession.f_sap_format
	--		core.log.info("sapClient:",sapClient)
	--		core.log.info("sapFormat:",sapFormat)	   
	--		core.log.info("sapurl:",sapurl)
	    else
		    sapurl = 'https://223.243.99.172:39443/sap/opu/odata/sap/'
			sapClient = '&sap-client=130'			
		end	
	  
	   
--       data = 	core.json.decode(data)	

		local unamepass = "SAP_RFC_USR:Gp.1234567"
		-- ��ȡztbw02��token
		local url= sapurl.."Z_WIB_TABLE_CDS/Z_WIB_TABLE?$format=json"..sapClient
--			core.log.info("url: ", url)
  			local basic_auth = ngx.encode_base64(unamepass)
--			core.log.info("auth: ", basic_auth)
            
			local function getMethod(url,basic_auth)
				local res, err = core.http.request_uri(url, {
					  method = "GET",
					  headers = {
									["Authorization"] = "Basic " .. basic_auth,
									["Accept"] = "application/xml",
									["X-CSRF-Token"] = "fetch",                          --�ȸ���get��ʽ��ȡtoken
								},
					  ssl_verify = false,
				  })
				  
				  if not res then
					return 500, err
				  end
				  
				  if res.status >= 300 then
					core.log.info("Error Code from CDS call:",res.status)
					core.log.info("Error Code from CDS call:",err)
					return res.status, res.body
				  end
					return res.body
			 end
			 
			 
			 local wibData = core.json.decode(getMethod(url,basic_auth)).d.results
--����תԭ������			 			 
			 for i=1,table.maxn(wibData) do
				if wibData[i].dh ~= "" then
					wibData[i].ztcmng = wibData[i].ztcmng * tonumber(wibData[i].dh)					
				end	
			 end
			 for k=1,table.maxn(wibData) do			
               
--ȥ��cocod1��cncod2��ǰ��0				
				   wibData[k].cncod1 = wibData[k].cncod1:match("^[0]*(.-)[%s]*$")
				   wibData[k].cncod2 = wibData[k].cncod2:match("^[0]*(.-)[%s]*$")
--תԭ������������λС��					   
				   wibData[k].ztcmng = string.format("%.3f",wibData[k].ztcmng)  					
				   wibData[k].dh = string.format("%.3f",wibData[k].dh)  					
				
			 end
			 
			 local j = 1
			 while j<=table.maxn(wibData) do
				wibData[j].__metadata = nil
				j = j + 1
			 
			 end
			 
			 								
--����DN��			
			core.response.exit(200,core.json.encode(wibData))
	end		
			 
			 