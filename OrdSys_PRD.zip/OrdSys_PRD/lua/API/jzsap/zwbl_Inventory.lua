local core = require("apisix.core")
local pgsql_str = core.pg.quote_pgsql_str
local session = require("admin.session")
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")
local config = require("apisix.core.config_local")
local sap_conf = config.sap_conf()
--local getSession = core.json.decode(session.getData("userData"))
local getSession = session.get()
	
-- ��ȡǰ�˴������
	if getSession == nil then
	--��ȡ���ʵ�url	  	  
	  local headers_tab = ngx.req.get_headers()
	--�ָ��ַ���
	  local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
	--�õ����һ����  
	  local myurl = split_res[table.maxn(split_res)] 
	--  core.log.info("myurl:",myurl)	    
	--��url����session
	  local res = session.setData(myurl,"url")   
	  local msg = {}
	  msg["msg"] = "no login"
--	  core.response.exit(401, core.json.encode(msg))
	else  
--       ngx.req.read_body()		
--	 local myData,argserr= ngx.req.get_post_args() 
--		if myData == nil then
--			 core.response.exit(400, argserr)
--		end
--		local bokno = myData.bokno
        local arg = ngx.req.get_uri_args()
		local bokno = ""
		for k,v in pairs(arg) do
			if k == "bokno"  then
				bokno = v
			end
		end
--		core.log.info("bokno:",bokno)
 
--		core.log.info("bokno1:",bokno)
		-- ��ȡbody��Ϣ
--		ngx.req.read_body()
--       core.log.info("getSession:",getSession)	
        local sapurl = ""
	    local sapClient = ""
		if getSession ~= false then
		 
		    sapurl = sap_conf[getSession.f_company].home_uri
	--		core.log.info("Session",core.json.encode(getSession))
	--��ʽ https://223.243.99.172:19443/sap/opu/odata/sap/		
	--���� https://223.243.99.172:39443/sap/opu/odata/sap/
			sapClient = getSession.f_sap_client
			local sapFormat = getSession.f_sap_format
	--		core.log.info("sapClient:",sapClient)
	--		core.log.info("sapFormat:",sapFormat)	   
	--		core.log.info("sapurl:",sapurl)
	    else
		    sapurl = 'https://223.243.99.172:39443/sap/opu/odata/sap/'
			sapClient = '&sap-client=130'			
		end	
	  
	   
--       data = 	core.json.decode(data)	

		local unamepass = "SAP_RFC_USR:Gp.1234567"
		-- ��ȡztbw02��token
		local url= sapurl.."Z_WBL_TABLE_CDS/Z_WBL_TABLE?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient
		
		local url1= sapurl.."Z_WBL_01_CDS/Z_WBL_01?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient
		local url1t= sapurl.."Z_WBL_01_T_CDS/Z_WBL_01_T?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient		
		
		local url2= sapurl.."Z_WBL_02_CDS/Z_WBL_02?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient
		local url2t= sapurl.."Z_WBL_02_T_CDS/Z_WBL_02_T?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient
		local url4= sapurl.."Z_WBL_04_CDS/Z_WBL_04?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient
		local url6= sapurl.."Z_WBL_06_CDS/Z_WBL_06?".."$filter=bokno%20eq%20%27"..bokno.."%27&$format=json"..sapClient
--			core.log.info("url: ", url)
  			local basic_auth = ngx.encode_base64(unamepass)
--			core.log.info("auth: ", basic_auth)
            
			local function getMethod(url,basic_auth)
				local res, err = core.http.request_uri(url, {
					  method = "GET",
					  headers = {
									["Authorization"] = "Basic " .. basic_auth,
									["Accept"] = "application/xml",
									--["X-CSRF-Token"] = "fetch",                          --�ȸ���get��ʽ��ȡtoken
								},
					  ssl_verify = false,
				  })
				  
				  if not res then
            return 500, err
				  end
				  
				  if res.status >= 300 then
            core.log.info("Error Code from CDS call:",res.status)
            core.log.info("Error Code from CDS call:",err)
            return res.status, res.body
				  end
					return res.body
			 end
      
			local mySql = "select bokno,cncod,zqcqty,zztqty from t_gp_04 where bokno = '"..bokno.."'"
			local sqlRes = db.selectBySql(mySql)

			 
			 
			 local wblData = core.json.decode(getMethod(url,basic_auth)).d.results
			 --core.log.info("wblData:",core.json.encode(wblData[1]))
			 local wblData1 = core.json.decode(getMethod(url1,basic_auth)).d.results
			 local wblData1t = core.json.decode(getMethod(url1t,basic_auth)).d.results
			 
			 local wblData2 = core.json.decode(getMethod(url2,basic_auth)).d.results
			 local wblData2t = core.json.decode(getMethod(url2t,basic_auth)).d.results
			 local wblData4 = core.json.decode(getMethod(url4,basic_auth)).d.results --�ֿⱣ˰��Ʒ����
			 local wblData6 = core.json.decode(getMethod(url6,basic_auth)).d.results --��˰ԭ�Ŀ���
--��������			 			 
			 for i=1,table.maxn(wblData) do
--				if wblData[i].dh ~= "" then
--					wblData[i].quantity = wblData[i].quantity * tonumber(wblData[i].dh)
--				end
				
--				if wblData[i].dh1 ~= "" then
--					wblData[i].tquantity = wblData[i].tquantity * tonumber(wblData[i].dh1)
--				end
				wblData[i]["zlabst"] = 0
				wblData[i]["psmng"] = 0
				wblData[i]["quantity"] = 0
				wblData[i]["tquantity"] = 0
				
				wblData[i]["wemng"] = 0
				wblData[i]["zwemng"] = 0
				wblData[i]["menge"] = 0
				
				for o=1,table.maxn(wblData1) do
				 if wblData[i].barea == wblData1[o].werks and wblData[i].bokno == wblData1[o].bokno and wblData[i].cncod == wblData1[o].cncod then
						wblData[i].wemng = wblData[i].wemng + wblData1[o].wemng 
						wblData[i].menge = wblData[i].menge + wblData1[o].wemng - wblData1[o].menge
				 end				
				end
				
				
				for p=1,table.maxn(wblData1t) do
				
				 if wblData[i].barea == wblData1t[p].werks and wblData[i].bokno == wblData1t[p].bokno and wblData[i].cncod == wblData1t[p].cncod then
						wblData[i].zwemng = wblData[i].zwemng + wblData1t[p].zwemng 
						
				 end				
				end
				
				
				for m=1,table.maxn(wblData2) do
				 if wblData[i].barea == wblData2[m].Plant and wblData[i].bokno == wblData2[m].bokno and wblData[i].cncod == wblData2[m].cncod2 then
					if wblData2[m].dh ~= "" then
						wblData[i].quantity = wblData[i].quantity + wblData2[m].ActualDeliveryQuantity * tonumber(wblData2[m].dh)
					end	
				 end				
				end
				
				for n=1,table.maxn(wblData2t) do
				 if wblData[i].barea == wblData2t[n].Plant and wblData[i].bokno == wblData2t[n].bokno and wblData[i].cncod == wblData2t[n].cncod2 then
					if wblData2t[n].dh ~= "" then
						wblData[i].tquantity = wblData[i].tquantity + wblData2t[n].ActualDeliveryQuantity * tonumber(wblData2t[n].dh)
					end	
				 end				
				end
				
				
				for j=1,table.maxn(wblData4) do
				 if wblData[i].barea == wblData4[j].werks and wblData[i].bokno == wblData4[j].bokno and wblData[i].cncod == wblData4[j].cncod2 then
					if wblData4[j].dh ~= "" then
						wblData[i].zlabst = wblData[i].zlabst + wblData4[j].labst * tonumber(wblData4[j].dh)
					end	
				 end				
				end
				
				for k=1,table.maxn(wblData6) do
				 if wblData[i].barea == wblData6[k].dwerk and wblData[i].bokno == wblData6[k].bokno and wblData[i].cncod == wblData6[k].cncod2 then
					if wblData6[k].dh ~= nil then
--					core.log.info("dh:",wblData6[k].dh3)
						wblData[i].psmng = wblData[i].psmng + (wblData6[k].psmng - wblData6[k].wemng) * tonumber(wblData6[k].dh)
					end	
				 end				
				end
				
				
--				if wblData[i].dh2 ~= "" then
--					wblData[i].zlabst = wblData[i].zlabst * tonumber(wblData[i].dh2)
--				end
--				if wblData[i].dh3 ~= "" then
--					wblData[i].psmng = wblData[i].psmng * tonumber(wblData[i].dh3)
--				end
                wblData[i]["zqcqty"] = 0				
                wblData[i]["zztqty"] = 0	
                --ȥǰ��0
			   wblData[i].cncod = wblData[i].cncod:match("^[0]*(.-)[%s]*$")	
                if sqlRes ~= nil then			   
					if next(sqlRes) ~= nil then
						for j=1,table.maxn(sqlRes) do
							if wblData[i].cncod == sqlRes[j].cncod then
							   wblData[i].zqcqty = sqlRes[j].zqcqty
							   wblData[i].zztqty = sqlRes[j].zztqty						   
							end  
						end
					end
				end

--������λС�� 
               wblData[i].wemng = string.format("%.3f",wblData[i].wemng)			   
               wblData[i].zwemng = string.format("%.3f",wblData[i].zwemng)			   
               wblData[i].quantity = string.format("%.3f",wblData[i].quantity)			   
               wblData[i].tquantity = string.format("%.3f",wblData[i].tquantity)			   
               wblData[i].labst = string.format("%.3f",wblData[i].labst)			   
               wblData[i].menge = string.format("%.3f",wblData[i].menge)			   
               wblData[i].zlabst = string.format("%.3f",wblData[i].zlabst)			   
               wblData[i].m53jlabst = string.format("%.3f",wblData[i].m53jlabst)			   
               wblData[i].psmng = string.format("%.3f",wblData[i].psmng)			   
               wblData[i].zqcqty = string.format("%.3f",wblData[i].zqcqty)			   
               wblData[i].zztqty = string.format("%.3f",wblData[i].zztqty)
			   
               wblData[i]["ztsbsi"] = wblData[i].zqcqty+wblData[i].wemng+wblData[i].zwemng-wblData[i].quantity+wblData[i].tquantity	
			   wblData[i]["zsumin"] = wblData[i].labst+wblData[i].menge+wblData[i].zlabst-wblData[i].zztqty+wblData[i].m53jlabst-wblData[i].psmng
			   wblData[i]["zdiffer"] = wblData[i].ztsbsi-wblData[i].zsumin
			   
			   wblData[i].ztsbsi = string.format("%.3f",wblData[i].ztsbsi)
			   wblData[i].zsumin = string.format("%.3f",wblData[i].zsumin)
			   wblData[i].zdiffer = string.format("%.3f",wblData[i].zdiffer)
			   
			   
			 end

             			 
			 local j = 1
			 while j<=table.maxn(wblData) do
				wblData[j].__metadata = nil
--				wblData[j].dh = nil
--				wblData[j].dh1 = nil
--				wblData[j].dh2 = nil
--				wblData[j].dh3 = nil
				j = j + 1			 
			 end

--����DN��			
      --core.log.info("wblData:",core.json.encode(wblData[1]))
			core.response.exit(200,core.json.encode(wblData))
      --ngx.say(core.json.encode(wblData))
	end		
			 
			 