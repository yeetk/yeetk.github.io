--�����ύ�ı����������ݿ��б�����
local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local session = require("admin.session")��
local db = require("db_ordsys")

local getSession = session.get()
	
-- ��ȡǰ�˴������
	if getSession == nil then
	--��ȡ���ʵ�url	  	  
		local headers_tab = ngx.req.get_headers()
	--�ָ��ַ���
		local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
	--�õ����һ����  
		local myurl = split_res[table.maxn(split_res)] 
	--  core.log.info("myurl:",myurl)	    
	--��url����session
		local res = session.setData(myurl,"url")   
		local msg = {}
		msg["msg"] = "no login"
	--	  core.response.exit(401, core.json.encode(msg))
	else 
        ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
	    local res,reqerr= ngx.req.get_post_args() --��ȡpost
--		core.log.info("res:",cjson.encode(res.data))
		local myData = ""
        		
--Bokno,Cncod,Zqcqty,Zztqty	
        for k,v in pairs(res) do
			k = cjson.decode(k)
			myData = k.arrB
		end	
		
		
		local uname = ""
		if getSession then
			uname = getSession.f_uname
		else
			uname = "ZZH"
			
		end
		local myDate = os.date("%Y%m%d");
		local myTime = os.date("%H%M%S");
--		core.log.info("date:",myDate)
--		core.log.info("time:",myTime)
			
		
		
		 local table_k = {}
		 
		 local insert_k = ""
		 for i = 1,table.maxn(myData) do
		     myData[i].Zqcqty = tonumber(myData[i].Zqcqty)
		     myData[i].Zztqty = tonumber(myData[i].Zztqty)
			 insert_k = "('"..myData[i].Bokno.."','"..myData[i].Cncod.."',"..myData[i].Zqcqty..","..myData[i].Zztqty..",'"..uname.."','"..myDate.."','"..myTime.."')"		 		 
		--׼��һ��k�����飬��׼��һ��v������
			 table.insert(table_k,insert_k)
		 end

		
		local mySql = "insert into  t_gp_04  (Bokno,Cncod,Zqcqty,Zztqty,Zernam,Zeerdat,Zerzet) values " .. table.concat(table_k,",") .. " on conflict(Bokno,Cncod) do update set (Zqcqty,Zztqty,Zlernam,Zleerdat,Zlerzet) = (EXCLUDED.Zqcqty,EXCLUDED.Zztqty,EXCLUDED.Zernam,EXCLUDED.Zeerdat,EXCLUDED.Zerzet)"	
--		core.log.info("sql: ", mySql)
		local mysqlRes = db.selectBySql(mySql)  --����sql
		
        core.response.exit(200,"success")
end		

	


   








