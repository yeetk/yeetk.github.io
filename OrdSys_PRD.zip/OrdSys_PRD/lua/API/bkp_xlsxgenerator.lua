local Workbook = require "xlsxwriter.workbook"


-- Create a workbook and add a worksheet.
local workbook  = Workbook:new("/usr/local/OrdSys/file/报关文件hs001.xlsx")
local worksheet = workbook:add_worksheet("报关单草单")

-- Some data we want to write to the worksheet.
local expenses = {
  {"LIPS-MATNR", "ZBW20-CNCOD", "ZBW19-CNDES", "ZBW19-CNCOD", "LIPS-LFIMG", "ZBW19-MEINS", 0, "VBAP-NETPR/VBAP-KPEIN", "数量*净单价",  "VBAK-CMWAE"},
  {"LIPS-MATNR", "ZBW20-CNCOD", "ZBW19-CNDES", "ZBW19-CNCOD", "LIPS-LFIMG", "ZBW19-MEINS", 0, "VBAP-NETPR/VBAP-KPEIN", "数量*净单价",  "VBAK-CMWAE"},
}

-- Start from the first cell. Rows and columns are zero indexed.

local merge_format = workbook:add_format({align = "center"})
local merge_10 = workbook:add_format({align = "left"})
local merge_16 = merge_format
local right_border = workbook:add_format({align = "left"})
merge_10:set_font_size(10)
merge_10:set_border(1)
merge_10:set_border_color("black")
right_border:set_right(1)
right_border:set_border_color("black")
merge_16:set_font_size(16)
merge_16:set_text_wrap()

worksheet:set_column("B:B", 19)
worksheet:set_column("C:C", 13)
worksheet:set_column("D:D", 19)
worksheet:set_column("E:E", 19)
worksheet:set_column("F:F", 13)

worksheet:merge_range("A1:K2", "Lu'an Zhuo Lixin Optical Technology Co., Ltd\r\n六安卓立信光科技有限责任公司", merge_16)
--worksheet:merge_range("A1:K2", "=CONCATENATE('Lu'an Zhuo Lixin Optical Technology Co., Ltd',CHAR(10),'六安卓立信光科技有限责任公司')", merge_16)
--worksheet:merge_range("A2:K2", "", merge_16)
worksheet:merge_range("A4:K4", "Export apply sheet in Chinese Code", merge_16)

worksheet:merge_range("A5:B5", "Ledger No:", merge_10)
worksheet:merge_range("C5:E5", "", merge_10)
worksheet:write("F5", "Invoice No:", merge_10)
worksheet:merge_range("G5:H5", "", merge_10)
worksheet:write("I5", "", merge_10)
worksheet:write("J5", "申报日期:", merge_10)
worksheet:write("K5", "", merge_10)

worksheet:merge_range("A6:D6", "经营单位：六安卓立信光科技工厂3401261030", merge_10)
worksheet:write("K6", "", right_border)
worksheet:merge_range("A7:D7", "发货单位：精卓光电合肥工厂3401261070", merge_10)
worksheet:write("K7", "", right_border)

worksheet:merge_range("A8:E8", "Ship to：CN", merge_10)
worksheet:write("F8", "成交方式：", merge_10)
worksheet:write("G8", "", merge_10)
worksheet:write("H8", "", merge_10)
worksheet:write("I8", "", merge_10)
worksheet:write("J8", "", merge_10)
worksheet:write("K8", "", merge_10)

worksheet:merge_range("A9:B9", "件数：", merge_10)
worksheet:merge_range("D9:E9", "毛重：", merge_10)
worksheet:merge_range("G9:H9", "净重：", merge_10)
worksheet:write("I9", "", merge_10)
worksheet:write("J9", "", merge_10)
worksheet:write("K9", "", merge_10)

worksheet:write("A10", "序号", merge_10)
worksheet:write("B10", "料号", merge_10)
worksheet:write("C10", "手册项号", merge_10)
worksheet:write("D10", "品名", merge_10)
worksheet:write("E10", "HS code", merge_10)
worksheet:write("F10", "数量", merge_10)
worksheet:write("G10", "单位", merge_10)
worksheet:write("H10", "净重", merge_10)
worksheet:write("I10", "单价", merge_10)
worksheet:write("J10", "总价", merge_10)
worksheet:write("K10", "币制", merge_10)

local row = 10
local col = 1

-- Iterate over the data and write it out element by element.
for _, expense in ipairs(expenses) do
  worksheet:write(row, 0, row-9, merge_10)
  for i, v in ipairs(expense) do
    worksheet:write(row, i, v, merge_10)
  end
  --[[
  local item, cost = unpack(expense)
  worksheet:write(row, col,     item)
  worksheet:write(row, col + 1, cost)
  --]]
  row = row + 1
end

-- Write a total using a formula.
worksheet:write(row, 0, "", merge_10)
worksheet:write(row, 1, "", merge_10)
worksheet:write(row, 2, "", merge_10)
worksheet:write(row, 3, "", merge_10)
worksheet:write(row, 4, "", merge_10)
worksheet:write(row, 5, "", merge_10)
worksheet:write(row, 6, "总净重：", merge_10)
local sumtab = {"=SUM(H11:H", row , ")"}
local sumf = table.concat(sumtab)
worksheet:write(row, 7, sumf, merge_10)
sumtab = {"=SUM(J11:J", row , ")"}
sumf = table.concat(sumtab)
worksheet:write(row, 8, "总价合计：", merge_10)
worksheet:write(row, 9, sumf, merge_10)
worksheet:write(row, 10, "", merge_10)

workbook:close()