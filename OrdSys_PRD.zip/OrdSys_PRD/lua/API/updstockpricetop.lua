local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

--更新数据库
local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.log.info("sql: ", sql)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end


local isql = "select * from t_position where f_selldate is null"
local selres, selerr = stockdb(isql)

local preuri = "https://data.gtimg.cn/flashdata/hushen/latest/daily/"

---[[
for k, row in ipairs(selres) do
    --core.log.info("updating:",row.f_code)
    
    --local uri = preuri .. string.lower(string.sub(row.f_market,1,2)) .. row.f_code .. ".js"
    local stockcode = tonumber(row.f_code)
    local market = "sz"
    if stockcode > 499999 then
      market = "sh"
    end
    local uri = preuri .. market .. row.f_code .. ".js"
    local res, err = core.http.request_uri(uri, {
        method = "GET",
        headers = {
            ["Content-Type"] = "application/javascript",
            ["Referer"] = "http://data.gtimg.cn/",
            --["mcode"] = value.mcode,
        },
        --body = "mergerMark=sysapi1075&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if not res then
      --return 500, err
      core.log.info(500, err)
    end

    --core.log.info("res: ", res.body)
    local split_res, split_err = ngx_re.split(res.body,"\n")
    
    
    if #split_res > 3 then
    
      row.f_price_top = row.f_price_top or 0
      for l=#split_res-1,3,-1 do
        local split_day, day_err = ngx_re.split(string.sub(split_res[l],1,-4)," ")
        --split_day = {日期，开，收，高，低，量}
        --core.log.info(split_day)
        local split_yesterday, yesterday_err = ngx_re.split(string.sub(split_res[l-1],1,-4)," ")
        
        local idate = tonumber("20" .. split_day[1]) or 0
        --core.log.info(row.f_code .. "~" .. idate)
        local buydate, t =  string.gsub(tostring(row.f_date),"-","")
        --core.log.info(row.f_date)
        --core.log.info(tostring(row.f_date))
        --core.log.info(string.gsub(tostring(row.f_date),"-","",2))
        if idate  > tonumber(buydate) then
          local todaystart = tonumber(split_day[2]) or 0
          local todayhigh = tonumber(split_day[4]) or 0
          local todayend = tonumber(split_day[3]) or 0
          local todaylow = tonumber(split_day[5]) or 0
          --local yesterdayend = tonumber(split_yesterday[3]) or 0
          --local yesterdayhigh = tonumber(split_yesterday[4]) or 0
          
          if todayhigh > row.f_price_top then
            row.f_price_top = todayhigh
          end
        end --end of if

      end --end of for loop
      isql = "UPDATE t_position SET f_price_top=" .. row.f_price_top .. " where f_sn = " .. row.f_sn
      --core.log.info("code-%s: %s", row.f_sn,isql)
      local updres, upderr = stockdb(isql)

    end -- end of if
    
end
--]]
--core.response.exit(200, core.json.encode(selres))