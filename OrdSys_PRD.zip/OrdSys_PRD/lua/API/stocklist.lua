local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

--读取返回Stock List，同比、环比收入增长，连涨天数

local function pgmoondb (sql)
  local pg, pgerr = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    ssl = false,
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", pgerr)
  end
  local ok, connerr = pg:connect()
  --assert(pg:connect())
  
  ---[[
  if not ok then
      --return nil, err
      core.log.info("error: ", connerr)
  end
  --core.log.info("sql: ", sql)
  --]]
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

--[[
local function postgresdb (sql)
  
end
--]]
local isql = "select f_market,f_code,f_name from t_stock_list"
local selres, selerr = pgmoondb(isql)

core.response.exit(200, core.json.encode(selres))