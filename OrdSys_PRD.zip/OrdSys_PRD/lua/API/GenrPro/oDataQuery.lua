local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")
local config = require("apisix.core.config_local")

local sapurl = ""
local myformat = ""
local myclient = ""

local sap_conf = config.sap_conf()
local unamepass = ""


local getSession = session.get()
if not getSession then
	  	  
  local headers_tab = ngx.req.get_headers()
  
  --local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
  
  --local myurl = split_res[table.maxn(split_res)] 
  --  core.log.info("myurl:",myurl)	    
  
  --local res = session.setData(myurl,"url")
  --local msg = {}
  --msg["msg"] = "not login or No Authorization"
  --core.response.set_header("Location", headers_tab.origin .. "/login.html")
  core.response.exit(401)
else  
	--sapurl = getSession.f_sap_url
  sapurl = sap_conf[getSession.f_company].home_uri
	myformat = getSession.f_sap_format
	myclient = getSession.f_sap_client
	--unamepass = getSession.f_uname .. ":" .. getSession.f_passwd
	unamepass = sap_conf[getSession.f_company].sap_uname .. ":" .. sap_conf[getSession.f_company].sap_passwd
	--
	local function getDataByUrl(master_odata, master_entity, fieldData, orderby) 
	--
	--			url = "https://erpdev.sbs.com.cn/sap/opu/odata/sap"..master_odata..master_entity.."?$filter=contains("..master_field..",%27"..fieldData.."%27&$format=json&sap-client=100"

			local url = sapurl .. master_odata .. "/" .. master_entity .. "?$filter=" .. fieldData .. myformat .. myclient --.. "&$orderby=SalesOrder,SalesOrderItem"
      if orderby then
        url = url .. "&$orderby=" .. ngx.escape_uri(orderby)
      end
      --url = ngx.escape_uri(url)
	--		ngx.say(url)
			core.log.info("url: ", url)
			local basic_auth = ngx.encode_base64(unamepass)
	--		core.log.info("auth: ", basic_auth)
			local cdsres, err = core.http.request_uri(url, {
				  method = "GET",
				  headers = {
					  ["Authorization"] = "Basic " .. basic_auth,   
					  ["Accept"] = "application/xml",
	--				  ["Content-Type"] = "application/json; charset=utf-8",		
				  },
				  ssl_verify = false,
			  })
			  
			  if not cdsres then
				return 500, err
			  end

			  if cdsres.status >= 300 then
          core.log.info("Error Code from CDS call:",cdsres.status)
          core.log.info("Error Code from CDS call:",err)
          core.response.exit(cdsres.status, err)
          --return cdsres.status, cdsres.body
			  end
			  --ngx.say(cdsres.body)
			  return core.json.decode(cdsres.body)
	end	
	
	local function timeConversion(myTime)
		return os.date("%Y-%m-%d %H:%M:%S", myTime)
	end
	 
	ngx.req.read_body() 
	local post_args,argserr= ngx.req.get_post_args() 
	if  post_args == nil then
    ngx.say("err:", argserr)
	end
	--core.log.info("post_args:",core.json.encode(post_args))

	local myFieldData = ""
  myFieldData = ngx.escape_uri(post_args.condition)
	--core.log.info("FieldDATA:", myFieldData)
  
  --local odata = post_args.odata
  --local entity = "/" .. post_args.entity
  
  local cdsData = getDataByUrl(post_args.odata, post_args.entity, myFieldData, post_args.orderby)
	--core.log.info("res:", salesOrderData)
	--core.response.exit(200, core.json.encode(finalData))
  core.response.exit(200, core.json.encode(cdsData.d.results))

end	 
	 
