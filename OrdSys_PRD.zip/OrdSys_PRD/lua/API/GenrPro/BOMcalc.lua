local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local db = require("db_ordsys")
local config = require("apisix.core.config_local")

local sapurl = ""
local myformat = ""
local myclient = ""

local sap_conf = config.sap_conf()
local unamepass = ""

--local getSession = core.json.decode(session.getData("userData"))
if getSession == nil then
	--unamepass = getSession.f_uname .. ":" .. getSession.f_passwd
	unamepass = "SAPYTK:112233"
	--
	local function getDataByUrl(orderby) 
	--
	--			url = "https://erpdev.sbs.com.cn/sap/opu/odata/sap"..master_odata..master_entity.."?$filter=contains("..master_field..",%27"..fieldData.."%27&$format=json&sap-client=100"

			local url = "https://223.243.99.172:39443/sap/opu/odata/sap/Y_P_VALID_BOMITEMS_CDS/Y_P_Valid_Bomitems?$filter=IsRoot%20eq%20false %20&$format=json&sap-client=130"
      if orderby then
        url = url .. "&$orderby=" .. ngx.escape_uri(orderby)
      end
      --url = ngx.escape_uri(url)
	--		ngx.say(url)
			core.log.info("url: ", url)
			local basic_auth = ngx.encode_base64(unamepass)
	--		core.log.info("auth: ", basic_auth)
			local cdsres, err = core.http.request_uri(url, {
				  method = "GET",
				  headers = {
					  ["Authorization"] = "Basic " .. basic_auth,   
					  ["Accept"] = "application/xml",
	--				  ["Content-Type"] = "application/json; charset=utf-8",		
				  },
				  ssl_verify = false,
			  })
			  
			  if not cdsres then
          return 500, err
			  end

			  if cdsres.status >= 300 then
          core.log.info("Error Code from CDS call:",cdsres.status)
          core.log.info("Error Code from CDS call:",err)
          core.response.exit(cdsres.status, err)
          --return cdsres.status, cdsres.body
			  end
			  --ngx.say(cdsres.body)
			  return core.json.decode(cdsres.body)
	end	
	
	local function timeConversion(myTime)
		return os.date("%Y-%m-%d %H:%M:%S", myTime)
	end
	 
	ngx.req.read_body() 
	local post_args,argserr= ngx.req.get_post_args() 
	if  post_args == nil then
    ngx.say("err:", argserr)
	end
	--core.log.info("post_args:",core.json.encode(post_args))

  --local odata = post_args.odata
  --local entity = "/" .. post_args.entity
  ngx.update_time()
  local begin = ngx.now()
  
  local cdsData = getDataByUrl()
  
  ngx.update_time()
  ngx.say("cds request seconds: ", ngx.now() - begin)
  
  local i,j = 0,0
  ngx.update_time()
  begin = ngx.now()
	for  k,v in ipairs(cdsData.d.results) do
    --core.log.info(k, ":", v)
		if v.IsRoot ~= true then
      i = i + 1
    end
    if v.IsBulkMaterial ~= true then
      j = j + 1
    end
	end
  ngx.update_time()
  ngx.say("ipairs looped seconds: ", ngx.now() - begin)
  ngx.say("ipairs looped: ", i, "times")
  ngx.say("there is: ", j, " Non-bulk Materials")
	--core.log.info("res:", salesOrderData)
	--core.response.exit(200, core.json.encode(finalData))
  --core.response.exit(200, core.json.encode(cdsData.d.results))
end	 
	 
