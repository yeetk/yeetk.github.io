--ngx.exec("/echo")转场
				
	local cjson = require "cjson"
	local encode_array = require("pgmoon.arrays").encode_array
	local pgmoon = require("pgmoon")
	local pg = pgmoon.new({
	  host = "127.0.0.1",
	  port = "5432",
	  database = "stockdb",
	  user = "postgres",
	  password = "112233"
	})
	
	--local my_array = {}
	--local code,cost,name,trader,volume
	--local str = "["
	
	pg:connect()
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	--ngx.say(type(my_array))
	--ngx.say(table.concat(my_array,","))
	--local sql = "select f_code,f_name,f_lzts,f_efficiency60,f_price_n,f_jump_prob65,f_jump_average_rate65,f_t1_rise_prob65,f_t1_average_rise_rate65,f_t1_average_drop_rate65,f_std_deviation,f_volume_jump,f_linerisestop from t_stock_list where f_efficiency60 > 3 and f_lzts > 0 order by f_lzts,f_efficiency60 desc"
  local sql = "select f_code,f_name,f_lzts,f_efficiency60,f_price_n,f_jump_prob65,f_jump_average_rate65,f_t1_rise_prob65,f_t1_average_rise_rate65,f_t1_average_drop_rate65,f_std_deviation,f_volume_jump,f_linerisestop from t_stock_list where f_efficiency60 > 9  order by f_efficiency60 desc"
	--ngx.say(sql)
	local res, err, partial, num_queries = pg:query(sql)
	--local res, err, partial, num_queries = pg:query("insert into \"t_position\" (\"f_code\",\"f_cost\",\"f_name\",\"f_trader\",\"f_volume\") values(" .. encode_array(my_array) .. ")")
	--ngx.say(err)
	
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	
	--ngx.say(type(res))
	---[[
	-- cjson性能似乎不如for嵌套
	local json = cjson.encode(res)
	ngx.say(json)
	--]]
