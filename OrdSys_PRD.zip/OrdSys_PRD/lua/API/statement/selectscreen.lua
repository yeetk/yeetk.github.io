local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local require_sql = require("/API/statement/requiredata")
--��ѯ��������authidѡ����Ļ�ֶ�
ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
local res,reqerr= ngx.req.get_post_args() --��ȡpost
local authId =""
for k,v in pairs(res) do
    k = cjson.decode(k)
	authId=k.authId 
end
--core.log.info("authId:",authId)
--����authidȷ��sql         		   
local sql = "select b.field_id,b.master_field,b.field_desc from t_auth_field as a left join t_odata_api as b on a.f_field_id = b.field_id where a.f_auth_id = '"..authId.."' order by b.field_id asc"	   
local sqlres = require_sql.selectBySql(sql)

if next(sqlres) == nil then
core.response.exit(200, "no data")
else
core.response.exit(200, core.json.encode(sqlres))
end
