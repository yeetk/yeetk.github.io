local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local require_sql = require("/API/statement/requiredata")

--ngx.req.read_body() -- 
--local res,reqerr= ngx.req.get_post_args() --
local getSession = session.getData()

local sql = ""
if getSession.f_uname then
  sql = "select * from t_user_auth where f_uname = '" .. getSession.f_uname .. "' order by f_component asc"
  local sqlres = require_sql.selectBySql(sql)
  if next(sqlres) == nil then
    core.response.exit(204, "no data")
  else
    core.response.exit(200, core.json.encode(sqlres))
  end
  
else
  core.response.exit(204, "no Authority")
end




