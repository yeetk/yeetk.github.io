local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local require_sql = require("/API/statement/requiredata")
--���۶��˵�-��¼
ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
local res,reqerr= ngx.req.get_post_args() --��ȡpost
if  res == nil then
ngx.say("err:",reqerr)
end
local userName = ""
local passWord = ""
for k,v in pairs(res) do
	k = cjson.decode(k)
	userName = k.userName  
	passWord = k.passWord   
end
--core.log.info("userName:",userName)
--core.log.info("passWord:",passWord)

--�������ݿ��ѯ���˺������Ƿ����
local sql = "select * from t_user where f_uname = '"..userName.."' and f_passwd = '"..passWord.."'"
local userData = require_sql.selectBySql(sql)
if next(userData) == nil then
	core.response.exit(201, "uname or upass is error")
end
--�˺�������֤�ɹ����û����ݴ���session
local createSession = session.setData(core.json.encode(userData[1]),"userData")   


core.response.exit(200, "success login")
