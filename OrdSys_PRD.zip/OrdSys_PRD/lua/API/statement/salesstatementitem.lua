local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local require_sql = require("/API/statement/requiredata")
--��ȡ�û�����
local sapurl = ""
local myformat = ""
local myclient = ""
local unamepass = ""
local getSession = core.json.decode(session.getData("userData"))
if getSession == nil then
	--��ȡ���ʵ�url	  	  
	  local headers_tab = ngx.req.get_headers()
    --�ָ��ַ���
      local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
    --�õ����һ����  
      local myurl = split_res[table.maxn(split_res)] 
    --  core.log.info("myurl:",myurl)	    
	--��url����session
	  local res = session.setData(myurl,"url")   
	  local msg = {}
	  msg["msg"] = "no login"
	  core.response.exit(401, core.json.encode(msg))
else  
	sapurl = getSession.f_sap_url
	myformat = getSession.f_sap_format
	myclient = getSession.f_sap_client
	--unamepass = getSession.f_uname .. ":" .. getSession.f_passwd
	unamepass = "SAPPP:123456789"
	--���۶��˵��������۶�����Ϊ������ѯ
	--����url��ȡ����
	local function getDataByUrl(master_odata,master_entity,master_field,fieldData) 
	--ƴ��url
	--			url = "https://erpdev.sbs.com.cn/sap/opu/odata/sap"..master_odata..master_entity.."?$filter=contains("..master_field..",%27"..fieldData.."%27&$format=json&sap-client=100"

			local url= sapurl..master_odata..master_entity.."?$filter="..master_field.."%20eq%20%27"..fieldData.."%27"..myformat..myclient
	--		ngx.say(url)
	--		core.log.info("url: ", url)
			local basic_auth = ngx.encode_base64(unamepass)
	--		core.log.info("auth: ", basic_auth)
			local cdsres, err = core.http.request_uri(url, {
				  method = "GET",
				  headers = {
					  ["Authorization"] = "Basic " .. basic_auth,   
					  ["Accept"] = "application/xml",
	--				  ["Content-Type"] = "application/json; charset=utf-8",		
				  },
				  ssl_verify = false,
			  })
			  
			  if not cdsres then
				return 500, err
			  end

			  if cdsres.status >= 300 then
				core.log.info("Error Code from CDS call:",cdsres.status)
				core.log.info("Error Code from CDS call:",err)
				return cdsres.status, cdsres.body
			  end
			  --ngx.say(cdsres.body)
			  return core.json.decode(cdsres.body)
	end	
	--ʱ��תʱ��
	local function timeConversion(myTime)
		return os.date("%Y-%m-%d %H:%M:%S", myTime)
	end
	 
    --local TicketType = {}
	--TicketType["01"] = ngx.escape_uri("ֽ��רƱ")
	--TicketType["02"] = ngx.escape_uri("ֽ����Ʊ")
	--TicketType["03"] = ngx.escape_uri("����רƱ")
	--TicketType["04"] = ngx.escape_uri("������Ʊ")
	--�������۶�����Ų�ѯ����ǰ�˵�����
	local function getMyData(FieldValue,myitem1)
		local myData  = {}        --����ǰ�εĽ��
	--ƴ�����۶���Url����ȡ���۶�������
		myData = getDataByUrl("/ZCDS_SBS_STATEMENT_ALL_CDS","/ZCDS_SBS_STATEMENT_ALL","SalesOrder",FieldValue.."%27%20and%20SalesOrderItem%20eq%20%27"..myitem1)
		myData = myData.d.results[1]
		--core.log.info("res:",core.json.encode(myData))
		if	myData ~= nil then
			myData["__metadata"] = nil
		--����ת��
			local CreationDate = myData.CreationDate
			local ProductAvailabilityDate = myData.ProductAvailabilityDate
			local RequestedDeliveryDate = myData.RequestedDeliveryDate
			
			if type(CreationDate)~='userdata' then
				myData.CreationDate = timeConversion((string.sub(CreationDate,7,-3))/1000)
			end
--111			
			if type(ProductAvailabilityDate)~='userdata' then
				myData.ProductAvailabilityDate = timeConversion((string.sub(ProductAvailabilityDate,7,-3))/1000)
			end
			if type(RequestedDeliveryDate)~='userdata' then
				myData.RequestedDeliveryDate = timeConversion((string.sub(RequestedDeliveryDate,7,-3))/1000)
			end	
			--core.log.info("CreationDate:",CreationDate)
			local saleData = getDataByUrl("/API_SALES_ORDER_SRV","/A_SalesOrder","SalesOrder",FieldValue)
			myData["SoldToParty"] = saleData.d.results[1].SoldToParty              --�ͻ�����
		--���ݿͻ������ѯ�ͻ�����
			local customName = getDataByUrl("/API_BUSINESS_PARTNER","/A_BusinessPartner","BusinessPartner",saleData.d.results[1].SoldToParty)
			myData["BusinessPartnerName"] = customName.d.results[1].BusinessPartnerName  --�ͻ�����
			myData["ContractNumber"] = FieldValue.."/"..myitem1 --����Ŀ��ͬ�� 
			--��ѯ�ƻ���
			local conditionData = getDataByUrl("/API_SALES_ORDER_SRV","/A_SalesOrderItemPrElement","SalesOrder",FieldValue.."%27%20and%20SalesOrderItem%20eq%20%27"..myitem1 )
			for i=1,table.maxn(conditionData.d.results) do
				if	conditionData.d.results[i].ConditionType =="PPR1" then
						myData["TaxUnitPrice"] = conditionData.d.results[i].ConditionRateValue --��˰����
				end
				if	conditionData.d.results[i].ConditionType =="ZTX1" then
						myData["RateValue"] = conditionData.d.results[i].ConditionRateValue --˰��
				end
			
			end
			--myData["TicketType"] = TicketType[myData.TicketType] --Ʊ������
			--��ѯƱ��
			
			local billItemData = getDataByUrl("/API_BILLING_DOCUMENT_SRV","/A_BillingDocumentItem","SalesDocument",FieldValue.."%27%20and%20BillingDocumentItem%20eq%20%27"..myitem1)
				if billItemData.d.results[1]~=nil then
				--core.log.info("BillingQuantity:",cjson.encode(billItemData.d.results[1]))
					myData["BillingQuantity"] = billItemData.d.results[1].BillingQuantity --��Ʊ����
					myData["BillingDocument"] = billItemData.d.results[1].BillingDocument --��Ʊƾ֤��
				else
					myData["BillingQuantity"] = 0
					myData["BillingDocument"] = nil --��Ʊƾ֤��
				end
			myData["NotBillingQuantity"] = myData["ActualDeliveryQuantity"]-myData["BillingQuantity"] --δ��Ʊ����	
			if myData["TaxUnitPrice"] == nil then
				myData["NotBillingMoney"] = 0
			else	
				myData["NotBillingMoney"] = myData["NotBillingQuantity"]*myData["TaxUnitPrice"] --δ��Ʊ���	
			end
			--��ѯ�˻���
			local returnItemData = getDataByUrl("/ZCDS_SBS_RETURNORDER_CDS","/ZCDS_SBS_RETURNORDER","ReferenceOrder",FieldValue.."%27%20and%20ReferenceOrderitem%20eq%20%27"..myitem1)
			myData["ReturnQuantity"] = 0 --�˻�����
			if returnItemData.d.results[1]~=nil then
				myData["returnItem"] = {}
				for k=1,table.maxn(returnItemData.d.results) do
					--returnItemData.d.results[k].__metadata = nil
					myData["ReturnQuantity"] = myData["ReturnQuantity"]+returnItemData.d.results[k].DeliverQuantity
					table.insert(returnItemData.d.results[k],myData["returnItem"])
				end
			end
			myData["ActualDeliveryQuantity"] = myData["ActualDeliveryQuantity"]- myData["ReturnQuantity"]
		end	
		return myData			
	end
	--1.����ǰ�˴����������۶���
	ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
	local res,reqerr= ngx.req.get_post_args() --��ȡpost
	if  res == nil then
	ngx.say("err:",reqerr)
	end
--	core.log.info("res:",core.json.encode(res))
	local finalData = {}
	for k, v in pairs(res) do
		local split_res, split_err = ngx_re.split(k,",")
		for k=1,table.maxn(split_res) do
			local split_res1, split_err1 = ngx_re.split(split_res[k],":")
			local getData = getMyData(split_res1[1],split_res1[2])
			table.insert(finalData,getData)
		end
	end 

    --core.log.info("res:",core.json.encode(finalData))
	core.response.exit(200, core.json.encode(finalData))
end	 
	 
