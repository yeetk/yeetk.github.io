local pgmoon = require("pgmoon")

local _M = {}

function _M.selectBySql(sql)
	local pg, err = pgmoon.new({
		host = "127.0.0.1",
		port = "5432",
		database = "ordsys",
		user = "postgres",
		password = "112233"
	  })
	if not pg then
		  --return nil, err
		  --core.log.info("error: ", err)
		  ngx.say("error: ", err)
	  end
	  local ok, err = pg:connect()
	  if not ok then
		  --return nil, err
		  --core.log.info("error: ", err)
		 ngx.say("error: ", err)
	  end
	  --core.log.info("sql: ", sql)
	  local res, err = pg:query(sql)
	  --local insres, err = core.pg.query(sql)
	  if not res then
		  --return 204, {errmsg = err}
		  --core.log.info("error: ", err)
		  ngx.say("error: ", err)
		  --core.response.exit(204, err)
	  end
	  pg:keepalive()
      return res
 end
 return _M