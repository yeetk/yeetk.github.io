local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local require_sql = require("/API/statement/requiredata")
local sapurl = ""
local myformat = ""
local myclient = ""
local unamepass = ""
local getSession = session.getData("userData")
if getSession == nil then
	--url	  	  
	  local headers_tab = ngx.req.get_headers()
    --
      local split_res, split_err = ngx_re.split(headers_tab.referer,"/")
    --
      local myurl = split_res[table.maxn(split_res)] 
    --  core.log.info("myurl:",myurl)	    
	--session
	  local res = session.setData(myurl,"url")   
	  local msg = {}
	  msg["msg"] = "no login"
	  core.response.exit(401, core.json.encode(msg))
else  
	sapurl = getSession.f_sap_url
	myformat = getSession.f_sap_format
	myclient = getSession.f_sap_client
	--unamepass = getSession.f_uname .. ":" .. getSession.f_passwd
	unamepass = "SAPPP:123456789"
	--
	--
	local function getDataByUrl(master_odata,master_entity,fieldData) 
	--url
	--			url = "https://erpdev.sbs.com.cn/sap/opu/odata/sap"..master_odata..master_entity.."?$filter=contains("..master_field..",%27"..fieldData.."%27&$format=json&sap-client=100"

			local url= sapurl..master_odata..master_entity.."?$filter="..fieldData..myformat..myclient.."&$orderby=SalesOrder,SalesOrderItem"
	--		ngx.say(url)
			--core.log.info("url: ", url)
			local basic_auth = ngx.encode_base64(unamepass)
	--		core.log.info("auth: ", basic_auth)
			local cdsres, err = core.http.request_uri(url, {
				  method = "GET",
				  headers = {
					  ["Authorization"] = "Basic " .. basic_auth,   
					  ["Accept"] = "application/xml",
	--				  ["Content-Type"] = "application/json; charset=utf-8",		
				  },
				  ssl_verify = false,
			  })
			  
			  if not cdsres then
				return 500, err
			  end

			  if cdsres.status >= 300 then
				core.log.info("Error Code from CDS call:",cdsres.status)
				core.log.info("Error Code from CDS call:",err)
				return cdsres.status, cdsres.body
			  end
			  --ngx.say(cdsres.body)
			  return core.json.decode(cdsres.body)
	end	
	--ʱ��תʱ��
	local function timeConversion(myTime)
		return os.date("%Y-%m-%d %H:%M:%S", myTime)
	end
	 
	ngx.req.read_body() -- ���� body ����֮ǰһ��Ҫ�ȶ�ȡ body
	local res,reqerr= ngx.req.get_post_args() --��ȡpost
	if  res == nil then
	ngx.say("err:",reqerr)
	end
	--core.log.info("res:",core.json.encode(res))
	--ȷ�����۶���
	local bodyData = {}
    local myFieldName = "" 
    local b = 0	
	for  k,v in pairs(res) do	 
		local bodyData1 = cjson.decode(k)
		for i=1,table.maxn(bodyData1) do
			bodyData[bodyData1[i].fieldName]=bodyData1[i].fieldData
			if i==1 then
				myFieldName = bodyData1[i].fieldName
			end
			b = b+1	
		end        	
	end
--	core.log.info("res:",core.json.encode(bodyData))

	local myFieldData = ""
		--�ж�ֵ�Ƿ����-��������ڶ��� 
	local a =1	

	for  k,v in pairs(bodyData) do		
		if string.find(v.ge,",")~= nil then
			local split_res1, split_err1 = ngx_re.split(v.ge,",")
			for j=1,table.maxn(split_res1) do
				myFieldData = myFieldData..k.."%20eq%20%27"..split_res1[j].."%27"
				if j~= table.maxn(split_res1) then	
					myFieldData = myFieldData.."%20and%20"
				end
			end			
		else			
			myFieldData = myFieldData..k.."%20eq%20%27"..v.ge.."%27"				
		end	
        if a~= b then	
			myFieldData = myFieldData.."%20and%20"
		end
		a = a+1
	end		
--	core.log.info("res:",myFieldData)
    local salesOrderData = getDataByUrl("/ZCDS_SBS_STATEMENT_SELECT_CDS","/ZCDS_SBS_STATEMENT_SELECT",myFieldData)
	--core.log.info("res:",core.json.encode(salesOrderData))
	local finalData = {}
    if 	salesOrderData~=nil then
		for k=1,table.maxn(salesOrderData.d.results) do
			if salesOrderData.d.results[k].SoldToPartyType == 'SP' then
				salesOrderData.d.results[k].__metadata = nil
				local ProductAvailabilityDate = salesOrderData.d.results[k].ProductAvailabilityDate
				if type(ProductAvailabilityDate)~='userdata' then
					salesOrderData.d.results[k].ProductAvailabilityDate = timeConversion((string.sub(ProductAvailabilityDate,7,-3))/1000)
				end				
				table.insert(finalData,salesOrderData.d.results[k])
			end
		end
	end	
	--fieldΪ����ʱ��Ҫת�룡����       		
	core.response.exit(200, core.json.encode(finalData))

end	 
	 
