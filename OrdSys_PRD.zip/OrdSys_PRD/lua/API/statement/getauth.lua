local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local session = require("admin.session")
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")
local require_sql = require("/API/statement/requiredata")
--
--session
local ok, err = session.check()
if not ok then
    core.response.exit(401, err)
end

local getSession = session.get()

--
local userId = getSession.f_id
local selectRoleAndAuthSql = "select d.f_authid,d.f_authname,d.f_authurl,d.f_requestmethod,d.f_desc from t_user as a left join t_user_role as b on a.f_id = b.f_user_id left join t_role_auth as c on b.f_role_id = c.f_role_id left join t_auth as d on c.f_auth_id = d.f_authid where a.f_id = '"..userId.."'"
local authData = require_sql.selectBySql(selectRoleAndAuthSql)
if next(authData) == nil then
core.response.exit(200, "no data")
else
core.response.exit(200, core.json.encode(authData))
end