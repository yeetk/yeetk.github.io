local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

ngx.req.read_body()
local args,argerr= ngx.req.get_post_args()
local function selectdata(sql, db)
  local pg, err = pgmoon.new({
      host = "127.0.0.1",
      port = "5432",
      database = db,
      user = "postgres",
      password = "112233"
    })
  if not pg then
      --return nil, err
      --core.log.info("error: ", err)
      ngx.say("error: ", err)
  end
  local ok, connerr = pg:connect()
  if not ok then
     ngx.say("error: ", connerr)
  end 
  local res, reserr = pg:query(sql) 
  if not res then
      ngx.say("error: ", reserr)
  end  
   pg:keepalive()
  return res
 
end

if args.db then
  local sql  = "SELECT pg_catalog.pg_relation_filenode(c.oid) as Filenode, relname as TableName FROM  pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace  LEFT JOIN pg_catalog.pg_database d ON d.datname ='" .. args.db .. "' WHERE  relkind IN ('r') AND n.nspname NOT IN ('pg_catalog', 'information_schema') AND n.nspname !~ '^pg_toast' ORDER BY relname"

  core.response.exit(200, core.json.encode(selectdata(sql,args.db)))
end
  

   








