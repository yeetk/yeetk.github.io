local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      --core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

---[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select * from t_stock_idx where f_year=" .. value.year .. " and f_rtype=" .. value.rtype
local selres, selerr = stockdb(isql)

--local uri = "http://www.cninfo.com.cn/data/project/commonInterface"
--local fieldmap = {营业收入="f_yysr", 营业成本="f_yycb", 营业利润="f_yylr", 利润总额="f_lrze", 所得税="f_sds", 净利润="f_jlr"}

for k, row in ipairs(selres) do

  --更新Graham数字
  if row.f_current_assets and row.f_liability and row.f_circulate_shares then
    local graham = (row.f_current_assets - row.f_liability ) / row.f_circulate_shares
    
    isql = "UPDATE t_stock_idx SET f_graham_number=" .. string.format("%0.3f", graham) .. " where f_code = " .. pgsql_str(row.f_code) .. " and f_year=" .. value.year .. " and f_rtype=" .. value.rtype
    local updidxres, updidxerr = stockdb(isql)
    
    isql = "select * from t_stock_list where f_code=" .. pgsql_str(row.f_code)
    local listres, listerr = stockdb(isql)
    
    if listres[1].f_price_n then
      local price_graham = listres[1].f_price_n / graham
      isql = "UPDATE t_stock_list SET f_price_graham=" .. string.format("%0.3f", price_graham) .. " where f_code = " .. pgsql_str(row.f_code)
      local updlistres, updlisterr = stockdb(isql)
    end
  end
  
  --获取去年同期数据
  isql = "select * from t_stock_idx where f_code=" .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year-1 .. " and f_rtype=" .. row.f_rtype
  local res, err = stockdb(isql)
  --更新收入增长同比环比指标
  if res[1] and row.f_yysrq and res[1].f_yysrq then
    --季度收入增量同比
    local yysryony = (row.f_yysrq - res[1].f_yysrq) * 100 / res[1].f_yysrq
    --获取上期数据
    if row.f_rtype == 1 then
      isql = "select * from t_stock_idx where f_code=" .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year-1 .. " and f_rtype=4"
    else
      isql = "select * from t_stock_idx where f_code=" .. pgsql_str(row.f_code) .. " and f_year=" .. row.f_year .. " and f_rtype=" .. row.f_rtype-1
    end
    res, err = stockdb(isql)
    if res[1] and res[1].f_yysrq then
      --季度收入增量环比
      local yysrqonq = (row.f_yysrq - res[1].f_yysrq) * 100 / res[1].f_yysrq
      if string.format("%0.3f", yysryony) ~= "inf" and string.format("%0.3f", yysrqonq) ~= "inf" then
        isql = "UPDATE t_stock_list SET f_yysr_yony=" .. string.format("%0.3f", yysryony) .. ", f_yysr_qonq=" .. string.format("%0.3f", yysrqonq) .. " where f_code = " .. pgsql_str(row.f_code)
        local updres, upderr = stockdb(isql)
      end
    end
  end
end
return 200, {msg = "successful run"}