local cjson = require("cjson")
local ffi = require("ffi")

ffi.cdef[[
   int changeSched(int argc, const char** argv);
   int nlsui_main(int argc, const char** argv);
]]
local cfunc = ffi.load('/usr/local/nwrfc/750/nwrfcsdk/lib/libChangeSchedLinesFFI.so')

--[[
local user_config = core.config.local_conf().user_config

local session_val, err = session.get()
if not session_val then
    return 401, err
end
--]]

ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
--core.log.info(core.json.encode(req_head))
ngx.log(ngx.INFO, "req_head: " .. req_head["content-type"])
if req_body and req_head["content-type"] == "application/json" then
    local data, err = cjson.decode(req_body)
    if not data then
        --core.log.error("invalid request body: ", req_body, " err: ", err)
        ngx.log(ngx.ERR, "invalid request body")
        --[[
        core.response.exit(400, {error_msg = "invalid request body",
                                 req_body = req_body})
        --]]
        ngx.exit(400)
    end

    local conf = data
end
ngx.log(ngx.INFO, "converted data of req_body: " .. cjson.decode(req_body).SalesOrder)
local conf = cjson.decode(req_body)
local argStr = {conf["SalesOrder"], conf["SalesOrderItem"], conf["RequestedDeliveryDate"]}

--local arg = ffi.new("const char*[4]", {"0000000726","000010","20200312"})
local arg = ffi.new("const char*[4]", argStr)

local ret = cfunc.changeSched(4,arg)

--core.log.info("ret: ", ret)
ngx.log(ngx.INFO, "ret: " .. ret)
if not 0 then
  --return 204, err
  ngx.status = 204
  ngx.say("error")
end

--return 200, "Sales Order:" .. conf[SalesOrder] .. ", item:" .. conf[SalesOrderItem] .. "updated"

ngx.status = 200
ngx.say("Sales Order:" .. conf.SalesOrder .. ", item:" .. conf.SalesOrderItem .. " Requested Delivery Date updated")
--ngx.say("updated")