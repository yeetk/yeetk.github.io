--ngx.exec("/echo")转场
				
	local cjson = require "cjson"
	local encode_array = require("pgmoon.arrays").encode_array
	local pgmoon = require("pgmoon")
	local pg = pgmoon.new({
	  host = "127.0.0.1",
	  port = "5432",
	  database = "stockdb",
	  user = "postgres",
	  password = "112233"
	})
	
	--local my_array = {}
	--local code,cost,name,trader,volume
	local str = "["
	
	pg:connect()
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	--ngx.say(type(my_array))
	--ngx.say(table.concat(my_array,","))
	local sql = "select f_sn,f_code,f_name,f_cost,f_risk,f_volume,f_trader,f_price_top from t_position where f_selldate is null"
	--ngx.say(sql)
	local res, err, partial, num_queries = pg:query(sql)
	--local res, err, partial, num_queries = pg:query("insert into \"t_position\" (\"f_code\",\"f_cost\",\"f_name\",\"f_trader\",\"f_volume\") values(" .. encode_array(my_array) .. ")")
	--ngx.say(err)
	
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	
	--ngx.say(type(res))
	---[[
	-- cjson性能似乎不如for嵌套
	local json = cjson.encode(res)
	ngx.say(json)
	--]]
