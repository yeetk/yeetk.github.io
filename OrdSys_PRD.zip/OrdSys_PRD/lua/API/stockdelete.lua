--ngx.exec("/echo")转场
				
	local cjson = require "cjson"
	local encode_array = require("pgmoon.arrays").encode_array
	local pgmoon = require("pgmoon")
	local pg = pgmoon.new({
	  host = "127.0.0.1",
	  port = "5432",
	  database = "stockdb",
	  user = "postgres",
	  password = "112233"
	})
	
	local sql = nil
	--local my_array = {}
	--local code,cost,name,trader,volume
	ngx.req.read_body()
	local args, err = ngx.req.get_post_args()
	-- local posi = ""
	if err == "truncated" then
		 -- one can choose to ignore or reject the current request here
	 end

	if not args then
		 ngx.say("failed to get post args: ", err)
		 return
	end
  ngx.say(args.code,"~",args.price)
		if args.code and args.price then
			str = "f_price = " .. args.price
			--sql = "update t_position set f_selldate = current_date, " .. str .. " where f_selldate is null and " .. "f_code='" .. args.code .. "'"
      sql = "delete from t_position where f_selldate is null and " .. "f_sn=" .. args.sn
		else
			--sql = nil
		end
	
	
	pg:connect()
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	--ngx.say(type(my_array))
	--ngx.say(table.concat(my_array,","))
	if sql then
		--local sql = "select f_code,f_name,f_cost,f_risk,f_volume from t_position where f_selldate is null"
		local res, err, partial, num_queries = pg:query(sql)
		ngx.say(err,"~",num_queries)
	end
	