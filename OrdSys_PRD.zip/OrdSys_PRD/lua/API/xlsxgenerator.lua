local require = require
local ngx = ngx
local core = require("apisix.core")
local cjson = require("cjson")
local new_tab = require "table.new"
local Workbook = require "xlsxwriter.workbook"

local function xlsxExport(area, dataTab) 
  -- Create a workbook and add a worksheet.
  local plant = dataTab[1].Plant or "1030"
  local info = {
      ["CN"] = {
        ["1030"] = {
          ["fileName"] = "舒城报关草单.xlsx",
          ["fileName1"] = "舒城报关资料.xlsx",
          ["optPlantName"] = "六安卓立信光科技工厂34139609Q1",
          ["dlvPlantName"] = "精卓光电合肥工厂34012606C1",
          ["companyName"] = "Lu'an Zhuo Lixin Optical Technology Co., Ltd\r\n六安卓立信光科技有限责任公司",
          ["vendor"] = "1030",
          ["address"] = "Building 1,Precision Electronic Industry Park,Hangbu Town,Shucheng County,Lu'an City,Anhui Province\r\n安徽省六安市舒城县杭埠镇精密电子产业园1＃楼",
          ["buyerCompanyName"] = "Jingzhuo Technology (HK) Co. Limited\r\n精卓科技（香港）有限公司",
          ["buyerAddress"] = "20th Floor, Euro Trade Centre, 21-23 Des Voeux Road Central, Hong Kong\r\n香港中環德輔道中21-23號歐陸貿易中心20樓"
        },
        ["1070"] = {
          ["fileName"] = "合肥报关草单.xlsx",
          ["fileName1"] = "合肥报关资料.xlsx",
          ["optPlantName"] = "精卓光电合肥工厂34012606C1",
          ["dlvPlantName"] = "精卓光电合肥工厂34012606C1",
          ["companyName"] = "Hefei Jingzhuo Photoelectric Co.,Ltd.\r\n合肥精卓光电有限责任公司",
          ["vendor"] = "1070",
          ["address"] = "Yunhai Road Industrial Park,No.176，Yun'er Road, Hefei Economic DevelopmentZone, Anhui Province\r\n安徽省合肥市经济技术开发区云二路176号云海路工业园B栋",
          ["buyerCompanyName"] = "Jingzhuo Technology (HK) Co. Limited\r\n精卓科技（香港）有限公司",
          ["buyerAddress"] = "20th Floor, Euro Trade Centre, 21-23 Des Voeux Road Central, Hong Kong\r\n香港中環德輔道中21-23號歐陸貿易中心20樓"
        }
      },
      ["HK"] = {
        ["1030"] = {
          ["fileName"] = "香港报关草单.xlsx",
          ["fileName1"] = "香港报关资料.xlsx",
          ["optPlantName"] = "精卓科技（香港）有限公司",
          ["dlvPlantName"] = "精卓科技（香港）有限公司",
          ["companyName"] = "Jingzhuo Technology (HK) Co. Limited\r\n精卓科技（香港）有限公司",
          ["vendor"] = "JJZ01",
          ["address"] = "20th Floor, Euro Trade Centre, 21-23 Des Voeux Road Central, Hong Kong\r\n香港中環德輔道中21-23號歐陸貿易中心20樓",
          ["buyerCompanyName"] = "联宝（合肥）电子科技有限公司\r\nLCFC (Hefei) Electronics Technology Co., Ltd.",
          ["buyerAddress"] = "No. 3188-1, Yungu Road (Comprehensive Bonded  Zone), Hefei Economic & Technological Development Area,Anhui\r\n安徽省合肥经济技术开发区云谷路3188-1号（综合保税区内）"
        },
        ["1070"] = {
          ["fileName"] = "香港报关草单.xlsx",
          ["fileName1"] = "香港报关资料.xlsx",
          ["optPlantName"] = "精卓科技（香港）有限公司",
          ["dlvPlantName"] = "精卓科技（香港）有限公司",
          ["companyName"] = "Jingzhuo Technology (HK) Co. Limited\r\n精卓科技（香港）有限公司",
          ["vendor"] = "JJZ01",
          ["address"] = "20th Floor, Euro Trade Centre, 21-23 Des Voeux Road Central, Hong Kong\r\n香港中環德輔道中21-23號歐陸貿易中心20樓",
          ["buyerCompanyName"] = "联宝（合肥）电子科技有限公司\r\nLCFC (Hefei) Electronics Technology Co., Ltd.",
          ["buyerAddress"] = "No. 3188-1, Yungu Road (Comprehensive Bonded  Zone), Hefei Economic & Technological Development Area,Anhui\r\n安徽省合肥经济技术开发区云谷路3188-1号（综合保税区内）"
        }
      }
    }
  local filePath = "/usr/local/OrdSys/file/"
  local trpMethod = {T="By Truck",A="By Air",S="By Sea"}
  --workbook for applySheet
  local workbook  = Workbook:new(table.concat({filePath, dataTab[1].zbglsh, info[area][plant].fileName}))
  local worksheet = workbook:add_worksheet("报关单草单")
  
  local merge_format = workbook:add_format({align = "center"})
  local merge_16 = merge_format
  merge_16:set_font_size(16)
  merge_16:set_text_wrap()
  
  local merge_10 = workbook:add_format({align = "left"})
  merge_10:set_font_size(10)
  merge_10:set_border_color("black")
  merge_10:set_border(1)
  
  local right_border = workbook:add_format({align = "left"})
  right_border:set_border_color("black")
  right_border:set_right(1)
  
  local bottom_border = workbook:add_format({align = "left"})
  bottom_border:set_border_color("black")
  bottom_border:set_bottom(1)

  worksheet:set_row(0, 31)
  worksheet:set_column("B:B", 19)
  worksheet:set_column("C:C", 13)
  worksheet:set_column("D:D", 19)
  worksheet:set_column("E:E", 19)
  worksheet:set_column("F:F", 13)

  worksheet:merge_range("A1:K2", info[area][plant].companyName, merge_16)
  --worksheet:merge_range("A1:K2", "=CONCATENATE('Lu'an Zhuo Lixin Optical Technology Co., Ltd',CHAR(10),'六安卓立信光科技有限责任公司')", merge_16)
  --worksheet:merge_range("A2:K2", "", merge_16)
  worksheet:merge_range("A4:K4", "Export apply sheet in Chinese Code", merge_16)

  worksheet:merge_range("A5:B5", "Ledger No:", merge_10)
  worksheet:merge_range("C5:E5", dataTab[1].BookNumber, merge_10)
  worksheet:write("F5", "Invoice No:", merge_10)
  worksheet:merge_range("G5:H5", dataTab[1].zbglsh, merge_10)
  worksheet:write("I5", "", merge_10)
  worksheet:write("J5", "申报日期:", merge_10)
  worksheet:write("K5", dataTab[1].ReplyAckDate, merge_10)

  worksheet:merge_range("A6:D6", "经营单位：" .. info[area][plant].optPlantName, merge_10)
  worksheet:write("K6", "", right_border)
  worksheet:merge_range("A7:D7", "发货单位：" .. info[area][plant].dlvPlantName, merge_10)
  worksheet:write("K7", "", right_border)

  worksheet:merge_range("A8:E8", "Ship to：CN", merge_10)
  worksheet:write("F8", "成交方式：", merge_10)
  worksheet:merge_range("G8:K8", dataTab[1].IncotermsClassification, merge_10)
--[[
  worksheet:write("H8", "", merge_10)
  worksheet:write("I8", "", merge_10)
  worksheet:write("J8", "", merge_10)
  worksheet:write("K8", "", merge_10)
--]]

  worksheet:merge_range("A9:B9", "件数：", merge_10)
  worksheet:write("C9", "", merge_10)
  worksheet:merge_range("D9:E9", "毛重：", merge_10)
  worksheet:write("F9", "", merge_10)
  worksheet:merge_range("G9:K9", "净重：", merge_10)
--[[
  worksheet:write("I9", "", merge_10)
  worksheet:write("J9", "", merge_10)
  worksheet:write("K9", "", merge_10)
--]]

  --workbook for other Sheet
  local workbook1  = Workbook:new(table.concat({filePath, dataTab[1].zbglsh, info[area][plant].fileName1}))
  local worksheet1 = workbook1:add_worksheet("packing list")
  local worksheet2 = workbook1:add_worksheet("invoice")
  local worksheet3 = workbook1:add_worksheet("Sales Order")
  
  local merge_format1 = workbook1:add_format({align = "center"})

  local merge1_16 = workbook1:add_format({align = "center"})
  merge1_16:set_font_size(16)
  merge1_16:set_text_wrap()
  local bottom1_16 = workbook1:add_format({align = "center"})
  bottom1_16:set_font_size(16)
  bottom1_16:set_text_wrap()
  bottom1_16:set_border_color("black")
  bottom1_16:set_bottom(1)
  
  local merge1_10 = workbook1:add_format({align = "left"})
  merge1_10:set_font_size(10)
  merge1_10:set_text_wrap()
  local right_border1 = workbook1:add_format({align = "left"})
  right_border1:set_font_size(10)
  right_border1:set_text_wrap()
  right_border1:set_border_color("black")
  right_border1:set_right(1)
  
  local left_right_border1 = workbook1:add_format({align = "left"})
  left_right_border1:set_font_size(10)
  left_right_border1:set_text_wrap()
  left_right_border1:set_border_color("black")
  left_right_border1:set_left(1)
  left_right_border1:set_right(1)
  
  local bottom_border1 = workbook1:add_format({align = "left"})
  bottom_border1:set_font_size(10)
  bottom_border1:set_text_wrap()
  bottom_border1:set_border_color("black")
  bottom_border1:set_bottom(1)
  
  local bottom_right1 = workbook1:add_format({align = "left"})
  bottom_right1:set_font_size(10)
  bottom_right1:set_text_wrap()
  bottom_right1:set_border_color("black")
  bottom_right1:set_bottom(1)
  bottom_right1:set_right(1)
  
  local left_bottom_right1 = workbook1:add_format({align = "left"})
  left_bottom_right1:set_font_size(10)
  left_bottom_right1:set_text_wrap()
  left_bottom_right1:set_border_color("black")
  left_bottom_right1:set_left(1)
  left_bottom_right1:set_bottom(1)
  left_bottom_right1:set_right(1)
  
  if dataTab[1].DeliveryDocumentType == "ZLR" then
    local tmp = info[area][plant].companyName
    info[area][plant].companyName =  info[area][plant].buyerCompanyName
    info[area][plant].buyerCompanyName = tmp
    tmp = info[area][plant].address
    info[area][plant].address = info[area][plant].buyerAddress
    info[area][plant].buyerAddress = tmp
  end
  
  for _, sheet in ipairs(workbook1:worksheets()) do
    --sheet:write("A1", "Hello")
    sheet:set_row(0, 35)
    sheet:set_row(5, 35)
    sheet:set_row(6, 50)
    sheet:set_row(8, 35)
    sheet:set_row(9, 50)
    sheet:set_column("B:B", 19)
    sheet:set_column("C:C", 13)
    sheet:set_column("D:D", 19)
    sheet:set_column("E:E", 19)
    sheet:set_column("F:F", 13)
    sheet:set_column("I:I", 13)
    sheet:set_column("J:J", 13)

    sheet:merge_range("A5:E5", "卖方:", left_right_border1)
    sheet:write("F5", "Invoice No:", merge1_10)
    sheet:merge_range("G5:I5", dataTab[1].zbglsh, merge1_10)
    
    
    sheet:merge_range("A6:E6", info[area][plant].companyName, left_right_border1)
    
    
    sheet:merge_range("A7:E7", info[area][plant].address, left_right_border1)
    sheet:write("F7", "Vendor Code:", bottom_border1)
    
    sheet:merge_range("A8:E8", "买方:", left_right_border1)
    sheet:write("F8", "Inco terms:", merge1_10)
    
    sheet:merge_range("A9:E9", info[area][plant].buyerCompanyName, left_right_border1)
    sheet:write("F9", "Mode of transport：", merge1_10)
    
    sheet:merge_range("A10:E10", info[area][plant].buyerAddress, left_bottom_right1)
    sheet:write("F10", "手册号:", bottom_border1)
    
    if sheet:get_name() ~= "invoice" then
      sheet:merge_range("A1:K2", info[area][plant].companyName, merge1_16)
      sheet:write("J5", "Date:", merge1_10)
      sheet:write("K5", dataTab[1].ReplyAckDate, right_border1)
      sheet:write("K6", "", right_border1)
      sheet:merge_range("G7:K7", info[area][plant].vendor, bottom_right1)
      sheet:merge_range("G8:K8", dataTab[1].IncotermsClassification, right_border1)
      sheet:merge_range("G9:K9", trpMethod[dataTab[1].zysfs], right_border1)
      sheet:merge_range("G10:K10", dataTab[1].BookNumber, bottom_right1)
    else
      sheet:merge_range("A1:L2", info[area][plant].companyName, merge1_16)
      sheet:write("J5", "Date:", merge1_10)
      sheet:merge_range("K5:L5", dataTab[1].ReplyAckDate, right_border1)
      sheet:write("L6", "", right_border1)
      sheet:merge_range("G7:L7", info[area][plant].vendor, bottom_right1)
      sheet:merge_range("G8:L8", dataTab[1].IncotermsClassification, right_border1)
      sheet:merge_range("G9:L9", trpMethod[dataTab[1].zysfs], right_border1)
      sheet:merge_range("G10:L10", dataTab[1].BookNumber, bottom_right1)
    end
  end

  worksheet1:merge_range("A4:K4", "PACKING LIST", bottom1_16)
  worksheet2:merge_range("A4:L4", "INVOICE", bottom1_16)
  worksheet3:merge_range("A4:K4", "Sales Order", bottom1_16)
  
  worksheet:write("A10", "序号", bottom_border)
  worksheet1:write("A11", "序号", bottom_border1)
  worksheet2:write("A11", "序号", bottom_border1)
  worksheet3:write("A11", "序号", bottom_border1)
  

  local fieldMap = {
      CN = {
        applySheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "手册项号", fieldId = "ChineseCode"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "HS code", fieldId = "cccCode"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "净重", fieldId = "NetWeight"},
          {fieldName = "单价", fieldId = "NetUnitPrice"},
          {fieldName = "总价", fieldId = "Amount"},
          {fieldName = "币制", fieldId = "TransactionCurrency"}
        },
        packListSheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "手册项号", fieldId = "ChineseCode"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "物料描述", fieldId = "arktx"},
          {fieldName = "HS code", fieldId = "cccCode"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "净重", fieldId = "NetWeight"},
          {fieldName = "毛重", fieldId = "GrossWeight"},
          {fieldName = "件数", fieldId = "Qty"}
        },
        invoiceSheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "手册项号", fieldId = "ChineseCode"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "物料描述", fieldId = "arktx"},
          {fieldName = "HS code", fieldId = "cccCode"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "单价", fieldId = "NetUnitPrice"},
          {fieldName = "总价", fieldId = "Amount"},
          {fieldName = "币制", fieldId = "TransactionCurrency"},
          {fieldName = "原产国", fieldId = "Origin"}
        },
        salesOrderSheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "联宝订单号", fieldId = "PurchaseOrder94"},
          {fieldName = "联想订单号", fieldId = "PurchaseOrder75"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "物料描述", fieldId = "arktx"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "单价", fieldId = "NetUnitPrice"},
          {fieldName = "总价", fieldId = "Amount"},
          {fieldName = "币制", fieldId = "TransactionCurrency"}
        }
      },
      HK = {
        applySheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "手册项号", fieldId = "ChineseCode"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "HS code", fieldId = "cccCode"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "净重", fieldId = "NetWeight"},
          {fieldName = "单价", fieldId = "NetUnitPrice"},
          {fieldName = "总价", fieldId = "Amount"},
          {fieldName = "币制", fieldId = "TransactionCurrency"}
        },
        packListSheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "手册项号", fieldId = "ChineseCode"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "物料描述", fieldId = "arktx"},
          {fieldName = "HS code", fieldId = "cccCode"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "净重", fieldId = "NetWeight"},
          {fieldName = "毛重", fieldId = "GrossWeight"},
          {fieldName = "件数", fieldId = "Qty"}
        },
        invoiceSheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "手册项号", fieldId = "ChineseCode"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "物料描述", fieldId = "arktx"},
          {fieldName = "HS code", fieldId = "cccCode"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "单价", fieldId = "NetUnitPrice"},
          {fieldName = "总价", fieldId = "Amount"},
          {fieldName = "币制", fieldId = "TransactionCurrency"},
          {fieldName = "原产国", fieldId = "Origin"}
        },
        salesOrderSheet = {
          --{fieldName = "序号", fieldId = "zposnr"},
          {fieldName = "料号", fieldId = "Material"},
          {fieldName = "联宝订单号", fieldId = "PurchaseOrder94"},
          {fieldName = "联想订单号", fieldId = "PurchaseOrder75"},
          {fieldName = "品名", fieldId = "MaterialDescription"},
          {fieldName = "物料描述", fieldId = "arktx"},
          {fieldName = "数量", fieldId = "ActualDeliveryQuantity"},
          {fieldName = "单位", fieldId = "LegalBaseUnit"},
          {fieldName = "单价", fieldId = "NetUnitPrice"},
          {fieldName = "总价", fieldId = "Amount"},
          {fieldName = "币制", fieldId = "TransactionCurrency"}
        }
      }
    }
  
  local row = #dataTab + 10
  --local col = 1
  --create Header line of applySheet
  for i, fld in ipairs(fieldMap[area].applySheet) do
    worksheet:write(9, i,  fld.fieldName, bottom_border)
  end
  
  --create Header line of packListSheet
  for i, fld in ipairs(fieldMap[area].packListSheet) do
    worksheet1:write(10, i,  fld.fieldName, bottom_border1)
  end
  
  --create Header line of invoiceSheet
  for i, fld in ipairs(fieldMap[area].invoiceSheet) do
    worksheet2:write(10, i,  fld.fieldName, bottom_border1)
  end
  
  --create Header line of salesOrderSheet
  for i, fld in ipairs(fieldMap[area].salesOrderSheet) do
    worksheet3:write(10, i,  fld.fieldName, bottom_border1)
  end

  -- Iterate over the data and write it out element by element.
  for i, item in ipairs(dataTab) do
    --fill constant value
    item.Origin = "中国"
    item.ActualDeliveryQuantity = tonumber(item.ActualDeliveryQuantity)
    item.NetWeight = tonumber(item.NetWeight)
    item.GrossWeight = tonumber(item.GrossWeight)
    item.Qty = tonumber(item.Qty)
    item.Amount = tonumber(string.format("%.2f", tonumber(item.NetUnitPrice) * item.ActualDeliveryQuantity))
    --filling applySheet item line
    worksheet:write(9+i, 0, i, bottom_border)
    for j, fld in ipairs(fieldMap[area].applySheet) do
      if fld.fieldId ~= "" then
        worksheet:write(9+i, j,  item[fld.fieldId], bottom_border)
      else
        worksheet:write(9+i, j,  "", bottom_border)
      end
    end
    --filling packListSheet item line
    worksheet1:write(10+i, 0, i, bottom_border1)
    for j, fld in ipairs(fieldMap[area].packListSheet) do
      if fld.fieldId ~= "" then
        worksheet1:write(10+i, j,  item[fld.fieldId], bottom_border1)
      else
        worksheet1:write(10+i, j,  "", bottom_border1)
      end
    end
    
    --filling invoiceSheet item line
    worksheet2:write(10+i, 0, i, bottom_border1)
    for j, fld in ipairs(fieldMap[area].invoiceSheet) do
      if fld.fieldId ~= "" then
        worksheet2:write(10+i, j,  item[fld.fieldId], bottom_border1)
      else
        worksheet2:write(10+i, j,  "", bottom_border1)
      end
    end
    
    --filling salesOrderSheet item line
    worksheet3:write(10+i, 0, i, bottom_border1)
    for j, fld in ipairs(fieldMap[area].salesOrderSheet) do
      if fld.fieldId ~= "" then
        worksheet3:write(10+i, j,  item[fld.fieldId], bottom_border1)
      else
        worksheet3:write(10+i, j,  "", bottom_border1)
      end
    end
    
  end

  -- Write a total using a formula.
  worksheet:write(row, 0, "", bottom_border)
  worksheet:write(row, 1, "", bottom_border)
  worksheet:write(row, 2, "", bottom_border)
  worksheet:write(row, 3, "", bottom_border)
  worksheet:write(row, 4, "", bottom_border)
  worksheet:write(row, 5, "", bottom_border)
  worksheet:write(row, 6, "总净重：", bottom_border)
  local sumtab = {"=SUM(H11:H", row , ")"}
  local sumf = table.concat(sumtab)
  worksheet:write(row, 7, sumf, bottom_border)
  sumtab = {"=SUM(J11:J", row , ")"}
  sumf = table.concat(sumtab)
  worksheet:write(row, 8, "总价合计：", bottom_border)
  worksheet:write(row, 9, sumf, bottom_border)
  worksheet:write(row, 10, "", bottom_border)

  --sumarty total for workbook1 using a formula.
  local row1 = row + 1
  worksheet1:write(row1, 0, "", bottom_border)
  worksheet1:write(row1, 1, "Total:", bottom_border)
  worksheet1:write(row1, 2, "", bottom_border)
  worksheet1:write(row1, 3, "", bottom_border)
  worksheet1:write(row1, 4, "", bottom_border)
  worksheet1:write(row1, 5, "", bottom_border)
  worksheet1:write(row1, 6, table.concat({"=SUM(G12:G", row1, ")"}), bottom_border)
  worksheet1:write(row1, 7, "", bottom_border)
  worksheet1:write(row1, 8, table.concat({"=SUM(I12:I", row1, ")"}), bottom_border)
  worksheet1:write(row1, 9, table.concat({"=SUM(J12:J", row1, ")"}), bottom_border)
  worksheet1:write(row1, 10, table.concat({"=SUM(K12:K", row1, ")"}), bottom_border)
  
  worksheet1:merge_range(table.concat({"A", row+3 , ":B", row+3}), table.concat({"SAY TOTAL  ", dataTab[1].PalletQty, " Pallet ", dataTab[1].CartonQty, " carton"}), merge1_10)
  worksheet1:merge_range(table.concat({"H", row+5 , ":K", row+7}), info[area][plant].companyName, merge1_10)
  
  worksheet2:write(row1, 0, "", bottom_border)
  worksheet2:write(row1, 1, "Total:", bottom_border)
  worksheet2:write(row1, 2, "", bottom_border)
  worksheet2:write(row1, 3, "", bottom_border)
  worksheet2:write(row1, 4, "", bottom_border)
  worksheet2:write(row1, 5, "", bottom_border)
  worksheet2:write(row1, 6, table.concat({"=SUM(G12:G", row1, ")"}), bottom_border)
  
  worksheet2:write(row1, 7, "", bottom_border)
  worksheet2:write(row1, 8, "", bottom_border)
  worksheet2:write(row1, 9, table.concat({"=SUM(J12:J", row1 , ")"}), bottom_border)
  worksheet2:write(row1, 10, "", bottom_border)
  
  worksheet2:merge_range(table.concat({"I", row+5 , ":L", row+7}), info[area][plant].companyName, merge1_10)
  
  worksheet3:write(row1, 0, "", bottom_border)
  worksheet3:write(row1, 1, "Total:", bottom_border)
  worksheet3:write(row1, 2, "", bottom_border)
  worksheet3:write(row1, 3, "", bottom_border)
  worksheet3:write(row1, 4, "", bottom_border)
  worksheet3:write(row1, 5, "", bottom_border)
  worksheet3:write(row1, 6, table.concat({"=SUM(G12:G", row1, ")"}), bottom_border)
  
  worksheet3:write(row1, 7, "", bottom_border)
  worksheet3:write(row1, 8, "", bottom_border)
  worksheet3:write(row1, 9, table.concat({"=SUM(J12:J", row1 , ")"}), bottom_border)
  worksheet3:write(row1, 10, "", bottom_border)
  
  worksheet3:merge_range(table.concat({"H", row+5 , ":K", row+7}), info[area][plant].companyName, merge1_10)
  
  worksheet:fit_to_pages(1, 0)
  worksheet1:fit_to_pages(1, 0)
  worksheet2:fit_to_pages(1, 0)
  worksheet3:fit_to_pages(1, 0)
  worksheet:set_landscape()
  worksheet1:set_landscape()
  worksheet2:set_landscape()
  worksheet3:set_landscape()

  workbook:close()
  workbook1:close()
  return true
end

ngx.req.read_body() 
local post_args,argserr = ngx.req.get_post_args() 
if  post_args.data == nil then
  ngx.say("err:", argserr)
end
local postData = core.json.decode(post_args.data)
local cnExport = xlsxExport("CN", postData)
local hkExport = xlsxExport("HK", postData)
if cnExport and hkExport then
  --ngx.redirect('/file/')
  ngx.say(core.json.encode({msg="successful export"}))
end