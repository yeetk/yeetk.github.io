local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

--[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select f_code from t_stock_list"
local selres, selerr = stockdb(isql)

local uri = "http://www.cninfo.com.cn/data/project/commonInterface"
local fieldmap = {营业收入="f_yysr", 营业成本="f_yycb", 营业利润="f_yylr", 利润总额="f_lrze", 所得税="f_sds", 净利润="f_jlr"}

for k, row in ipairs(selres) do
  for i=1,4 do
    --获取利润表
    local res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1075&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if res and res.status < 300 then
      
      --core.log.info("res: ", res.body)
      local api1075 = core.json.decode(res.body)
      if api1075 then
        for l, item in ipairs(api1075) do
          if fieldmap[item.index] then
            for m, value in pairs(item) do
              --insert into t_stock_idx (f_code, f_year, f_rtype, f_) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_code, f_year, f_rtype) do update set f_='';
              
              if m ~= "index" and tostring(value) ~= "userdata: NULL" then
                isql = "insert into t_stock_idx (f_code, f_year, f_rtype, " .. fieldmap[item.index] .. ") values(" .. pgsql_str(row.f_code) .. "," .. m .. "," .. i .. "," .. value ..") ON CONFLICT(f_code, f_year, f_rtype) do update set " .. fieldmap[item.index] .. "=" .. value
                local insres, inserr = stockdb(isql)
                
              end
            end
          end
          
        end
      end
    end
    
    --[[
    --获取现金流量表
    res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1076&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if not res then
      --return 500, err
      core.response.exit(500, {errmsg = err})
    end

    if res.status >= 300 then
      --return res.status, res.body
      core.response.exit(res.status, res.body)
    end

    --core.log.info("res: ", res.body)
    local api1076 = core.json.decode(res.body)
    
    --获取资产负债表
    res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1077&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if not res then
      --return 500, err
      core.response.exit(500, {errmsg = err})
    end

    if res.status >= 300 then
      --return res.status, res.body
      core.response.exit(res.status, res.body)
    end

    --core.log.info("res: ", res.body)
    local api1077 = core.json.decode(res.body)
    --]]
  end
end
return 200, {msg = "successful run"}