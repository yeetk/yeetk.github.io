local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

--更新价格连涨天数

local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

--[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select * from t_stock_list"
local selres, selerr = stockdb(isql)

local uri = "http://www.cninfo.com.cn/data/project/commonInterface"
--local fieldmap = {营业收入="f_yysr", 营业成本="f_yycb", 营业利润="f_yylr", 利润总额="f_lrze", 所得税="f_sds", 净利润="f_jlr", 流动资产="f_current_assets", 总负债="f_liability"}
local insres, inserr
for k, row in ipairs(selres) do
  --for i=1,4 do
    --获取分红信息
    local res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1073&paramStr=%40limit%3D1%3B%40orderby%3DF013D%3Adesc%3Bscode%3D" .. row.f_code,
        ssl_verify = false,
    })

    --core.log.info("updating: ", row.f_code)
    
    if res and res.status < 300 then
      
      --core.log.info("res: ", res.body)
      local api1073 = core.json.decode(res.body)
      if api1073 then
        for l, item in ipairs(api1073) do
          --insert into t_stock_idx (f_code, f_year, f_rtype, f_) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_code, f_year, f_rtype) do update set f_='';
          local F010N = 0
          local F011N = 0
          local F012N = 0
          local F013D = "0001-01-01"
          local F014D = "0001-01-01"
          local F015D = "0001-01-01"
          local F016D = "0001-01-01"
          local F017D = "0001-01-01"
          if tostring(item.F010N) ~= "userdata: NULL" then
            F010N = item.F010N
          end
          if tostring(item.F011N) ~= "userdata: NULL" then
            F011N = item.F011N
          end
          if tostring(item.F012N) ~= "userdata: NULL" then
            F012N = item.F012N
          end
          if tostring(item.F013D) ~= "userdata: NULL" then
            F013D = string.gsub(item.F013D, "/", "-")
          end
          if tostring(item.F014D) ~= "userdata: NULL" then
            F014D = string.gsub(item.F014D, "/", "-")
          end
          if tostring(item.F015D) ~= "userdata: NULL" then
            F015D = string.gsub(item.F015D, "/", "-")
          end
          if tostring(item.F016D) ~= "userdata: NULL" then
            F016D = string.gsub(item.F016D, "/", "-")
          end
          if tostring(item.F017D) ~= "userdata: NULL" then
            F017D = string.gsub(item.F017D, "/", "-")
          end
          isql = "insert into t_stock_div (f_code, f_decdate, f_exdivdate, f_bookdate, f_paydate, f_ratdate, f_payment, f_ration, f_allocation) values(" .. pgsql_str(row.f_code) .. "," .. pgsql_str(F013D) .. "," .. pgsql_str(F014D) .. "," .. pgsql_str(F015D) .. "," .. pgsql_str(F016D) .. "," .. pgsql_str(F017D) .. "," .. F010N .. "," .. F011N .. "," .. F012N .. ") ON CONFLICT DO NOTHING"
          insres, inserr = stockdb(isql)
        end
        ngx.say(row.f_code .. " updated,\n")
      end
    end
  
end