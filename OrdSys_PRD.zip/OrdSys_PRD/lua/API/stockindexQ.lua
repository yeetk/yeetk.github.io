local core = require("apisix.core")
local get_method = ngx.req.get_method
--local str_lower = string.lower
local require = require
local ngx = ngx
local cjson = require("cjson")
local format = string.format
local pgsql_str = core.pg.quote_pgsql_str
local new_tab = require "table.new"
local ngx_re = require "ngx.re"
local pgmoon = require("pgmoon")

local function stockdb (sql)
  local pg, err = pgmoon.new({
    host = "127.0.0.1",
    port = "5432",
    database = "stockdb",
    user = "postgres",
    password = "112233"
  })
  if not pg then
      --return nil, err
      core.log.info("error: ", err)
  end
  local ok, err = pg:connect()
  if not ok then
      --return nil, err
      core.log.info("error: ", err)
  end
  --core.log.info("sql: ", sql)
  local res, err = pg:query(sql)
  --local insres, err = core.pg.query(sql)
  
  if not res then
      --return 204, {errmsg = err}
      core.log.info("error: ", err)
      core.response.exit(204, err)
  end
  pg:keepalive()    
  --core.log.info("res: ", res)
  return res, err
end

---[[
ngx.req.read_body()
local req_body = ngx.req.get_body_data()
local req_head = ngx.req.get_headers()
local value = ngx.req.get_post_args()
--]]
--local re_res, re_err = ngx_re.split(row["证券代码"], "-")


local isql = "select f_code from t_stock_list"
local selres, selerr = stockdb(isql)

local uri = "http://www.cninfo.com.cn/data/project/commonInterface"
local fieldmap = {营业收入="f_yysr", 营业成本="f_yycb", 营业利润="f_yylr", 利润总额="f_lrze", 所得税="f_sds", 净利润="f_jlr", 流动资产="f_current_assets", 总负债="f_liability"}

for k, row in ipairs(selres) do
  --for i=1,4 do
    --获取利润表
    local res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1075&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. value.rtype .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    core.log.info("updating: ", row.f_code)
    
    if res and res.status < 300 then
      
      --core.log.info("res: ", res.body)
      local api1075 = core.json.decode(res.body)
      if api1075 then
        for l, item in ipairs(api1075) do
          if fieldmap[item.index] then
            for m, val in pairs(item) do
              --insert into t_stock_idx (f_code, f_year, f_rtype, f_) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_code, f_year, f_rtype) do update set f_='';
              
              if m == value.year and tostring(val) ~= "userdata: NULL" then
                isql = "insert into t_stock_idx (f_code, f_year, f_rtype, " .. fieldmap[item.index] .. ") values(" .. pgsql_str(row.f_code) .. "," .. m .. "," .. value.rtype .. "," .. val ..") ON CONFLICT(f_code, f_year, f_rtype) do update set " .. fieldmap[item.index] .. "=" .. val
                local insres, inserr = stockdb(isql)
                
              end
            end
          end
          
        end
      end
    end
    
    --获取资产负债表
    res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1077&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. value.rtype .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if res and res.status < 300 then
      
      --core.log.info("res: ", res.body)
      local api1077 = core.json.decode(res.body)
      if api1077 then
        for l, item in ipairs(api1077) do
          if fieldmap[item.index] then
            for m, val in pairs(item) do
              --insert into t_stock_idx (f_code, f_year, f_rtype, f_) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_code, f_year, f_rtype) do update set f_='';
              
              if m == value.year and tostring(val) ~= "userdata: NULL" then
                isql = "insert into t_stock_idx (f_code, f_year, f_rtype, " .. fieldmap[item.index] .. ") values(" .. pgsql_str(row.f_code) .. "," .. m .. "," .. value.rtype .. "," .. val ..") ON CONFLICT(f_code, f_year, f_rtype) do update set " .. fieldmap[item.index] .. "=" .. val
                local insres, inserr = stockdb(isql)
                
              end
            end
          end
          
        end
      end
    end
    
    --获取股本结构
    res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=cninfo5017&paramStr=%40limit%3D1%3B%40orderby%3DVARYDATE%3Adesc%3Bscode%3D" .. row.f_code,
        ssl_verify = false,
    })

    if res and res.status < 300 then
      
      --core.log.info("res: ", res.body)
      local cninfo5017 = core.json.decode(res.body)
      if cninfo5017 then
        for l, item in ipairs(cninfo5017) do
          
          --insert into t_stock_idx (f_code, f_year, f_rtype, f_) values('1', 'long long ago', '', '8400001') ON CONFLICT(f_code, f_year, f_rtype) do update set f_='';
          --local re_res, re_err = ngx_re.split(row["证券代码"], "-")
          --local m, re_err = ngx_re.split(item["VARYDATE"], "-")
          
          --if item["F021N"] then
            isql = "insert into t_stock_idx (f_code, f_year, f_rtype, f_circulate_shares, f_all_shares) values(" .. pgsql_str(row.f_code) .. "," .. value.year .. "," .. value.rtype .. "," .. item.F021N .. "," .. item.F003N ..") ON CONFLICT(f_code, f_year, f_rtype) do update set f_circulate_shares=" .. item.F021N ..", f_all_shares=" .. item.F003N
            local insres, inserr = stockdb(isql)
            
          --end
          
        end
      end
    end
    
    --[[
    --获取现金流量表
    res, err = core.http.request_uri(uri, {
        method = "POST",
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["Referer"] = "http://webapi.cninfo.com.cn/",
            --["mcode"] = value.mcode,
        },
        body = "mergerMark=sysapi1076&paramStr=scode%3D" .. row.f_code .. "%3Brtype%3D" .. i .. "%3Bsign%3D1",
        ssl_verify = false,
    })

    if not res then
      --return 500, err
      core.response.exit(500, {errmsg = err})
    end

    if res.status >= 300 then
      --return res.status, res.body
      core.response.exit(res.status, res.body)
    end

    --core.log.info("res: ", res.body)
    local api1076 = core.json.decode(res.body)
    

    --]]
  --end
  
  ngx.say(row.f_code .. " updated,\n")
end
return 200, {msg = "successful run"}