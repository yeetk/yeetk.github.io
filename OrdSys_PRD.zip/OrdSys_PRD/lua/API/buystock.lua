--ngx.exec("/echo")转场
				
	local cjson = require "cjson"
	local encode_array = require("pgmoon.arrays").encode_array
	local pgmoon = require("pgmoon")
	local pg = pgmoon.new({
	  host = "127.0.0.1",
	  port = "5432",
	  database = "stockdb",
	  user = "postgres",
	  password = "112233"
	})
	
	--local my_array = {}
	--local code,cost,name,trader,volume
	local fields = " "
	local fvalues = ""
	ngx.req.read_body()
	local args, reqerr = ngx.req.get_post_args()
	-- local posi = ""
	if reqerr == "truncated" then
		 -- one can choose to ignore or reject the current request here
	 end

	if not args then
		 ngx.say("failed to get post args: ", reqerr)
		 return
	end
	local i = 0
	for key, val in pairs(args) do
		i = i+1
		if type(val) == "table" then
			ngx.say(key, ": ", table.concat(val, ", "))
		else
			ngx.say(key, ": ", val)
			--[[
			if key == "code" then
				code = val
			end
			if key == "cost" then
				cost = tonumber(val)
			end
			if key == "name" then
				name = val
			end
			if key == "trader" then
				trader = val
			end
			if key == "volume" then
				volume = tonumber(val)
			end
			]]
			fields = fields .. "f_" .. key
			
			if key == "cost" or key == "volume" or key == "risk" then
				fvalues = fvalues .. val
			else
				fvalues = fvalues .. "'" .. val .. "'"
			end
			
			if i < 7 then
				fields = fields .. ","
				fvalues = fvalues .. ","
			end
			
		end
	end
	
	pg:connect()
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	--ngx.say(type(my_array))
	--ngx.say(table.concat(my_array,","))
	local sql = "insert into \"t_position\" (" .. fields .. ") values(" .. fvalues .. ")"
	ngx.say(sql)
	--local res, err, partial, num_queries = pg:query(pg:escape_literal(sql))
	local res, err, partial, num_queries = pg:query(sql)
	--local res, err, partial, num_queries = pg:query("insert into \"t_position\" (\"f_code\",\"f_cost\",\"f_name\",\"f_trader\",\"f_volume\") values(" .. encode_array(my_array) .. ")")
	ngx.say(err)
	--[[
	--local res = pg:query("select * from t_game where f_posi = " .. pg:escape_literal(posi))
	
	ngx.say(type(res))
	
	-- cjson性能似乎不如for嵌套
	local json = cjson.encode(res)
	ngx.say(json)
	]]
	--ngx.header["Location"] = "http://www.sogou.com"
	
	
	--[[
	for key, val in ipairs(res) do
		if type(val) == "table" then
			--ngx.say(key, ": ", table.concat(val, ", "))
			for k, v in pairs(val) do
				if type(v) == "table" then
					ngx.say(k, ": ", table.concat(v, ", "))
				else
					ngx.say(k, ": ", v)
				end
			end
		else
			ngx.say(key, ": ", val)
			ngx.say(type(val))
		end
	end
	]]