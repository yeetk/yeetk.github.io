function postAsync(url, data, callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("POST", url, true); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
		req.send(urlencodeFormData(data));
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
					//console.log(req.responseText);
					//var reply = req.responseText; 
					//return reply;
				}
				else if(req.status == 401){
                    
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                }
				else{
					return "XHR error: " + req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for getAsync is undefined");
	}
}

function postAsyncXML(url, data, callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("POST", url, true); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','text/xml')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
					//console.log(req.responseText);
					//var reply = req.responseText; 
					//return reply;
				}else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else if(req.status == 401){
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return "XHR error: " + req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for postAsync is undefined");
	}
}

function postAsyncJSON(url, data, callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("POST", url, true); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','application/json')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
				}
				else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
                else if(req.status == 401){
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                    return false;
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for postAsyncJSON is undefined");
	}
}

function postSyncJSON(url, data, callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("POST", url, false); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','application/json')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
				}
				else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
                else if(req.status == 401){
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                    return false;
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for postAsyncJSON is undefined");
	}
}

function anyAsyncJSON(method, url, data, callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open(method, url, true); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','application/json')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
				}
				else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
                else if(req.status == 401){
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                    return false;
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for anyAsyncJSON is undefined");
	}
}

function anySyncJSON(method, url, data, callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open(method, url, false); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','application/json')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
				}
				else if(req.status == 204){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
                else if(req.status == 401){
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                    return false;
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for anySyncJSON is undefined");
	}
}

function putAsync(url, data,callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("PUT", url, true); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
		req.send(urlencodeFormData(data));
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
					//console.log(req.responseText);
					//var reply = req.responseText; 
					//return reply;
				}else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else if(req.status == 401){
                    gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return "XHR error: " + req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for getAsync is undefined");
	}
    
}

function getAsync(url, data,callback)    {
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("GET", url, true); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','text/plain')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
					//console.log(req.responseText);
					var reply = req.responseText; 
					return reply;
				}else if(req.status == 400){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else if(req.status == 401){
                    console.log(req);
                    //gotoLogin();
                }
                else if(req.status == 403){
                    authErr();
                }else if(req.status == 500){
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
                    //return req;
                }
				else{
					return "XHR error: " + req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for getAsync is undefined");
	}
    
}

function getSync(url, data,callback)    {
    //console.log(callback);
    var req;
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
    if (req != undefined) {
        // req.overrideMimeType("application/json"); // if request result is JSON
        try {
			req.open("GET", url, false); // 3rd param is whether "async"
        }
        catch(err) {
			alert("couldnt complete request. Is JS enabled for that domain?\\n\\n" + err.message);
			return false;
        }
		req.setRequestHeader('Content-Type','text/plain')
		req.send(data);
        //req.send(data); // param string only used for POST

        req.onreadystatechange=function(){
			if (req.readyState == 4) { // only if req is "loaded"
				if (req.status == 200){  // only if "OK"
					// defensive check
					if (typeof callback === "function") {
						// apply() sets the meaning of "this" in the callback
						callback.apply(req.responseText);
					}
					console.log(req.responseText);
					var reply = req.responseText; 
					return reply;
				}
				else if(req.status == 401){
                    gotoLogin(req);
                }
                else if(req.status == 403){
                    authErr();
                    return false;
                }
				else{
					return "XHR error: " + req.status +" "+req.statusText; 
				}
			}
		}
	}
	else{
		alert("req for getAsync is undefined");
	}
    
}

function gotoLogin(){
    window.location.href='login.html';
    //return "XHR error: " + req.status +" "+req.statusText; 
}

function authErr(){
    alert("No Authorization");
    
    //return "XHR error: " + req.status +" "+req.statusText; 
}

function urlencodeFormData(fd){
    var s = '';
    function encode(s){ return encodeURIComponent(s).replace(/%20/g,'+'); }
    for(var pair of fd.entries()){
        if(typeof pair[1]=='string'){
            s += (s?'&':'') + encode(pair[0])+'='+encode(pair[1]);
        }
    }
    return s;
}


/*
var form = document.myForm;
xhr.open('POST', form.action, false);
xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
xhr.send(urlencodeFormData(new FormData(form)));



var var_str = "var1=" + var1  + "&var2=" + var2;
var ret = postAsync(url, var_str) ;
    // hint: encodeURIComponent()

if (ret.match(/^XHR error/)) {
    console.log(ret);
    return;
    }
	
	
var xhr = new XMLHttpRequest(),
    fd = new FormData();

fd.append( 'file', input.files[0] );
xhr.open( 'POST', 'http://example.com/script.php', true );
xhr.onreadystatechange = handler;
xhr.send( fd );

*/
