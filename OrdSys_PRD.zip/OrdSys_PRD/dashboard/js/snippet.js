//	<script language="javascript">
//	<script language="javascript"></script>
		function updateurl(){
			//console.log(document.getElementById('i1').labels[0].innerHTML);
			document.getElementById('form').action = document.getElementById('formurl').value;
			console.log(document.getElementById('form').action);
		}
		function getinf(){
			
			if(document.getElementById('i0').value){
				var codestring;
				if(Number(document.getElementById('i0').value)>499999){
					codestring = "sh" + document.getElementById('i0').value;
				}
				else{
					codestring = "sz" + document.getElementById('i0').value;
				}
				var geturl = "http://qt.gtimg.cn/q=" + codestring;
				minAjax({
					url: geturl,//request URL
					type:"GET",//Request type GET/POST
					//Send Data in form of GET/POST
					data:{},
					//CALLBACK FUNCTION with RESPONSE as argument
					success: function(data){
						var dataarr=data.split("~")
						//alert(dataarr);
						console.log(dataarr);
						document.getElementById('i1').value = dataarr[1];
						document.getElementById('i2').value = Number(dataarr[3]);
						//price = Number(dataarr[3]);
						if(document.getElementById('i9').value && document.getElementById('i8').value){
							document.getElementById('i7').value = Number(dataarr[3]) * Number(document.getElementById('i8').value) / 100;
							var hand = (Number(document.getElementById('i9').value) * 2) / Number(dataarr[3]);//*1000/5,/100=*2
							document.getElementById('i3').value = hand.toFixed(0);
							//console.log(price);
							//console.log(Number(document.getElementById('i8').value));
						}
					}
				});
			}
			
		}
		
		function buy(){
			var oForm = document.getElementById('form');
			var fd = new FormData(oForm);
			var cb = function(){
				var ret = this;
				console.log(ret);
				getPosition();
			}
			postAsync(oForm.action, fd, cb);
			// hint: encodeURIComponent()
			
			/*if (ret.match(/^XHR error/)) {
				
				return;
			}*/
		}
		
		function updateTable(tableData) {
		  //var table = document.createElement('table');
		  var tableBody = document.getElementById('tbody');
		  tableBody.innerHTML = "";
		  tableData.forEach(function(rowData) {
			var row = document.createElement('tr');

			rowData.forEach(function(cellData) {
			  var cell = document.createElement('td');
			  cell.appendChild(document.createTextNode(cellData));
			  row.appendChild(cell);
			});
			tableBody.appendChild(row);
		  });

		  //table.appendChild(tableBody);
		  //document.body.appendChild(table);
		}
		
		function getPosition() {
			//改读取数据库
			tdata = [];
			var oForm = document.getElementById('form');
			var fd = new FormData(oForm);
			var cb = function(){
				var ret = this;
				console.log(ret);
				tdata = JSON.parse(ret);
				//循环获取历史日数据
				for(var i=0;i<tdata.length;i++){
					if(Number(tdata[i][0])>499999){
						var stockcode = "sh" + tdata[i][0] + ".js";
					}
					else{
						var stockcode = "sz" + tdata[i][0] + ".js";
					}
					//var stockcodes = stockcodes + stockcode + ",";
					var geturl = "http://data.gtimg.cn/flashdata/hushen/latest/daily/" + stockcode;
					minAjax({
						url: geturl,//request URL
						type:"GET",//Request type GET/POST
						//Send Data in form of GET/POST
						data:{},
						//CALLBACK FUNCTION with RESPONSE as argument
						success: function(data){
							var dataarr=data.split("\\n\\");
							//alert(dataarr);
							console.log(dataarr);
							// = dataarr[dataarr.length-1];
							// = Number(dataarr[3]);
							//price = Number(dataarr[3]);
							/*if(document.getElementById('i9').value && document.getElementById('i8').value){
								document.getElementById('i7').value = Number(dataarr[3]) * Number(document.getElementById('i8').value) / 100;
								var hand = (Number(document.getElementById('i9').value) * 2) / Number(dataarr[3]);//*1000/5,/100=*2
								document.getElementById('i3').value = hand.toFixed(0);
								//console.log(price);
								//console.log(Number(document.getElementById('i8').value));
							}*/
						}
					});
				}
				
				
				updateTable(tdata);
			}
			postAsync('http://hyutd.com/position', fd, cb);
		}
		
		window.onload=function(){
			getPosition();
		} 
		
//	</script>