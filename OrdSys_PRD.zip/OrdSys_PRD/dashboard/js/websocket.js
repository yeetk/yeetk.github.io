var ws = null;
function connect() {
  var wsurl = "";
  var stockcodes = "";
  if(tdata){
	for(var i=0;i<tdata.length;i++){
		if(Number(tdata[i][0])>499999){
			var stockcode = "sh" + tdata[i][0];
		}
		else{
			var stockcode = "sz" + tdata[i][0];
		}
		var stockcodes = stockcodes + stockcode + ",";
		
	}
	wsurl = "ws://hq.sinajs.cn/wskt?list=" + stockcodes;
	console.log(wsurl);
  }
   
  if (ws !== null) return log('already connected');
  ws = new WebSocket(wsurl);
  //ws = new WebSocket('ws://qt.gtimg.cn/wskt?q=sh600881');
  ws.onopen = function () {
	log('connected');
  };
  ws.onerror = function (error) {
	log(error);
  };
  ws.onmessage = function (e) {
	log('recv: ' + e.data);
	var stockdata = e.data.split(/[\n]/)
	//var testdata = e.data.split(/[\s\n]/)
	//console.log(testdata);
	for(var j=0;j<stockdata.length;j++){
		var msgarr = stockdata[j].split("=");
		//msgarr[0]编码
		if(msgarr[1]){
			var pricearr = msgarr[1].split(",");
		}
		for(var i=0;i<tdata.length;i++){
			if(msgarr[0].substr(2,6)==tdata[i][0]){
				//console.log(pricearr);
				tdata[i][1] = pricearr[0];
				tdata[i][5] = pricearr[3];
				
				if(Number(tdata[i][6]) < Number(pricearr[4])){
					tdata[i][6] = pricearr[4];
				}
				var num = tdata[i][6] - tdata[i][3];
				tdata[i][7] = num.toFixed(2);
			}
		}
	}
	updateTable(tdata);
  };
  ws.onclose = function () {
	log('disconnected');
	ws = null;
  };
  startWorker();
  return false;
}
function disconnect() {
  if (ws === null) return log('already disconnected');
  ws.close();
  return false;
}
function send() {
	if (ws === null){
		connect();
		return log('connect first');
	} 
  //var nb = document.getElementById('i0').value;
  //document.getElementById('text').value = "";
  //var text =
  var codestring = " ";
  /*if(Number(document.getElementById('i0').value)>499999){
	codestring = "sh" + document.getElementById('i0').value;
  }
  else{
	codestring = "sz" + document.getElementById('i0').value;
  }*/
  log('send: ' + codestring);
  ws.send(codestring);
  return false;
}
function log(text) {
  //var li = document.createElement('li');
  //li.appendChild(document.createTextNode(text));
  //document.getElementById('log').appendChild(li);
  console.log(text);
  return false;
}

//Web Worker
var w;
function startWorker(){
	if(typeof(Worker)!=="undefined"){
		if(typeof(w)=="undefined"){
			w=new Worker("./worker/worker.js");
			console.log("worker started!");
		}
		w.onmessage = function (event){
			send();
			document.getElementById("message").innerHTML=event.data;
		};
	}
	else
	  {
	  document.getElementById("message").innerHTML="Sorry, your browser does not support Web Workers...";
	  }
}

function stopWorker(){ 
	w.terminate();
}