//alert("createDeliveryNote.js loaded and runing");
//insert programm private js file to head
var script = document.createElement("script");
script.type = "text/javascript";
script.src = "js/xml2json.min.js";
document.getElementsByTagName("head")[0].appendChild(script);
var oCreateDate = document.getElementById("10005-CreationDate");
var oDate =  new Date();
oCreateDate.innerText = oDate.getFullYear() + "/" + (oDate.getMonth()+1) + "/" + oDate.getDate();
//
var UoM = {
    "%":{"SAPCode":"%","ISOCode":"P1","TechnicalName":"%"},"%O":{"SAPCode":"%O","ISOCode":"","TechnicalName":"%O"},"ONE":{"SAPCode":"1","ISOCode":"","TechnicalName":"One"},"D":{"SAPCode":"10","ISOCode":"DAY","TechnicalName":"d"},"22S":{"SAPCode":"22S","ISOCode":"","TechnicalName":"mm2/s"},"CMS":{"SAPCode":"2M","ISOCode":"2M","TechnicalName":"cm/s"},"000":{"SAPCode":"2X","ISOCode":"2X","TechnicalName":"m/min"},"µL":{"SAPCode":"4G","ISOCode":"4G","TechnicalName":"µl"},"µF":{"SAPCode":"4O","ISOCode":"4O","TechnicalName":"µF"},"PF":{"SAPCode":"4T","ISOCode":"4T","TechnicalName":"pF"},"A":{"SAPCode":"A","ISOCode":"AMP","TechnicalName":"A"},"GOH":{"SAPCode":"A87","ISOCode":"A87","TechnicalName":"GOhm"},"GM3":{"SAPCode":"A93","ISOCode":"A93","TechnicalName":"g/m3"},"ACR":{"SAPCode":"ACR","ISOCode":"ACR","TechnicalName":"acre"},"KD3":{"SAPCode":"B34","ISOCode":"B34","TechnicalName":"kg/dm3"},"KML":{"SAPCode":"B45","ISOCode":"B45","TechnicalName":"kmol"},"NI":{"SAPCode":"B47","ISOCode":"B47","TechnicalName":"ND"},"MN":{"SAPCode":"B73","ISOCode":"B73","TechnicalName":"MN"},"MGO":{"SAPCode":"B75","ISOCode":"B75","TechnicalName":"MOhm"},"MHV":{"SAPCode":"B78","ISOCode":"B78","TechnicalName":"MV"},"µA":{"SAPCode":"B84","ISOCode":"B84","TechnicalName":"µA"},"BAG":{"SAPCode":"BAG","ISOCode":"BG","TechnicalName":"Bag"},"BAR":{"SAPCode":"BAR","ISOCode":"BAR","TechnicalName":"bar"},"003":{"SAPCode":"BB6","ISOCode":"","TechnicalName":"000003"},"004":{"SAPCode":"BBL","ISOCode":"","TechnicalName":"000004"},"005":{"SAPCode":"BCF","ISOCode":"","TechnicalName":"000005"},"BT":{"SAPCode":"BOT","ISOCode":"BO","TechnicalName":"Bt."},"BQK":{"SAPCode":"BQK","ISOCode":"A18","TechnicalName":"Bq/kg"},"BTU":{"SAPCode":"BTU","ISOCode":"","TechnicalName":"Btu"},"006":{"SAPCode":"BUI","ISOCode":"","TechnicalName":"000006"},"007":{"SAPCode":"BUU","ISOCode":"","TechnicalName":"000007"},"Bqm":{"SAPCode":"Bqm","ISOCode":"","TechnicalName":"Bq/m3"},"RF":{"SAPCode":"C10","ISOCode":"C10","TechnicalName":"mF"},"M/M":{"SAPCode":"C36","ISOCode":"C36","TechnicalName":"mol/m3"},"M/L":{"SAPCode":"C38","ISOCode":"C38","TechnicalName":"Mol/l"},"NA":{"SAPCode":"C39","ISOCode":"C39","TechnicalName":"nA"},"C3S":{"SAPCode":"C3S","ISOCode":"2J","TechnicalName":"cm3/s"},"R-U":{"SAPCode":"C41","ISOCode":"C41","TechnicalName":"nF"},"NMM":{"SAPCode":"C56","ISOCode":"C56","TechnicalName":"N/mm2"},"CCK":{"SAPCode":"CCK","ISOCode":"CCK","TechnicalName":"CCK"},"CCM":{"SAPCode":"CCM","ISOCode":"CMQ","TechnicalName":"cm3"},"CD":{"SAPCode":"CD","ISOCode":"CDL","TechnicalName":"cd"},"CD3":{"SAPCode":"CDM","ISOCode":"DMQ","TechnicalName":"dm3"},"CM":{"SAPCode":"CM","ISOCode":"CMT","TechnicalName":"cm"},"CM2":{"SAPCode":"CM2","ISOCode":"CMK","TechnicalName":"cm2"},"CMH":{"SAPCode":"CMH","ISOCode":"","TechnicalName":"cm/h"},"CV":{"SAPCode":"CS","ISOCode":"CS","TechnicalName":"Case"},"CL":{"SAPCode":"CTL","ISOCode":"CLT","TechnicalName":"Cl"},"S/M":{"SAPCode":"D10","ISOCode":"D10","TechnicalName":"S/m"},"TOM":{"SAPCode":"D41","ISOCode":"D41","TechnicalName":"t/m3"},"VAM":{"SAPCode":"D46","ISOCode":"D46","TechnicalName":"VAM"},"dBA":{"SAPCode":"DBA","ISOCode":"","TechnicalName":"dB(A)"},"dBC":{"SAPCode":"DBC","ISOCode":"","TechnicalName":"dB(C)"},"DEG":{"SAPCode":"DEG","ISOCode":"DD","TechnicalName":"deg"},"DGP":{"SAPCode":"DGP","ISOCode":"","TechnicalName":"DGP"},"DM":{"SAPCode":"DM","ISOCode":"DMT","TechnicalName":"dm"},"DR":{"SAPCode":"DR","ISOCode":"DR","TechnicalName":"Dr"},"DZ":{"SAPCode":"DZ","ISOCode":"DZN","TechnicalName":"dz"},"EA":{"SAPCode":"EA","ISOCode":"EA","TechnicalName":"EA"},"EU":{"SAPCode":"EE","ISOCode":"","TechnicalName":"EU"},"EML":{"SAPCode":"EML","ISOCode":"","TechnicalName":"EU/ml"},"F":{"SAPCode":"F","ISOCode":"FAR","TechnicalName":"F"},"°F":{"SAPCode":"FA","ISOCode":"FAH","TechnicalName":"°F"},"FT":{"SAPCode":"FT","ISOCode":"FOT","TechnicalName":"Foot"},"FT2":{"SAPCode":"FT2","ISOCode":"FTK","TechnicalName":"ft2"},"FT3":{"SAPCode":"FT3","ISOCode":"FTQ","TechnicalName":"ft3"},"G":{"SAPCode":"G","ISOCode":"GRM","TechnicalName":"g"},"G/L":{"SAPCode":"G/L","ISOCode":"","TechnicalName":"gai/l"},"GAU":{"SAPCode":"GAU","ISOCode":"","TechnicalName":"GAU"},"°C":{"SAPCode":"GC","ISOCode":"CEL","TechnicalName":"°C"},"GHG":{"SAPCode":"GHG","ISOCode":"","TechnicalName":"g/hg"},"GJ":{"SAPCode":"GJ","ISOCode":"GV","TechnicalName":"GJ"},"GJT":{"SAPCode":"GJT","ISOCode":"","TechnicalName":"GJ/t"},"GKG":{"SAPCode":"GKG","ISOCode":"GK","TechnicalName":"g/kg"},"GLI":{"SAPCode":"GLI","ISOCode":"GL","TechnicalName":"g/l"},"GAL":{"SAPCode":"GLL","ISOCode":"GLL","TechnicalName":"gal US"},"GPM":{"SAPCode":"GLM","ISOCode":"","TechnicalName":"GPM US"},"GM":{"SAPCode":"GM","ISOCode":"","TechnicalName":"g/mol"},"GM2":{"SAPCode":"GM2","ISOCode":"GM","TechnicalName":"g/m2"},"GPH":{"SAPCode":"GPH","ISOCode":"","TechnicalName":"GPH US"},"µGQ":{"SAPCode":"GQ","ISOCode":"GQ","TechnicalName":"µg/m3"},"GRO":{"SAPCode":"GRO","ISOCode":"GRO","TechnicalName":"gro"},"GT":{"SAPCode":"GT","ISOCode":"","TechnicalName":"g/t"},"GAI":{"SAPCode":"GW","ISOCode":"","TechnicalName":"gai"},"H":{"SAPCode":"H","ISOCode":"HUR","TechnicalName":"h"},"HA":{"SAPCode":"HAR","ISOCode":"HAR","TechnicalName":"Hectar"},"HL":{"SAPCode":"HL","ISOCode":"HLT","TechnicalName":"hl"},"HPA":{"SAPCode":"HPA","ISOCode":"A97","TechnicalName":"hPa"},"HZ":{"SAPCode":"HZ","ISOCode":"HTZ","TechnicalName":"Hz"},"\"":{"SAPCode":"IN","ISOCode":"INH","TechnicalName":"\""},"\"2":{"SAPCode":"IN2","ISOCode":"INK","TechnicalName":"Inch2"},"\"3":{"SAPCode":"IN3","ISOCode":"INQ","TechnicalName":"Inch3"},"J":{"SAPCode":"J","ISOCode":"JOU","TechnicalName":"J"},"YR":{"SAPCode":"JHR","ISOCode":"ANN","TechnicalName":"yr"},"JKG":{"SAPCode":"JKG","ISOCode":"J2","TechnicalName":"J/kg"},"JKK":{"SAPCode":"JKK","ISOCode":"B11","TechnicalName":"J/kgK"},"JMO":{"SAPCode":"JMO","ISOCode":"B15","TechnicalName":"J/mol"},"K":{"SAPCode":"K","ISOCode":"KEL","TechnicalName":"K"},"KA":{"SAPCode":"KA","ISOCode":"B22","TechnicalName":"kA"},"CAN":{"SAPCode":"KAN","ISOCode":"CA","TechnicalName":"Can"},"CAR":{"SAPCode":"KAR","ISOCode":"CT","TechnicalName":"Car"},"KBK":{"SAPCode":"KBK","ISOCode":"B25","TechnicalName":"kBq/kg"},"KG":{"SAPCode":"KG","ISOCode":"KGM","TechnicalName":"kg"},"KGF":{"SAPCode":"KGF","ISOCode":"28","TechnicalName":"kg/m2"},"KGH":{"SAPCode":"KGH","ISOCode":"","TechnicalName":"kg/h"},"KGK":{"SAPCode":"KGK","ISOCode":"","TechnicalName":"kg/kg"},"KGM":{"SAPCode":"KGM","ISOCode":"","TechnicalName":"kg/mol"},"KGS":{"SAPCode":"KGS","ISOCode":"KGS","TechnicalName":"kg/s"},"KGT":{"SAPCode":"KGT","ISOCode":"","TechnicalName":"kg/t"},"KGV":{"SAPCode":"KGV","ISOCode":"KMQ","TechnicalName":"kg/m3"},"KAI":{"SAPCode":"KGW","ISOCode":"","TechnicalName":"kgai"},"KHZ":{"SAPCode":"KHZ","ISOCode":"KHZ","TechnicalName":"kHz"},"CRT":{"SAPCode":"KI","ISOCode":"CR","TechnicalName":"Crate"},"KJ":{"SAPCode":"KJ","ISOCode":"KJO","TechnicalName":"kJ"},"KJK":{"SAPCode":"KJK","ISOCode":"B42","TechnicalName":"KJ/kg"},"KJM":{"SAPCode":"KJM","ISOCode":"B44","TechnicalName":"KJ/mol"},"KM":{"SAPCode":"KM","ISOCode":"KMT","TechnicalName":"km"},"KM2":{"SAPCode":"KM2","ISOCode":"KMK","TechnicalName":"km2"},"KMH":{"SAPCode":"KMH","ISOCode":"KMH","TechnicalName":"km/h"},"KMK":{"SAPCode":"KMK","ISOCode":"","TechnicalName":"m3/m3"},"KMN":{"SAPCode":"KMN","ISOCode":"","TechnicalName":"K/min"},"KMS":{"SAPCode":"KMS","ISOCode":"","TechnicalName":"K/s"},"KOH":{"SAPCode":"KOH","ISOCode":"B49","TechnicalName":"kOhm"},"KPA":{"SAPCode":"KPA","ISOCode":"KPA","TechnicalName":"kPa"},"KT":{"SAPCode":"KT","ISOCode":"","TechnicalName":"kt"},"KV":{"SAPCode":"KV","ISOCode":"KVT","TechnicalName":"kV"},"KVA":{"SAPCode":"KVA","ISOCode":"KVA","TechnicalName":"kVA"},"KW":{"SAPCode":"KW","ISOCode":"KWT","TechnicalName":"KW"},"KWH":{"SAPCode":"KWH","ISOCode":"KWH","TechnicalName":"kW.h"},"KIK":{"SAPCode":"KWK","ISOCode":"","TechnicalName":"kai/kg"},"KWM":{"SAPCode":"KWM","ISOCode":"","TechnicalName":"kWh/m3"},"L":{"SAPCode":"L","ISOCode":"LTR","TechnicalName":"l"},"LMI":{"SAPCode":"L2","ISOCode":"L2","TechnicalName":"l/min"},"LB":{"SAPCode":"LB","ISOCode":"LBR","TechnicalName":"lb"},"DYr":{"SAPCode":"LBJ","ISOCode":"","TechnicalName":"lb/yr"},"lbM":{"SAPCode":"LBm","ISOCode":"","TechnicalName":"lb/mth"},"AU":{"SAPCode":"LE","ISOCode":"C62","TechnicalName":"AU"},"LHK":{"SAPCode":"LHK","ISOCode":"","TechnicalName":"l/hkm"},"002":{"SAPCode":"LM","ISOCode":"","TechnicalName":"000002"},"LMS":{"SAPCode":"LMS","ISOCode":"","TechnicalName":"l/m_.s"},"LPH":{"SAPCode":"LPH","ISOCode":"","TechnicalName":"L/hr"},"M":{"SAPCode":"M","ISOCode":"MTR","TechnicalName":"m"},"M%":{"SAPCode":"M%","ISOCode":"","TechnicalName":"%(m)"},"M%O":{"SAPCode":"M%O","ISOCode":"","TechnicalName":"%O(m)"},"M/S":{"SAPCode":"M/S","ISOCode":"MTS","TechnicalName":"m/s"},"M2":{"SAPCode":"M2","ISOCode":"MTK","TechnicalName":"m2"},"M-2":{"SAPCode":"M2I","ISOCode":"","TechnicalName":"1/M2"},"M2S":{"SAPCode":"M2S","ISOCode":"S4","TechnicalName":"m2/s"},"M3":{"SAPCode":"M3","ISOCode":"MTQ","TechnicalName":"m3"},"M3D":{"SAPCode":"M3D","ISOCode":"","TechnicalName":"m3/d"},"M3S":{"SAPCode":"M3S","ISOCode":"MQS","TechnicalName":"m3/s"},"MA":{"SAPCode":"MA","ISOCode":"4K","TechnicalName":"mA"},"MBA":{"SAPCode":"MBA","ISOCode":"MBR","TechnicalName":"mbar"},"008":{"SAPCode":"MBT","ISOCode":"","TechnicalName":"000008"},"MBZ":{"SAPCode":"MBZ","ISOCode":"","TechnicalName":"m.b_/s"},"MEJ":{"SAPCode":"MEJ","ISOCode":"3B","TechnicalName":"MJ"},"MG":{"SAPCode":"MG","ISOCode":"MGM","TechnicalName":"mg"},"MGE":{"SAPCode":"MGF","ISOCode":"","TechnicalName":"mg/cm2"},"MGG":{"SAPCode":"MGG","ISOCode":"","TechnicalName":"mg/g"},"MGJ":{"SAPCode":"MGJ","ISOCode":"","TechnicalName":"g/m3/k"},"MGK":{"SAPCode":"MGK","ISOCode":"NA","TechnicalName":"mg/kg"},"MGL":{"SAPCode":"MGL","ISOCode":"M1","TechnicalName":"mg/l"},"MGQ":{"SAPCode":"MGQ","ISOCode":"GP","TechnicalName":"mg/m3"},"MGT":{"SAPCode":"MGT","ISOCode":"","TechnicalName":"mg/t"},"MGW":{"SAPCode":"MGW","ISOCode":"MAW","TechnicalName":"VA"},"MGq":{"SAPCode":"MGq","ISOCode":"","TechnicalName":"mg/tm3"},"MHZ":{"SAPCode":"MHZ","ISOCode":"MHZ","TechnicalName":"MHz"},"MI":{"SAPCode":"MI","ISOCode":"SMI","TechnicalName":"mile"},"MI2":{"SAPCode":"MI2","ISOCode":"MIK","TechnicalName":"Mile2"},"µM":{"SAPCode":"MIM","ISOCode":"4H","TechnicalName":"µm"},"MIN":{"SAPCode":"MIN","ISOCode":"MIN","TechnicalName":"min"},"MIS":{"SAPCode":"MIS","ISOCode":"B98","TechnicalName":"µs"},"MIJ":{"SAPCode":"MJ","ISOCode":"C15","TechnicalName":"mJ"},"MJK":{"SAPCode":"MJK","ISOCode":"","TechnicalName":"MJ/kg"},"ML":{"SAPCode":"ML","ISOCode":"MLT","TechnicalName":"ml"},"MLK":{"SAPCode":"MLK","ISOCode":"","TechnicalName":"ml/m3"},"MLI":{"SAPCode":"MLW","ISOCode":"","TechnicalName":"mlai"},"MM":{"SAPCode":"MM","ISOCode":"MMT","TechnicalName":"mm"},"MM2":{"SAPCode":"MM2","ISOCode":"MMK","TechnicalName":"mm2"},"MMA":{"SAPCode":"MMA","ISOCode":"","TechnicalName":"mm/a"},"MMG":{"SAPCode":"MMG","ISOCode":"","TechnicalName":"mmol/g"},"MMH":{"SAPCode":"MMH","ISOCode":"","TechnicalName":"mm/h"},"MMK":{"SAPCode":"MMK","ISOCode":"D87","TechnicalName":"m_/kg"},"MMO":{"SAPCode":"MMO","ISOCode":"C18","TechnicalName":"mmol"},"MM3":{"SAPCode":"MMQ","ISOCode":"MMQ","TechnicalName":"mm3"},"MMS":{"SAPCode":"MMS","ISOCode":"C16","TechnicalName":"mm/s"},"MNM":{"SAPCode":"MNM","ISOCode":"C22","TechnicalName":"mN/m"},"MOK":{"SAPCode":"MOK","ISOCode":"C19","TechnicalName":"mol/kg"},"MOL":{"SAPCode":"MOL","ISOCode":"C34","TechnicalName":"mol"},"MON":{"SAPCode":"MON","ISOCode":"MON","TechnicalName":"Months"},"MPA":{"SAPCode":"MPA","ISOCode":"MPA","TechnicalName":"MPa"},"MPB":{"SAPCode":"MPB","ISOCode":"","TechnicalName":"ppb(m)"},"MPG":{"SAPCode":"MPG","ISOCode":"","TechnicalName":"MPG US"},"MPM":{"SAPCode":"MPM","ISOCode":"","TechnicalName":"ppm(m)"},"MPS":{"SAPCode":"MPS","ISOCode":"C24","TechnicalName":"mPa.s"},"MPT":{"SAPCode":"MPT","ISOCode":"","TechnicalName":"ppt(m)"},"MPZ":{"SAPCode":"MPZ","ISOCode":"","TechnicalName":"m.Pa/s"},"M3H":{"SAPCode":"MQH","ISOCode":"MQH","TechnicalName":"m3/h"},"MSE":{"SAPCode":"MS","ISOCode":"C26","TechnicalName":"ms"},"MS2":{"SAPCode":"MS2","ISOCode":"MSK","TechnicalName":"m/s2"},"MTE":{"SAPCode":"MTE","ISOCode":"C29","TechnicalName":"mT"},"MTM":{"SAPCode":"MTM","ISOCode":"","TechnicalName":"Mppcm"},"M/H":{"SAPCode":"MTS","ISOCode":"MTS","TechnicalName":"m/h"},"MTf":{"SAPCode":"MTf","ISOCode":"","TechnicalName":"Mppcf"},"MV":{"SAPCode":"MV","ISOCode":"2Z","TechnicalName":"mV"},"MVA":{"SAPCode":"MVA","ISOCode":"MVA","TechnicalName":"MVA"},"MW":{"SAPCode":"MW","ISOCode":"C31","TechnicalName":"mW"},"MWH":{"SAPCode":"MWH","ISOCode":"MWH","TechnicalName":"MWh"},"N":{"SAPCode":"N","ISOCode":"NEW","TechnicalName":"N"},"NAM":{"SAPCode":"NAM","ISOCode":"C45","TechnicalName":"nm"},"NGT":{"SAPCode":"NGT","ISOCode":"","TechnicalName":"ng/t"},"NM":{"SAPCode":"NM","ISOCode":"4P","TechnicalName":"N/m"},"NS":{"SAPCode":"NS","ISOCode":"C47","TechnicalName":"ns"},"OCM":{"SAPCode":"OCM","ISOCode":"C60","TechnicalName":"Ohcm"},"OHM":{"SAPCode":"OHM","ISOCode":"OHM","TechnicalName":"Ohm"},"OM":{"SAPCode":"OM","ISOCode":"C61","TechnicalName":"Ohmm"},"OZ":{"SAPCode":"OZ","ISOCode":"ONZ","TechnicalName":"oz"},"FOZ":{"SAPCode":"OZA","ISOCode":"OZA","TechnicalName":"foz US"},"P":{"SAPCode":"P","ISOCode":"","TechnicalName":"P"},"PA":{"SAPCode":"PA","ISOCode":"PAL","TechnicalName":"Pa"},"PAA":{"SAPCode":"PAA","ISOCode":"PR","TechnicalName":"PAIR"},"PAC":{"SAPCode":"PAK","ISOCode":"PK","TechnicalName":"PAC"},"PAL":{"SAPCode":"PAL","ISOCode":"PF","TechnicalName":"PAL"},"PAS":{"SAPCode":"PAS","ISOCode":"C65","TechnicalName":"Pas"},"PRC":{"SAPCode":"PCT","ISOCode":"","TechnicalName":"PrC"},"PDA":{"SAPCode":"PDA","ISOCode":"","TechnicalName":"PDays"},"PMI":{"SAPCode":"PMI","ISOCode":"","TechnicalName":"1/min"},"PMR":{"SAPCode":"PMR","ISOCode":"","TechnicalName":"kg/m2s"},"PPB":{"SAPCode":"PPB","ISOCode":"61","TechnicalName":"ppb"},"PPM":{"SAPCode":"PPM","ISOCode":"59","TechnicalName":"ppm"},"PPT":{"SAPCode":"PPT","ISOCode":"","TechnicalName":"ppt"},"PRM":{"SAPCode":"PRM","ISOCode":"","TechnicalName":"ug/c2m"},"PRS":{"SAPCode":"PRS","ISOCode":"IE","TechnicalName":"PRS"},"PS":{"SAPCode":"PS","ISOCode":"","TechnicalName":"ps"},"PT":{"SAPCode":"PT","ISOCode":"PT","TechnicalName":"pt US"},"QT":{"SAPCode":"QT","ISOCode":"QT","TechnicalName":"qt US"},"RHO":{"SAPCode":"RHO","ISOCode":"23","TechnicalName":"g/cm3"},"ROL":{"SAPCode":"ROL","ISOCode":"RO","TechnicalName":"ROL"},"S":{"SAPCode":"S","ISOCode":"SEC","TechnicalName":"s"},"PC":{"SAPCode":"ST","ISOCode":"PCE","TechnicalName":"PC"},"HR":{"SAPCode":"STD","ISOCode":"HUR","TechnicalName":"hrs"},"DAY":{"SAPCode":"TAG","ISOCode":"DAY","TechnicalName":"Days"},"TC3":{"SAPCode":"TC3","ISOCode":"","TechnicalName":"1/cm3"},"TCM":{"SAPCode":"TCM","ISOCode":"","TechnicalName":"ppcm3"},"TES":{"SAPCode":"TES","ISOCode":"D33","TechnicalName":"D"},"TEU":{"SAPCode":"TEU","ISOCode":"E22","TechnicalName":"TEU"},"TS":{"SAPCode":"TH","ISOCode":"MIL","TechnicalName":"thou"},"tha":{"SAPCode":"THA","ISOCode":"","TechnicalName":"t/ha"},"TYR":{"SAPCode":"TJH","ISOCode":"","TechnicalName":"t/yr"},"TKT":{"SAPCode":"TKT","ISOCode":"","TechnicalName":"t/kt"},"TM3":{"SAPCode":"TM3","ISOCode":"","TechnicalName":"1/m3"},"TO":{"SAPCode":"TO","ISOCode":"TNE","TechnicalName":"t"},"TON":{"SAPCode":"TON","ISOCode":"STN","TechnicalName":"ton"},"001":{"SAPCode":"TST","ISOCode":"","TechnicalName":"000001"},"TMO":{"SAPCode":"Tmt","ISOCode":"","TechnicalName":"t/mth"},"TPH":{"SAPCode":"ToS","ISOCode":"","TechnicalName":"t/h"},"Tot":{"SAPCode":"Tot","ISOCode":"","TechnicalName":"t/ton"},"µGL":{"SAPCode":"UGL","ISOCode":"","TechnicalName":"µg/l"},"V":{"SAPCode":"V","ISOCode":"VLT","TechnicalName":"V"},"V%":{"SAPCode":"V%","ISOCode":"","TechnicalName":"%(V)"},"V%O":{"SAPCode":"V%O","ISOCode":"","TechnicalName":"%O(V)"},"MSC":{"SAPCode":"V01","ISOCode":"","TechnicalName":"µS/cm"},"MPL":{"SAPCode":"V02","ISOCode":"C36","TechnicalName":"mMol/l"},"VAL":{"SAPCode":"VAL","ISOCode":"","TechnicalName":"val"},"VPB":{"SAPCode":"VPB","ISOCode":"","TechnicalName":"ppb(V)"},"VPM":{"SAPCode":"VPM","ISOCode":"","TechnicalName":"ppm(V)"},"VPT":{"SAPCode":"VPT","ISOCode":"","TechnicalName":"ppt(V)"},"W":{"SAPCode":"W","ISOCode":"WTT","TechnicalName":"W"},"WK":{"SAPCode":"WCH","ISOCode":"WEE","TechnicalName":"Weeks"},"WMK":{"SAPCode":"WMK","ISOCode":"D53","TechnicalName":"W/mk"},"WKY":{"SAPCode":"WTL","ISOCode":"","TechnicalName":"kg/sm2"},"YD":{"SAPCode":"YD","ISOCode":"YRD","TechnicalName":"yd"},"YD2":{"SAPCode":"YD2","ISOCode":"YDK","TechnicalName":"yd2"},"YD3":{"SAPCode":"YD3","ISOCode":"YDQ","TechnicalName":"yd3"},"BYr":{"SAPCode":"bJH","ISOCode":"","TechnicalName":"BTU/Yr"},"Bmo":{"SAPCode":"bMO","ISOCode":"","TechnicalName":"BTU/M"},"bbl":{"SAPCode":"bbl","ISOCode":"","TechnicalName":"Bt/bbl"},"bft":{"SAPCode":"bft","ISOCode":"B0","TechnicalName":"Bt/ft3"},"bgl":{"SAPCode":"bgl","ISOCode":"","TechnicalName":"Bt/gal"},"BSC":{"SAPCode":"bsc","ISOCode":"","TechnicalName":"BTU/SC"},"btl":{"SAPCode":"btl","ISOCode":"","TechnicalName":"Btu/lb"},"fcm":{"SAPCode":"fcm","ISOCode":"","TechnicalName":"fb/cm3"},"fm3":{"SAPCode":"fm3","ISOCode":"","TechnicalName":"fb/m3"},"fml":{"SAPCode":"fml","ISOCode":"","TechnicalName":"fb/ml"},"gGJ":{"SAPCode":"gGJ","ISOCode":"","TechnicalName":"g/GJ"},"gj3":{"SAPCode":"gj3","ISOCode":"","TechnicalName":"GJ/tm3"},"gjm":{"SAPCode":"gjm","ISOCode":"","TechnicalName":"GJ/m3"},"gjt":{"SAPCode":"gjt","ISOCode":"","TechnicalName":"GJ/ton"},"jm3":{"SAPCode":"jm3","ISOCode":"","TechnicalName":"J/m3"},"kgb":{"SAPCode":"kgb","ISOCode":"","TechnicalName":"kg/bbl"},"kgg":{"SAPCode":"kgg","ISOCode":"","TechnicalName":"kg/gal"},"kgj":{"SAPCode":"kgj","ISOCode":"","TechnicalName":"kg/J"},"kgm":{"SAPCode":"kgm","ISOCode":"","TechnicalName":"kg/MB"},"kgs":{"SAPCode":"kgs","ISOCode":"","TechnicalName":"kg/scf"},"kgt":{"SAPCode":"kgt","ISOCode":"","TechnicalName":"kg/ton"},"kml":{"SAPCode":"kml","ISOCode":"","TechnicalName":"kg/kgm"},"kwk":{"SAPCode":"kwk","ISOCode":"","TechnicalName":"kWh/kg"},"lbb":{"SAPCode":"lbb","ISOCode":"","TechnicalName":"lb/Btu"},"lbg":{"SAPCode":"lbg","ISOCode":"GE","TechnicalName":"lb/gal"},"lbl":{"SAPCode":"lbl","ISOCode":"","TechnicalName":"lb/lbm"},"lbm":{"SAPCode":"lbm","ISOCode":"","TechnicalName":"lb/MB"},"lbs":{"SAPCode":"lbs","ISOCode":"","TechnicalName":"lb/scf"},"lbt":{"SAPCode":"lbt","ISOCode":"","TechnicalName":"lb/ton"},"lcm":{"SAPCode":"lcm","ISOCode":"","TechnicalName":"l/cm3"},"lhh":{"SAPCode":"lhh","ISOCode":"","TechnicalName":"lb/Hph"},"lht":{"SAPCode":"lht","ISOCode":"","TechnicalName":"lb/HTH"},"lmf":{"SAPCode":"lmf","ISOCode":"","TechnicalName":"lb/Mf3"},"lmg":{"SAPCode":"lmg","ISOCode":"","TechnicalName":"lb/Mgl"},"ltb":{"SAPCode":"ltb","ISOCode":"","TechnicalName":"lb/Tbl"},"ltf":{"SAPCode":"ltf","ISOCode":"","TechnicalName":"lb/Tf3"},"ltg":{"SAPCode":"ltg","ISOCode":"","TechnicalName":"lb/Tgl"},"lth":{"SAPCode":"lth","ISOCode":"","TechnicalName":"lb/TH"},"mGJ":{"SAPCode":"mGJ","ISOCode":"","TechnicalName":"mg/GJ"},"mHg":{"SAPCode":"mHg","ISOCode":"","TechnicalName":"mmHg"},"mbb":{"SAPCode":"mbb","ISOCode":"","TechnicalName":"MB/bbl"},"mbg":{"SAPCode":"mbg","ISOCode":"","TechnicalName":"MB/gal"},"mbk":{"SAPCode":"mbk","ISOCode":"","TechnicalName":"MB/kg"},"mbl":{"SAPCode":"mbl","ISOCode":"","TechnicalName":"MB/lb"},"mbm":{"SAPCode":"mbm","ISOCode":"","TechnicalName":"MB/Msc"},"mbs":{"SAPCode":"mbs","ISOCode":"","TechnicalName":"MB/scf"},"mbt":{"SAPCode":"mbt","ISOCode":"","TechnicalName":"MB/ton"},"mjm":{"SAPCode":"mjm","ISOCode":"","TechnicalName":"MJ/m3"},"uGJ":{"SAPCode":"mkG","ISOCode":"","TechnicalName":"mcg/GJ"},"mmB":{"SAPCode":"mmB","ISOCode":"","TechnicalName":"mmBtu"},"nGJ":{"SAPCode":"nGJ","ISOCode":"","TechnicalName":"ng/GJ"},"nGQ":{"SAPCode":"nQ","ISOCode":"","TechnicalName":"ng/m3"},"pGQ":{"SAPCode":"pQ","ISOCode":"","TechnicalName":"pg/m3"},"sM3":{"SAPCode":"sM3","ISOCode":"","TechnicalName":"sp/m3"},"sMb":{"SAPCode":"sMb","ISOCode":"","TechnicalName":"scf/Mb"},"scf":{"SAPCode":"scf","ISOCode":"","TechnicalName":"SCF"},"sch":{"SAPCode":"sch","ISOCode":"","TechnicalName":"scf/h"},"scy":{"SAPCode":"scy","ISOCode":"","TechnicalName":"scf/y"},"TYr":{"SAPCode":"tJH","ISOCode":"","TechnicalName":"Ton/Yr"},"tMb":{"SAPCode":"tMb","ISOCode":"","TechnicalName":"t/MMbb"},"tMs":{"SAPCode":"tMs","ISOCode":"","TechnicalName":"t/Mscf"},"tbl":{"SAPCode":"tbl","ISOCode":"","TechnicalName":"t/bbl"},"tbt":{"SAPCode":"tbt","ISOCode":"","TechnicalName":"t/Btu"},"tgl":{"SAPCode":"tgl","ISOCode":"","TechnicalName":"ton/gl"},"Thm":{"SAPCode":"thm","ISOCode":"","TechnicalName":"Therm"},"tjl":{"SAPCode":"tjl","ISOCode":"","TechnicalName":"t/Joul"},"tm3":{"SAPCode":"tm3","ISOCode":"","TechnicalName":"t/tm3"},"T/M":{"SAPCode":"tmt","ISOCode":"","TechnicalName":"Ton/M"},"tph":{"SAPCode":"toS","ISOCode":"","TechnicalName":"Ton/H"},"tot":{"SAPCode":"tot","ISOCode":"","TechnicalName":"to/ton"},"tt":{"SAPCode":"tt","ISOCode":"","TechnicalName":"t/t"},"ttj":{"SAPCode":"ttj","ISOCode":"","TechnicalName":"t/TJ"},"COP":{"SAPCode":"COP","ISOCode":"","TechnicalName":"COP"},"PCS":{"SAPCode":"ZPC","ISOCode":"_01","TechnicalName":"PCS"},"PSI":{"SAPCode":"PSI","ISOCode":"","TechnicalName":"psi"},"卷":{"SAPCode":"ZJU","ISOCode":"_02","TechnicalName":"卷"},"***":{"SAPCode":"Z02","ISOCode":"","TechnicalName":""},"BOE":{"SAPCode":"BOE","ISOCode":"","TechnicalName":"BOE"}
    
};

//add Button to Shellbar
var oButton = document.getElementById("btn-submit");
oButton.style.display = "none";
var newButton = document.createElement("button");
newButton.className = "fd-button";
newButton.id = "btn-create";
newButton.innerText = "创建";

address = [];
document.getElementById("10005-YY1_ZDRZH_DLH").value = prog.user[0].f_full_name;
newButton.onclick = function (event) {
    //document.getElementById("screen-0").style.display = "none";
    //document.getElementById("screen-1").style.display = "block";
	var rc = obtainCheckbox();
	if(rc){
		//document.getElementById("screen-1").style.overflowY="visible";
		document.getElementById("btn-create").style.display = "none";
		document.getElementById("btn-back").style.display = "inline-block";
		document.getElementById("btn-submit").style.display = "inline-block";
	}
	
	var oCb = function(){
		if(this != "" ){
			address = JSON.parse(this);
			console.log(address)
			for(var l=0,nl=address.length;l<nl;l++){
				var oAddOptions = address[l].f_carename +"~"+ address[l].f_street +"~"+ address[l].f_mobile;
				var oSelect = document.getElementById("11007-AdressSelector");
				var opt = new Option(oAddOptions,address[l].f_addressid);
				oSelect.appendChild(opt);
				var oValue = oSelect.value;
				for(var i=0,ni=address.length;i<ni;i++){
					if(oValue == address[i].f_addressid){
						document.getElementById("11007-CareOfName").value = address[i].f_carename;
						document.getElementById("11007-StreetName").value = address[i].f_street;
						document.getElementById("11007-MobilePhoneNumber").value = address[i].f_mobile;
						document.getElementById("11007-Country").value = address[i].f_country;
						document.getElementById("11007-Region").value = address[i].f_region;
						document.getElementById("11007-CityName").value = address[i].f_city;
						document.getElementById("11007-PhoneNumber").value = address[i].f_phone;
					}
				}
				oSelect.onchange = function (event) {
					updAdrFields(oValue);
				}
				if(address.length==1){
					var opts = oSelect.getElementsByTagName("option");
					opts[1].selected = true;
					updAdrFields(address[0].f_addressid);
				}else{					
				}				
			}
		}
    }
    //read LongText for SalesOrders
	var oSoldToParty = document.getElementById("10005-SoldToParty").innerHTML;
    var getReqBody = {"from_table":"t_oms_bpadr", "where":{"f_bp":[oSoldToParty]}};
    anyAsyncJSON("POST", '/ordsys/admin/dbdata/t_oms_bpadr', JSON.stringify(getReqBody), oCb);
};
//upd Address field
function updAdrFields(id) {
	for(var i=0,ni=address.length;i<ni;i++){
		if(id == address[i].f_addressid){
			document.getElementById("11007-CareOfName").value = address[i].f_carename;
			document.getElementById("11007-StreetName").value = address[i].f_street;
			document.getElementById("11007-MobilePhoneNumber").value = address[i].f_mobile;
			document.getElementById("11007-Country").value = address[i].f_country;
			document.getElementById("11007-Region").value = address[i].f_region;
			document.getElementById("11007-CityName").value = address[i].f_city;
			document.getElementById("11007-PhoneNumber").value = address[i].f_phone;
		}
	}
}				

oButton.parentNode.insertBefore(newButton,oButton);

var backButton = document.createElement("button");
backButton.className = "fd-button";
backButton.style.display = "none";
backButton.id = "btn-back";
backButton.innerText = "返回";
backButton.onclick = function (event) {
    document.getElementById("10006-tbody").innerHTML = "";
    document.getElementById("screen-0").style.display = "block";
    document.getElementById("screen-1").style.display = "none";
    document.getElementById("btn-create").style.display = "inline-block";
    document.getElementById("btn-back").style.display = "none";
    document.getElementById("btn-submit").style.display = "none";
};
oButton.parentNode.insertBefore(backButton,oButton);

oButton.addEventListener('click', function (event) {
    var headData = {};
    
    //get header data
    var oForm = document.getElementById("section-10007").querySelectorAll('input,select');
    //console.log(oForm);
    for(var i=0,n=oForm.length;i<n;i++){
        //console.log((oForm[i].value == "") && (oForm[i].required == true));
        if((oForm[i].value == "") && (oForm[i].required == true)){
            oForm[i].focus();
            return false;
        }
        if(oForm[i].value && (oForm[i].disabled != true)){
            if(oForm[i].type == "date" && oForm[i].value){
                headData[oForm[i].id.split("-")[1]] = '\/Date(' + Date.parse(oForm[i].value) + ')\/';
            }else if(oForm[i].id.split("-")[1].indexOf("YY1_") == 0){
                headData[oForm[i].id.split("-")[1]] = oForm[i].value;
            }
        }
    }
    headData["YY1_SJFHRQ_DLH"] = '\/Date(' + Date.parse(document.getElementById("10005-YY1_SJFHRQ_DLH").value) + ')\/';
    
	
    var addressData = {};
	
    //get address data
    var oAddForm = document.getElementById("section-11007").querySelectorAll('input');
    console.log(oAddForm);
    for(var i=0,n=oAddForm.length;i<n;i++){
        if((oAddForm[i].value == "") && (oAddForm[i].required == true)){
            oAddForm[i].focus();
            return false;
        }
        addressData[oAddForm[i].id.split("-")[1]] = oAddForm[i].value;
    }

	
    //get table data
    var oTabItems = document.getElementById("10006-tbody");
    //console.log(oTabItems.rows);
    
    var predata = [];
    var patch_item_data = [];
    for(var i=0,n=oTabItems.rows.length;i<n;i++){
        var rowData = {};
        //rowData.Item = {};
        //console.log(oTabItems.rows[i].cells[0].childNodes[0].checked);
        //if(oTabItems.rows[i].cells[0].childNodes[0].checked){   //commented by tingkai on 2020.04.06
            for(var j=0,nj=oTabItems.rows[i].cells.length;j<nj;j++){
                var key = oTabItems.rows[i].cells[j].id.split("-")[1];
                var SN = Number(oTabItems.rows[i].cells[j].id.split("-")[2]);
                //console.log(key);
                if(oTabItems.rows[i].cells[j].childNodes.length > 0){
                    if(oTabItems.rows[i].cells[j].childNodes[0].tagName == "INPUT" && key == "DeliveredQtyInOrderQtyUnit"){
                        var val = oTabItems.rows[i].cells[j].childNodes[0].value;
                        rowData.Quantities = {
                            'DeliveryQuantity':{
                                '_unitCode':UoM[openOrder[SN].OrderQuantityUnit].ISOCode,
                                '__text':val
                            }
                        };
                        //rowData.Item.Quantities.DeliveryQuantity = val;
                    }else if(key == "SalesDocument"){
                        var val = oTabItems.rows[i].cells[j].childNodes[0].innerText;
                        
                        rowData.SalesOrderReference = {
                            'ID':{
                                '_schemeAgencyID':"?",
                                '__text':val
                            }
                        };
                    }else if(key == "SalesDocumentItem"){
                        var val = oTabItems.rows[i].cells[j].childNodes[0].innerText;
                        rowData.SalesOrderReference.ItemID = val;
                    }
                }
            }
            predata.push(rowData);
        //}   //commented by tingkai on 2020.04.06
            //item data for patching to ODATA
            var oItem = (i + 1) + "0";
            var rowId = oTabItems.rows[i].id.split("-");
            var oDlvRawDate = document.getElementById("10006-YY1_SJCNRQ_DLI-"+rowId[1]+"-input").value;
            if(oDlvRawDate){
				var oDlvDate =  '\/Date(' + Date.parse(oDlvRawDate) + ')\/';
			}else{
				var oDlvDate =  "";
			}
            var oSloc = document.getElementById("10006-StorageLocation-"+rowId[1]+"-select").value;
            var oSFYQ = document.getElementById("10006-YY1_SFYQH_DLI-"+rowId[1]+"-select").value;
            var oYQYY = document.getElementById("10006-YY1_YQYYH_DLI-"+rowId[1]+"-input").value;
            var iRow = {"item":oItem,"sloc":oSloc,"dlvDate":oDlvDate,"sfyq": oSFYQ, "yqyy":oYQYY};
            patch_item_data.push(iRow);
    }
    
    var xmlObj = {
        'soapenv:Envelope':{
            '_xmlns:soapenv':"http://schemas.xmlsoap.org/soap/envelope/",
            '_xmlns:glob':"http://sap.com/xi/APPL/SE/Global",
            'soapenv:Header':"",
            'soapenv:Body':{
                'glob:OutboundDeliveryERPWithReferenceToSalesOrderCreateRequest_sync':{
                    'OutboundDelivery':{'Item':predata}
                }
            }
        }
    }
    //console.log(predata);
	console.log(JSON.stringify(predata));
    var x2js = new X2JS({
        useDoubleQuotes : true
    });
    //var xmlText = event;
    var predataXML = x2js.json2xml_str(xmlObj);
    predataXML = '<?xml version="1.0" encoding="UTF-8"?>' + predataXML;
    //alert(predataXML);
            
    //document.getElementById("btn-submit").disabled = true;
    
    //data submit to Server --
    var cb = function(){
        var ret = this;
        console.log(ret);
        if(this != "timeout"){
            // Create x2js instance with default config
            var x2js = new X2JS();
            //var xmlText = event;
            var jsonObj = x2js.xml_str2json(ret);
            
            //document.getElementById('textarea-output').value = JSON.stringify(jsonObj);
            var respBody = jsonObj["Envelope"]["Body"]["OutboundDeliveryERPWithReferenceToSalesOrderCreateConfirmation_sync"];
            //var newDN = respBody.OutboundDelivery.ID;
            console.log(respBody);
            //if(typeof respBody.OutboundDelivery.ID != "undefined"){
            if(respBody.hasOwnProperty("OutboundDelivery")){
                alert("交货单" + respBody.OutboundDelivery.ID + " 已创建。");
                //location.reload();
                
                var cb2 = function(){
                }
                var url = "/ordsys/admin/callodatajsonpatch/API_OUTBOUND_DELIVERY_SRV;v=0002/A_OutbDeliveryHeader('" + respBody.OutboundDelivery.ID + "')";
                if(headData.hasOwnProperty("YY1_SJFHRQ_DLH")){
					postSyncJSON(url, JSON.stringify(headData), cb2);
                }else{
					cb2();
				}
				
				//Update delivery order address
				var cb2_address = function(){
					console.log(this);
				}
                var url = "/ordsys/admin/callodatajsonpatch/API_OUTBOUND_DELIVERY_SRV;v=0002/A_OutbDeliveryAddress2(DeliveryDocument='"+ respBody.OutboundDelivery.ID +"',PartnerFunction='SH')";
				postSyncJSON(url, JSON.stringify(addressData), cb2_address);

				//save LongText to DB
				var to_DB_JSON = {"keys":["f_dn"],"data":{"f_dn":respBody.OutboundDelivery.ID, "f_tx01":document.getElementById("10007-YY1_BZ1_DLH").value, "f_ybhd":""}};
				var cb3 = function(){
				}
				anySyncJSON("PUT", '/ordsys/admin/save2db/t_oms_dn/f_dn', JSON.stringify(to_DB_JSON), cb3);
				
				if(patch_item_data.length > 0){
					var cb5 = function(){
						console.log(this);
						var ret = "";
						
						try {
							ret = JSON.parse(this);
						} catch (d) {
							
						}
						if(ret != ""){
							
							if(ret.hasOwnProperty("error")){
								var cnf = false;
								if(ret.error.message.value.indexOf("credit") >= 0){
									cnf = confirm("客户信贷冻结，不能更新行项目自定义字段");
								}else{
									cnf = confirm("更新行项目自定义字段失败，SAP接口返回错误消息：" + ret.error.message.value);
								}
								if(cnf){
									location.reload();
									//location.reload(true);
								}else{
									patch_item_data = [];
									document.getElementById("btn-submit").disabled = false;
								}
								//location.reload();
								//document.getElementById("btn-submit").disabled = false;
							}else{
								var cnf = confirm("All data saved! Reload page?");
								if(cnf){
									location.reload();
									//location.reload(true);
								}else{
									patch_item_data = [];
									document.getElementById("btn-submit").disabled = false;
								}
							}
						}else{
							var cnf = confirm("All data saved! Reload page?");
								if(cnf){
									location.reload();
									//location.reload(true);
								}else{
									patch_item_data = [];
									document.getElementById("btn-submit").disabled = false;
								}
						}
					}
					var cb4 = function(){
						console.log(this);
					}
					for(var i=0,n=patch_item_data.length;i<n;i++){
						var patchData = {};
						if(patch_item_data[i].sloc != ""){
							patchData["StorageLocation"] = patch_item_data[i].sloc;
						}
						if(patch_item_data[i].dlvDate != ""){
							patchData["YY1_SJCNRQ_DLI"] = patch_item_data[i].dlvDate;
						}
						if(patch_item_data[i].sfyq != ""){
							patchData["YY1_SFYQH_DLI"] = patch_item_data[i].sfyq;
						}
						if(patch_item_data[i].yqyy != ""){
							patchData["YY1_YQYYH_DLI"] = patch_item_data[i].yqyy;
						}
						/*if(patch_item_data[i].dlvDate != ""){
							var patchData = {"StorageLocation":patch_item_data[i].sloc,"YY1_SJCNRQ_DLI":patch_item_data[i].dlvDate, "YY1_SFYQH_DLI":patch_item_data[i].sfyq, "YY1_YQYYH_DLI":patch_item_data[i].yqyy};
						}else{
							var patchData = {"StorageLocation":patch_item_data[i].sloc, "YY1_SFYQH_DLI":patch_item_data[i].sfyq, "YY1_YQYYH_DLI":patch_item_data[i].yqyy};
						}*/
						//A_OutbDeliveryItem(DeliveryDocument='" + respBody.OutboundDelivery.ID + "',DeliveryDocumentItem='" + patch_item_data[i].item + "')"
						var url = "/ordsys/admin/callodatajsonpatch/API_OUTBOUND_DELIVERY_SRV;v=0002/A_OutbDeliveryItem(DeliveryDocument='" + respBody.OutboundDelivery.ID + "',DeliveryDocumentItem='" + patch_item_data[i].item + "')";
						if(i==n-1){
							postAsyncJSON(url, JSON.stringify(patchData), cb5);
						}else{
							postSyncJSON(url, JSON.stringify(patchData), cb4);
						}
					}
				}else{
					var cnf = confirm("Text saved to DB! Reload page?");
					if(cnf){
						location.reload();
						//location.reload(true);
					}else{
						
						document.getElementById("btn-submit").disabled = false;
					}
				}

                //document.getElementById("10006-tbody").innerHTML = "";
                //document.getElementById("screen-0").style.display = "block";
                //document.getElementById("screen-1").style.display = "none";
            }else if(typeof(respBody.Log.Item[0].Note) != "undefined"){
                var cnf = confirm(respBody.Log.Item[0].Note);
                if(cnf){
                    location.reload();
                    //location.reload(true);
                }else{
                    document.getElementById("btn-submit").disabled = false;
                }
            }else{
                var cnf = confirm("SOAP接口未知错误，需管理员去SAP后台查询具体原因！");
                if(cnf){
                    location.reload();
                    //location.reload(true);
                }else{
                    document.getElementById("btn-submit").disabled = false;
                }
            }
            
        }else{
            alert("SAP接口超时错误，请稍后重试");
            document.getElementById("btn-submit").disabled = false;
            
        }
    }
    document.getElementById("btn-submit").disabled = true;
    postAsyncXML('/ordsys/admin/callsoap/ecc_outbounddeliverycwrrc', predataXML, cb);
    
}, false);

//Document Type convertion
var docTypeConv = {
	"CBRE":"LR",
	"OR":"LF",
	"CBFD":"LF",
	"NB":"NLCC",
	};

//obtain checkbox list
function obtainCheckbox(){
	var oSourceTbody = document.getElementById("10003-tbody");
	
	//create temporary josnArr
	var jsonTMP = {};
	for(var i=0,n=oSourceTbody.rows.length;i<n;i++){
		//console.log(oSourceTbody.rows[i].cells[0].childNodes[0],127);
		
		if (oSourceTbody.rows[i].cells[0].childNodes[0].checked === true) {
				var arrTr = oSourceTbody.rows[i].cells[1].id.split("-");
					
                // Added by tingkai on 2020/04/09 start ====================================================
                if(JSON.stringify(jsonTMP) === "{}"){
                    jsonTMP = openOrder[Number(arrTr[2])];
                }else{
                    if(jsonTMP.SoldToParty != openOrder[Number(arrTr[2])].SoldToParty){
                         alert("订单客户不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.YY1_ZKUNNR_SDH != openOrder[Number(arrTr[2])].YY1_ZKUNNR_SDH){
                        alert("终端客户不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.Plant != openOrder[Number(arrTr[2])].Plant){
                        alert("工厂不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.IncotermsClassification != openOrder[Number(arrTr[2])].IncotermsClassification){
                        alert("贸易条款不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.SalesGroup != openOrder[Number(arrTr[2])].SalesGroup){
                        alert("销售组不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.SalesOrganization != openOrder[Number(arrTr[2])].SalesOrganization){
                        alert("销售组织不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.SalesDocumentType != openOrder[Number(arrTr[2])].SalesDocumentType){
                        alert("订单类型不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }else if(jsonTMP.DistributionChannel != openOrder[Number(arrTr[2])].DistributionChannel){
                        alert("分销渠道不同，不能合并创建");
                         document.getElementById("10006-tbody").innerHTML = "";
                         return false;
                    }
                }
                // Added by tingkai on 2020/04/09 End ====================================================
                
				var oTr = document.createElement("tr");
                oTr.id = "10006-" + i + "-tr";
				//add Button to delete
				var oTd = document.createElement("td");
				oTr.appendChild(oTd);
				oTd.className = "fd-table__cell";
				oTd.style.width="2rem";
				var oDelBut = document.createElement("button");
				oDelBut.className = "fd-button";
				oDelBut.style.cssText += ";padding:0 5px;height:auto;min-width:auto;line-height:inherit;";
				oDelBut.id = "btn-delete";
				oDelBut.innerText = "x";
				oDelBut.onclick = function (event) { 
					this.parentNode.parentNode.innerHTML = "";
					event.target.remove(this.parentNode.parentNode);
				};
				oTd.appendChild(oDelBut);
				
				document.getElementById("10005-DeliveryDocumentType").innerText = docTypeConv[openOrder[Number(arrTr[2])].SalesDocumentType];

				for(var k=0,nk=prog.t_section_field.length;k<nk;k++){
					 //for(var j=0;j<oSourceTbody.rows[i].cells.length;j++) {    //commented by tingkai on 2020.04.06
						var arrTd = oSourceTbody.rows[i].cells[1].id.split("-"); //changed by tingkai on 2020.04.06
						//console.log(prog.t_section_field[k]);
						if(prog.t_section_field[k].f_section_id == "10006"){
							//if(prog.t_section_field[k].f_component == arrTd[1]){ //commented by tingkai on 2020.04.06
                                var oTd = document.createElement("td");
                                oTd.className = "fd-table__cell";
                                oTd.id = "10006-" + prog.t_section_field[k].f_component + "-" + i + "-td";
								                                
								if(prog.t_section_field[k].f_element == "input"){
									var oInput = document.createElement("input");
									oInput.className = "fd-input";
									oInput.type = prog.t_section_field[k].f_input_type;
									oInput.id = "10006-" + prog.t_section_field[k].f_component + "-" + i + "-input";
									
									if(prog.t_section_field[k].f_component == "DeliveredQtyInOrderQtyUnit"){
										var oId = [arrTr[0],"DeliveredQtyInOrderQtyUnit",arrTr[2],"input"];
										//console.log(document.getElementById(oId.join("-")).value);
										//console.log(oId.join("-"));
										oInput.value = document.getElementById(oId.join("-")).value;
									}else{ //changed by tingkai on 2020.04.06
										oInput.value = openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component]?openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component]:"";  //changed by tingkai on 2020.04.06
									}
									oTd.appendChild(oInput);
								}else if(prog.t_section_field[k].f_element == "select"){
									var oSelect = document.createElement("select");
									oSelect.className = "fd-form-select";
									oSelect.id = "10006-" + prog.t_section_field[k].f_component + "-" + i + "-select";
									if(prog.t_section_field[k].f_component == "StorageLocation"){
                                        var opt = new Option("","");
                                        oSelect.appendChild(opt);
                                        for(var l=0,nl=plantStorage.length;l<nl;l++){
                                            if(plantStorage[l].Plant == openOrder[Number(arrTr[2])].Plant){
                                                var opt = new Option(plantStorage[l].StorageLocation + "~" + plantStorage[l].StorageLocationName,plantStorage[l].StorageLocation);
                                                //oDL.options.add(opt,undefined);
                                                oSelect.appendChild(opt);
                                            }
                                        }
                                    }else{
                                        for(var l=0,nl=prog.t_section_field[k].f_option.length;l<nl;l++){
                                            //console.log(prog.t_section_field[k].f_option[l]);
                                            var opt = new Option(prog.t_section_field[k].f_option[l].code + "-" + prog.t_section_field[k].f_option[l].desc,prog.t_section_field[k].f_option[l].code);
                                            if(prog.t_section_field[k].f_value == prog.t_section_field[k].f_option[l].code){
                                                opt.selected = true;
                                            }
                                            oSelect.options.add(opt);
                                        }
                                        //行项目，是否延期选择Y，则延期原因必填
                                        if(prog.t_section_field[k].f_component == "YY1_SFYQH_DLI"){
                                            oSelect.onchange = function (event) {
                                                if(event.target.value == "Y"){
                                                    var splitId = event.target.id.split("-");
                                                    var oId = [splitId[0],"YY1_YQYYH_DLI",splitId[2],"input"];
                                                    var oYQYY = document.getElementById(oId.join("-"));
                                                    oYQYY.onblur = function (e) {
                                                        if(e.target.value == ""){
                                                            e.target.focus();
                                                        }
                                                    };
                                                    oYQYY.focus();
                                                }else{
                                                    var splitId = event.target.id.split("-");
                                                    var oId = [splitId[0],"YY1_YQYYH_DLI",splitId[2],"input"];
                                                    var oYQYY = document.getElementById(oId.join("-"));
                                                    oYQYY.onblur = "";
                                                    oYQYY.value = "";
                                                }
                                            };
                                        }
                                    }
									oTd.appendChild(oSelect);
                                    oSelect.value = openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component];
								}else if(prog.t_section_field[k].f_element == "span"){
									var oSpan = document.createElement("span");
									//oSpan.className = "";
									oSpan.id = "10006-" + prog.t_section_field[k].f_component + "-" + i + "-span";
									if(openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component]){
										oSpan.innerText = openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component];
									}
									oTd.appendChild(oSpan);
									
								}
								oTr.appendChild(oTd);
							//} //commented by tingkai on 2020.04.06
						}else if(prog.t_section_field[k].f_section_id == "10005" && document.getElementById("10005-"+prog.t_section_field[k].f_component) && openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component]){
							 document.getElementById("10005-"+prog.t_section_field[k].f_component).innerText = openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component];
						}else if(prog.t_section_field[k].f_section_id == "10007" && document.getElementById("10007-"+prog.t_section_field[k].f_component) && openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component]){
							 document.getElementById("10007-"+prog.t_section_field[k].f_component).value = openOrder[Number(arrTr[2])][prog.t_section_field[k].f_component];
						}
					//}    //commented by tingkai on 2020.04.06
					document.getElementById("10006-tbody").appendChild(oTr);
					/*
					for(var j=0,nj=prog.t_section_field.length;j<nj;j++){
						if(prog.t_section_field[j].f_section_id == "10006"){
							
						}
					}
					*/
				}
			 }else{
				
			 }
			 //var node = oSourceTbody.rows[i].cells[0];
			 //for (var k=0;k<node.childNodes.length;k += 2) {
		 //}
	}
	document.getElementById("screen-0").style.display = "none";
    document.getElementById("screen-1").style.display = "block";
    return true;
}       


//update table list
function updTable(sectionId,tbodyId,data){
    var tbody = document.getElementById(tbodyId);
    tbody.innerHTML = "";
    for(var i=0,n=data.length;i<n;i++){
        var oTr = document.createElement("tr");
        oTr.id = sectionId + "-" + i + "-tr";
        oTr.className = "fd-table__row";
        
        //add row checkbox
        var oTdCheckbox = document.createElement("td");
        oTdCheckbox.className = "fd-table__cell";
        oTdCheckbox.style.width="2rem";
        var oCheckbox = document.createElement("input");
        oCheckbox.className = "fd-checkbox";
        oCheckbox.type = "checkbox";
        oCheckbox.id = sectionId + "-checkbox-" + i + "-input";
        /*
        oInput.addEventListener('click', function (event) {
            if(event.target.checked == true){
                alert(event.target.value);
            }else{
                alert(event.target.value);
            }
        }, false);
        */
        oTdCheckbox.appendChild(oCheckbox);
        oTr.appendChild(oTdCheckbox);
        
        //add other fields
        for(var j=0,nj=prog.t_section_field.length;j<nj;j++){
            if(prog.t_section_field[j].f_section_id == sectionId && prog.t_section_field[j].f_hidden != "hidden"){
                var oTd = document.createElement("td");
                oTd.className = "fd-table__cell";
                oTd.id = sectionId + "-" + prog.t_section_field[j].f_component + "-" + i + "-td";
                if(prog.t_section_field[j].f_element == "input"){
                    
                    var oInput = document.createElement("input");
                    oInput.className = "fd-input";
                    oInput.type = prog.t_section_field[j].f_input_type;
                    oInput.id = sectionId + "-" + prog.t_section_field[j].f_component + "-" + i + "-input";
                    if(prog.t_section_field[j].f_component != "DeliveredQtyInOrderQtyUnit"){
                        oInput.value = data[i][prog.t_section_field[j].f_component]?data[i][prog.t_section_field[j].f_component]:"";
                    }
                    
                    oTd.appendChild(oInput);
                    /*
                    oTd.contentEditable = "true";
                    oTd.innerText = data[i][prog.t_section_field[j].f_component];
                    */
                }else if(prog.t_section_field[j].f_element == "span"){
                    var oSpan = document.createElement("span");
                    oSpan.id = sectionId + "-" + prog.t_section_field[j].f_component + "-" + i + "-span";
                    
                    if(typeof(data[i][prog.t_section_field[j].f_component]) == "string"){
                        var idxDate = data[i][prog.t_section_field[j].f_component].indexOf("/Date(");
                    }
                    if(idxDate >= 0){
                        var newDate = new Date();
                        //console.log(data[i][prog.t_section_field[j].f_component].substring(7,19));
                        newDate.setTime(data[i][prog.t_section_field[j].f_component].substring(6,19));
                        oSpan.innerText = newDate.toLocaleDateString(); //changed by tingkai on 2020.04.06
                    //}else if(data[i][prog.t_section_field[j].f_component]){   //changed by tingkai on 2020.04.06
                    }else{                                                      //changed by tingkai on 2020.04.06
                        //var oSpan = document.createElement("span");           //commented by tingkai on 2020.04.06
                        //oSpan.className = "fd-input";
                        //oSpan.id = sectionId + "-" + prog.t_section_field[j].f_component + "-" + i + "-span"; //commented by tingkai on 2020.04.06
                        oSpan.innerText = data[i][prog.t_section_field[j].f_component]?data[i][prog.t_section_field[j].f_component]:"";
                    }
                    oTd.appendChild(oSpan);
                }
                oTr.appendChild(oTd);
            }
        }
        tbody.appendChild(oTr);
    }
    /*
    for(var i=0,n=data.length;i<n;i++){
        var opt = new Option(data[i][val],data[i][key]+"-"+data[i][cokey]);
        //oDL.options.add(opt,undefined);
        oDL.appendChild(opt);
    }
    el.parentNode.appendChild(oDL);
    
    el.setAttribute('list',datalistId);
/Date(1574812800000)
    */
}

//loading Region and Country
countryRegion = {};
var cb = function(){
    var ret = this;
    var _region = JSON.parse(ret).d.results;
    //console.log(_region);
    for(var i=0,n=_region.length;i<n;i++){
        var _country = _region[i].Country;
        if(!countryRegion.hasOwnProperty(_country)){
            countryRegion[_country] = {};
        }
        countryRegion[_country].CountryShortName = _region[i].CountryShortName;
        countryRegion[_country][_region[i].Region] = {};
        countryRegion[_country][_region[i].Region].RegionName = _region[i].RegionName;
    }
    console.log(countryRegion);
    
    if(document.getElementById("countrylist")){
        var oDL = document.getElementById("countrylist");
        if(_region.length > 0){
            oDL.innerHTML = "";
        }
    }else{
        //create new datalist
        var oDL = document.createElement("datalist");
        oDL.id = "countrylist";
    }
    for(var key in countryRegion){
        //console.log(countryRegion[key]);
        var opt = new Option(countryRegion[key].CountryShortName,key);
        //oDL.options.add(opt,undefined);
        oDL.appendChild(opt);
    }
    var el = document.getElementById("11007-Country");
    el.parentNode.appendChild(oDL);
    el.setAttribute('list',"countrylist");
}

var GETurl = "/ordsys/admin/masterdata/YY1_REGIONTEXT_CDS/YY1_RegionText/?$format=json&$filter=Language eq 'ZH' and LanguageCountry eq 'ZH'";
getAsync(GETurl, '', cb);

// YY1_I_STORAGELOCATION_CDS/YY1_I_StorageLocation/?$format=json&$filter=Language eq 'ZH'
//loading Plant and StorageLocation
plantStorage = [];
var cb = function(){
    var ret = this;
    plantStorage = JSON.parse(ret).d.results;
    //plantStorage = JSON.parse(ret);
    //console.log(plantStorage);
    //updTable(sectionId,tbodyId,data)
}

var GETurl = "/ordsys/admin/masterdata/YY1_I_STORAGELOCATION_CDS/YY1_I_StorageLocation/?$format=json&$filter=Language eq 'ZH'";
getAsync(GETurl, '', cb);

//load stock qty. data
matStock = [];
function updStock(tbodyId){
    var cbStock = function(){
        var ret = this;
        matStock = JSON.parse(ret).d.results;
        //plantStorage = JSON.parse(ret);
        //console.log(matStock);
        
        var tbody = document.getElementById(tbodyId);
        /*
        for(var i=0,n=tbody.rows.length;i<n;i++){
            //tbody.rows[i]
            var arrTr = tbody.rows[i].id.split("-");
            var oMatnr = document.getElementById(([arrTr[0],"Material", i, "span"]).join("-")).innerText;
            var oPlant = document.getElementById(([arrTr[0],"Plant", i, "span"]).join("-")).innerText;
            var oSloc = document.getElementById(([arrTr[0],"StorageLocation", i, "span"]).join("-")).innerText;
            var oBatch = document.getElementById(([arrTr[0],"Batch", i, "span"]).join("-")).innerText;
        }
        */
        for(var i=0,n=openOrder.length;i<n;i++){
            openOrder[i].Stock = 0;
            openOrder[i].eStock = 0;
            for(var l=0,nl=matStock.length;l<nl;l++){
                // matStock[l].MatlWrhsStkQtyInMatlBaseUnit
                if(openOrder[i].Material == matStock[l].Material                &&
                   openOrder[i].Plant == matStock[l].Plant                      &&
                   openOrder[i].StorageLocation == matStock[l].StorageLocation  &&
                   openOrder[i].Batch == matStock[l].Batch){
                    if(matStock[l].SDDocument != ""){
                        if(openOrder[i].SalesDocument == matStock[l].SDDocument && openOrder[i].SalesDocumentItem == matStock[l].SDDocumentItem){
                            openOrder[i].eStock += Number(matStock[l].MatlWrhsStkQtyInMatlBaseUnit);
                        }
                    }else{
                        openOrder[i].Stock += Number(matStock[l].MatlWrhsStkQtyInMatlBaseUnit);
                    }
                }
            }
        }
        console.log(openOrder);
        updTable('10003','10003-tbody',openOrder);
    }
    var urlStock = "/ordsys/admin/masterdata/YY1_I_MATERIALSTOCK_CDS/YY1_I_MaterialStock?$format=json&$filter=startswith(Material ,'0000001')";
    getAsync(urlStock, '', cbStock);
}
//
var org = ["131A", "137A", "621A"];
var orgDesc = ["深圳市广和通无线股份有限公司", "浙江诺控通信技术有限公司", "广和通实业（香港）有限公司"];
var channel = {"Z1":{"zh":"直销"},"F1":{"zh":"分销"}};
var divition = {"00":{"zh":"通用产品组"}};

var payTerm = {"":{"zh":""},"Z001":{"zh":"现金基础（款到发货）"},
"Z002":{"zh":"月结30天"},
"Z003":{"zh":"月结45天"},
"Z004":{"zh":"月结60天"},
"Z005":{"zh":"月结1天"},
"Z006":{"zh":"货到票到15天"},
"Z007":{"zh":"发货后5个工作日内付款"},
"Z008":{"zh":"货到票到7天付款"},
"Z009":{"zh":"货到票到15天付款"},
"Z010":{"zh":"货到15天付款"},
"Z011":{"zh":"送货收支票"},
"Z012":{"zh":"送货收30天期票"},
"Z013":{"zh":"货到票到45天付款"},
"Z014":{"zh":"货到票到30天付款"},
"Z015":{"zh":"货到60天付款"},
"Z016":{"zh":"货到票到30天电付"},
"Z017":{"zh":"货到60天付款"},
"Z018":{"zh":"货到75天"},
"Z019":{"zh":"货到票到60天付款"},
"Z020":{"zh":""},
"Z021":{"zh":"货到票到90天付款"},
"Z022":{"zh":"月结90天"},
"Z023":{"zh":"月结90天"},
"Z024":{"zh":"月结收3个月商业电子承兑汇票"},
"Z025":{"zh":"月结45天收2个月银行承兑"},
"Z026":{"zh":"net45"},
"Z027":{"zh":"月结90天"},
"Z028":{"zh":"货到票到30天付款"},
"Z029":{"zh":"月结30天"},
"Z030":{"zh":"月结30天"},
"Z031":{"zh":"月结60天"},
"Z032":{"zh":"月结30天"},
"Z033":{"zh":"月结60天"},
"Z034":{"zh":"货到票到60天付款"},
"Z035":{"zh":"月结30天，电汇或收6个月银行承兑汇票"},
"Z036":{"zh":"货到票到30天付款"},
"Z037":{"zh":""},
"Z038":{"zh":"货到票到90天付款"},
"Z039":{"zh":""},
"Z040":{"zh":"月结30天付6个月银行承兑汇票"},
"Z041":{"zh":"月结60天"},
"Z042":{"zh":""},
"Z043":{"zh":""},
"Z044":{"zh":"货到票到7天付款"},
"Z045":{"zh":"货到票到30天付款"},
"Z046":{"zh":""},
"Z047":{"zh":"月结30天"},
"Z048":{"zh":"月结90天"},
"Z049":{"zh":"月结60天付6个月银行承兑汇票"},
"Z050":{"zh":"月结60天"},
"Z051":{"zh":""},
"Z052":{"zh":"NET 30"},
"Z053":{"zh":"月结"},
"Z054":{"zh":"net 45"},
"Z055":{"zh":"月结60天收6个月银行承兑或商业承兑"},
"Z056":{"zh":"货到票到一周内收3个月银行承兑汇票"},
"Z057":{"zh":"货到7天付款"},
"Z058":{"zh":"货到票到15天"},
"Z059":{"zh":"货到票到30天付款"},
"Z060":{"zh":"货到票到25天收3个月银行承兑汇票"},
"Z061":{"zh":"送货或货到一周内收30天期票"},
"Z062":{"zh":"货到票到15天付款"},
"Z063":{"zh":"货到30天付款"},
"Z064":{"zh":"货到票到30天电付"},
"Z065":{"zh":"货到票到5天内收30天支票"},
"Z066":{"zh":"送货收30天期票"},
"Z067":{"zh":"货到票到付款"},
"Z068":{"zh":"OA30天"},
"Z069":{"zh":"货到30天付款"},
"Z070":{"zh":"OA45天"},
"Z071":{"zh":"送货收45天期票"},
"Z072":{"zh":"货到45天付款"},
"Z073":{"zh":"货到票到收60天期票"},
"Z074":{"zh":"票到后60天付款"},
"Z075":{"zh":"货到票到60天收3个月银行承兑汇票"},
"Z076":{"zh":"货到票到60天付款"},
"Z077":{"zh":"月结60天"},
"Z078":{"zh":"送货收不超过60天期票"},
"Z079":{"zh":"月结90天"},
"Z080":{"zh":"货到90天付款"},
"Z081":{"zh":"货到30天付款"},
"Z082":{"zh":"货到票到30天付款"},
"Z083":{"zh":"月结90天"},
"Z084":{"zh":"月结90天"},
"Z085":{"zh":"月结30天"},
"Z086":{"zh":"货到30天付款"},
"Z087":{"zh":"月结30天"},
"Z088":{"zh":"月结45天电付"},
"Z089":{"zh":"月结"},
"Z090":{"zh":"货到票到60天付款"},
"Z091":{"zh":"月结60天"},
"Z092":{"zh":"月结30天付6个月银行承兑汇票"},
"Z093":{"zh":"月结90天"},
"Z094":{"zh":"货到票到60天付款"},
"Z095":{"zh":"月结60天"},
"Z096":{"zh":"月结60天"},
"Z097":{"zh":"月结30天"},
"Z098":{"zh":"月结30天付6个月银行承兑汇票"}};
var incoTerm = {"":{"zh":""},
"Z01":{
        "zh": "DAP&Chengdu"
    },
"Z02":{
        "zh": "DAP&Hefei"
    },
"Z03":{
        "zh": "DAP&Kunshan"
    },
"Z04":{
    "zh": "DAP&Shanghai"
    },
"Z05":{
    "zh": "DAP&Taiwan"
    },
"Z06":{
    "zh": "DAP&Chongqing"
    },
"Z07":{
    "zh": "DAP&HongKong"
    },
"Z08":{
    "zh": "DDP&Brasil"
    },
"Z09":{
    "zh": "DDP&Kunshan"
    },
"Z10":{
    "zh": "DDU&HongKong"
    },
"Z11":{
    "zh": "FOB&Chengdu"
    },
"Z12":{
    "zh": "FOB&Kunshan"
    },
"Z13":{
    "zh": "FOB&Shanghai"
    },
"Z14":{
    "zh": "FOB&Shenzhen"
    },
"Z15":{
    "zh": "FOB&HongKong"
    },
"Z16":{
    "zh": "FOB&Chongqing"
    },
"Z17":{
    "zh": "DDP&America"
    },
"Z18":{
    "zh": "DDP&Philippines"
    },
"Z19":{
    "zh": "DDP&Taoyuan"
    },
"Z99":{
    "zh": "国内通用＆Domestic"
    },
"Z20":{
    "zh": "DAP&Xiamen"
    },
"Z21":{
    "zh": "DDP&Netherlands"
    },
"Z22":{
    "zh": "DDP&Singapore"
    },
"Z23":{
    "zh": "FCA&Shenzhen"
    },
"Z25":{
    "zh": "DAP&Brazil"
    },
"Z26":{
    "zh": "DAP&Liubliana"
    },
"Z27":{
    "zh": "FCA&HongKong"
    }
};

var shipPoint = {"":{"zh":""},"1310":{"zh":"广和通装运点"},
"1311":{"zh":"比亚迪装运点"},
"1312":{"zh":"恒昌盛装运点"},
"1313":{"zh":"华贝装运点"},
"1314":{"zh":"友一装运点"},
"1315":{"zh":"海格装运点"},
"1330":{"zh":"深圳软件装运点"},
"1370":{"zh":"诺控装运点"},
"13R0":{"zh":"广和通装运点无号段产品"},
"13R1":{"zh":"比亚迪装运点无号段产品"},
"13R2":{"zh":"恒昌盛装运点无号段产品"},
"13R3":{"zh":"华贝装运点无号段产品"},
"13R4":{"zh":"友一装运点无号段产品"},
"13R5":{"zh":"海格装运点无号段产品"},
"13R7":{"zh":"诺控装运点无号段产品"},
"6210":{"zh":"香港广和通装运点"},
"6211":{"zh":"装运点 621C"},
"6212":{"zh":"装运点 621R"},
"62R0":{"zh":"香港广和通装运点无号段产品"}};
var orderReason = {
	"":{
	"zh": ""
},
	"001":{
	"zh": "客户领样"
},
	"002":{
	"zh": "客户还样"
},
	"003":{
	"zh": "质量问题"
},
	"004":{
	"zh": "商务问题"
},
	"005":{
	"zh": "其他"
},
	"006":{
	"zh": "服务费用"
}
};

//loading open Sales Order
openOrder = [];
var cb = function(){
    var ret = this;
    var orderNumbers = [];
    var materials = [];
    //openOrder = JSON.parse(ret).d.results;
    openOrder = JSON.parse(ret);
    for(var i=0,n=openOrder.length;i<n;i++){
        orderNumbers.push(openOrder[i].SalesDocument);
        materials.push(openOrder[i].Material);
        openOrder[i].SalesOrganizationName = orgDesc[org.indexOf(openOrder[i].SalesOrganization)];
        openOrder[i].DistributionChannelName = channel[openOrder[i].DistributionChannel][lang];
        openOrder[i].OrganizationDivisionName = divition[openOrder[i].OrganizationDivision][lang];
        openOrder[i].ShippingPointName = shipPoint[openOrder[i].ShippingPoint][lang];
        openOrder[i].PaymentTermsName = payTerm[openOrder[i].CustomerPaymentTerms][lang];
        openOrder[i].incotermsName = incoTerm[openOrder[i].IncotermsClassification][lang];
        openOrder[i].SDDocumentReason = orderReason[openOrder[i].SDDocumentReason][lang];
        if(openOrder[i].StorageLocation != ""){
            for(var j=0,nj=plantStorage.length;j<nj;j++){
                if(openOrder[i].StorageLocation == plantStorage[j].StorageLocation){
                    openOrder[i].StorageLocationName = plantStorage[j].StorageLocationName;
                    openOrder[i].PlantName = plantStorage[j].PlantName;
                    break;
                }
            }
        }else{
            for(var j=0,nj=plantStorage.length;j<nj;j++){               
                if(openOrder[i].Plant == plantStorage[j].Plant){
                    openOrder[i].StorageLocationName = "";
                    openOrder[i].PlantName = plantStorage[j].PlantName;
                    break;
                }
            }
        }
    }
    
    var cb2 = function(){
        var ret = JSON.parse(this);
        
        for(var l=0,nl=ret.length;l<nl;l++){
            for(var i=0,n=openOrder.length;i<n;i++){
                if(ret[l].f_salesorder == openOrder[i].SalesDocument){
                    openOrder[i].YY1_BZ1_DLH = ret[l].f_tx01;
                    continue;
                }
            }
        }
        updStock('10003-tbody');
        //console.log(openOrder);
        updTable('10003','10003-tbody',openOrder);
        //updTable(sectionId,tbodyId,data)
    }
    //read LongText for SalesOrders
    var getReqBody = {"from_table":"t_oms_so", "where":{"f_salesorder":orderNumbers}};
    //console.log(getReqBody);
    anyAsyncJSON("POST", '/ordsys/admin/dbdata/t_oms_so', JSON.stringify(getReqBody), cb2);   
}
//var gotData = getSync('http://47.107.128.34:1573/ordsys/admin/prog/name/createSalesOrderOR', '', cb);
//var GETurl = 'http://47.107.128.34:1573/ordsys/admin/cdsview/YY1_CUSTOMER_CDS/YY1_Customer?$format=json';
var GETurl = "/ordsys/admin/cdsview/YY1_SO_SCHEDULELINE_CDS/YY1_SO_ScheduleLine?$format=json&$filter=LanguageSalesGroup eq 'zh' and LanguageSalesOffice eq 'zh' and LanguageCustomer eq 'zh' and YY1_SPZT_SDH eq 'Y'";
getAsync(GETurl, '', cb);

//国家地区联动
document.getElementById("11007-Country").addEventListener('change', function (event) {
    if(document.getElementById("regionlist")){
        var oDL = document.getElementById("regionlist");
        //if(countryRegion[event.target.value].length > 0){
            oDL.innerHTML = "";
        //}
    }else{
        //create new datalist
        var oDL = document.createElement("datalist");
        oDL.id = "regionlist";
    }
    for(var key in countryRegion[event.target.value]){
        //console.log(countryRegion[event.target.value][key]);
        var opt = new Option(countryRegion[event.target.value][key].RegionName,key);
        //oDL.options.add(opt,undefined);
        oDL.appendChild(opt);
    }
    var el = document.getElementById("11007-Region");
    el.parentNode.appendChild(oDL);
    el.setAttribute('list',"regionlist");
}, false);

//是否延期，如果是，延期原因必填
document.getElementById("10007-YY1_SFYQ_DLH").addEventListener('change', function (event) {
    if(event.target.value == "Y"){
        document.getElementById("10007-YY1_Z_YQYI_DLH").required = true;
        document.getElementById("10007-YY1_Z_YQYI_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "block";
        document.getElementById("10007-YY1_Z_YQYI_DLH").focus();
    }else if(event.target.value == "N"){
        document.getElementById("10007-YY1_Z_YQYI_DLH").required = false;
        document.getElementById("10007-YY1_Z_YQYI_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "none";
    }
}, false);

document.getElementById("10007-YY1_Z_YQYI_DLH").addEventListener('change', function (event) {
    
    if(event.target.value == "" && event.target.required == true){
        document.getElementById("10007-YY1_Z_YQYI_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "block";
    }else{
        document.getElementById("10007-YY1_Z_YQYI_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "none";
    }
}, false);

//是否中转
document.getElementById("10007-YY1_Z_ZZSF_DLH").addEventListener('change', function (event) {
    if(event.target.value == "Y"){
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").required = true;
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "block";
        document.getElementById("10007-YY1_Z_ZZMC_DLH").value = "广和通香港公司";
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").focus();
    }else if(event.target.value == "N"){
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").required = false;
        document.getElementById("10007-YY1_Z_ZZMC_DLH").value = "广和通香港公司";
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "none";
    }
}, false);

document.getElementById("10007-YY1_Z_ZZDZ1_DLH").addEventListener('change', function (event) {
    
    if(event.target.value == "" && event.target.required == true){
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "block";
    }else{
        document.getElementById("10007-YY1_Z_ZZDZ1_DLH").parentNode.querySelector(".fd-form-message--error").style.display = "none";
    }
}, false);
