drop database if exists "ordsys";
drop user if exists ordsys_admin;

create user ordsys_admin password 'ordsys_admin123';
CREATE DATABASE ordsys OWNER ordsys_admin;
grant all privileges on database ordsys to ordsys_admin;
