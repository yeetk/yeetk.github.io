--
-- PostgreSQL database dump
--

-- Dumped from database version 12.7 (Ubuntu 12.7-1.pgdg16.04+1)
-- Dumped by pg_dump version 12.7 (Ubuntu 12.7-1.pgdg16.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ordsys; Type: DATABASE; Schema: -; Owner: ordsys_admin
--

CREATE DATABASE ordsys WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE ordsys OWNER TO ordsys_admin;

\connect ordsys

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: t_auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_auth (
    f_authid integer NOT NULL,
    f_authname character varying(31) NOT NULL,
    f_authurl character varying(131),
    f_desc character varying(91),
    f_start_date date,
    f_end_date date,
    f_requestmethod character varying(5)
);


ALTER TABLE public.t_auth OWNER TO postgres;

--
-- Name: t_auth_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_auth_field (
    f_auth_id integer NOT NULL,
    f_field_id integer NOT NULL,
    f_from date,
    f_to date
);


ALTER TABLE public.t_auth_field OWNER TO postgres;

--
-- Name: t_cfg_coinf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_cfg_coinf (
    f_company character varying(19) NOT NULL,
    f_shortname character varying(31),
    f_industy character varying(31),
    f_industyseg character varying(91),
    f_focus character varying(91),
    f_fullname character varying(91),
    f_href character varying(319),
    f_logosrc character varying(913)
);


ALTER TABLE public.t_cfg_coinf OWNER TO postgres;

--
-- Name: TABLE t_cfg_coinf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.t_cfg_coinf IS '企业信息（名称、行业、细分行业、主营产品或服务、Logo、网址等）';


--
-- Name: t_gp_04; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_gp_04 (
    bokno character varying(40) NOT NULL,
    cncod character varying(10) NOT NULL,
    zqcqty integer,
    zztqty integer,
    zernam character varying(12),
    zeerdat date,
    zerzet time(6) without time zone,
    zlernam character varying(12),
    zleerdat date,
    zlerzet time(6) without time zone
);


ALTER TABLE public.t_gp_04 OWNER TO postgres;

--
-- Name: t_odata_api; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_odata_api (
    master_odata character varying(50) NOT NULL,
    master_entity character varying(50) NOT NULL,
    master_field character varying(50) NOT NULL,
    master_slave_field character varying(50),
    slave_odata character varying(50),
    slave_entity character varying(50),
    slave_field character varying(50),
    field_id integer NOT NULL,
    field_desc character varying(50)
);


ALTER TABLE public.t_odata_api OWNER TO postgres;

--
-- Name: COLUMN t_odata_api.master_odata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.t_odata_api.master_odata IS '主服务';


--
-- Name: COLUMN t_odata_api.master_entity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.t_odata_api.master_entity IS '主实体';


--
-- Name: COLUMN t_odata_api.master_field; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.t_odata_api.master_field IS '主字段';


--
-- Name: t_prog; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_prog (
    f_id integer NOT NULL,
    f_prog text,
    f_prog_title text,
    f_prog_type text
);


ALTER TABLE public.t_prog OWNER TO ordsys_admin;

--
-- Name: t_prog_f_progid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_prog_f_progid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_prog_f_progid_seq OWNER TO ordsys_admin;

--
-- Name: t_prog_f_progid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_prog_f_progid_seq OWNED BY public.t_prog.f_id;


--
-- Name: t_role; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_role (
    f_id integer NOT NULL,
    f_role text,
    f_title jsonb,
    f_description jsonb
);


ALTER TABLE public.t_role OWNER TO ordsys_admin;

--
-- Name: COLUMN t_role.f_title; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_role.f_title IS '{“zh”:””,”en”:””}';


--
-- Name: COLUMN t_role.f_description; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_role.f_description IS '{“zh”:””,”en”:””}';


--
-- Name: t_role_auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_role_auth (
    f_role_id integer NOT NULL,
    f_auth_id integer NOT NULL,
    f_from date,
    f_to date
);


ALTER TABLE public.t_role_auth OWNER TO postgres;

--
-- Name: t_role_f_roleid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_role_f_roleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_role_f_roleid_seq OWNER TO ordsys_admin;

--
-- Name: t_role_f_roleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_role_f_roleid_seq OWNED BY public.t_role.f_id;


--
-- Name: t_role_menu; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_role_menu (
    f_role_id integer NOT NULL,
    f_prog_id integer NOT NULL,
    f_menu jsonb
);


ALTER TABLE public.t_role_menu OWNER TO ordsys_admin;

--
-- Name: COLUMN t_role_menu.f_menu; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_role_menu.f_menu IS '{“zh”:””,”en”:””}';


--
-- Name: t_rolemenu_f_roleid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_rolemenu_f_roleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_rolemenu_f_roleid_seq OWNER TO ordsys_admin;

--
-- Name: t_rolemenu_f_roleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_rolemenu_f_roleid_seq OWNED BY public.t_role_menu.f_role_id;


--
-- Name: t_user; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_user (
    f_id integer NOT NULL,
    f_uname character varying(31) NOT NULL,
    f_passwd character varying(31),
    f_group character varying(13),
    f_status character varying(13),
    f_bp_role character varying(31),
    f_supplier character varying(41),
    f_fname text,
    f_lname text,
    f_full_name text,
    f_gender boolean,
    f_email character varying(31),
    f_phone text,
    f_mobile numeric(15,0),
    f_language text,
    f_company character varying(19),
    f_cost_center numeric(10,0),
    f_start_date date,
    f_end_date date,
    f_sap_url character varying(255),
    f_sap_format character varying(20),
    f_sap_client character varying(20),
    f_default_env character varying(31),
    f_md5 character varying(68)
);


ALTER TABLE public.t_user OWNER TO ordsys_admin;

--
-- Name: COLUMN t_user.f_language; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_user.f_language IS 'zh/en';


--
-- Name: COLUMN t_user.f_default_env; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_user.f_default_env IS '默认环境 SAP GUI连接方式';


--
-- Name: t_user_auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_user_auth (
    f_uname character varying(31) NOT NULL,
    f_component character varying(319) NOT NULL,
    f_authdata text,
    f_default character varying(131)
);


ALTER TABLE public.t_user_auth OWNER TO postgres;

--
-- Name: t_user_f_usrid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_user_f_usrid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_user_f_usrid_seq OWNER TO ordsys_admin;

--
-- Name: t_user_f_usrid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_user_f_usrid_seq OWNED BY public.t_user.f_id;


--
-- Name: t_user_role; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_user_role (
    f_user_id integer NOT NULL,
    f_role_id integer NOT NULL,
    f_from date,
    f_to date
);


ALTER TABLE public.t_user_role OWNER TO ordsys_admin;

--
-- Name: t_userrole_f_roleid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_userrole_f_roleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_userrole_f_roleid_seq OWNER TO ordsys_admin;

--
-- Name: t_userrole_f_roleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_userrole_f_roleid_seq OWNED BY public.t_user_role.f_role_id;


--
-- Name: t_userrole_f_userid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_userrole_f_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_userrole_f_userid_seq OWNER TO ordsys_admin;

--
-- Name: t_userrole_f_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_userrole_f_userid_seq OWNED BY public.t_user_role.f_user_id;


--
-- Name: t_prog f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_prog ALTER COLUMN f_id SET DEFAULT nextval('public.t_prog_f_progid_seq'::regclass);


--
-- Name: t_role f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role ALTER COLUMN f_id SET DEFAULT nextval('public.t_role_f_roleid_seq'::regclass);


--
-- Name: t_user f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_user ALTER COLUMN f_id SET DEFAULT nextval('public.t_user_f_usrid_seq'::regclass);


--
-- Data for Name: t_auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_auth (f_authid, f_authname, f_authurl, f_desc, f_start_date, f_end_date, f_requestmethod) FROM stdin;
1	Monthly Statement	/sbshtml/SD/statement/selectScreen.html	盛博-对账单	2022-03-14	9999-12-12	post
5	Raw Material Convert	/GenrPro/CD/RawConvert.html	仓库保税成品折料表	\N	\N	post
4	WIP Raw Material Stock	/GenrPro/CD/WIPRawStock.html	WIP保税原材库存表	\N	\N	post
6	Book Balance	/GenrPro/CD/BookBalance.html	手册平衡表	\N	\N	post
2	Customs Declaration	/GenrPro/CD/list.html	报关单管理	\N	\N	post
3	Bonded BOM Compare	/GenrPro/CD/BomCompare.html	备案BOM对比	\N	\N	post
\.


--
-- Data for Name: t_auth_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_auth_field (f_auth_id, f_field_id, f_from, f_to) FROM stdin;
1	1	2022-03-14	9999-12-12
1	12	2022-03-14	9999-12-12
1	11	2022-03-14	9999-12-12
1	2	2022-03-14	9999-12-12
1	4	2022-03-14	9999-12-12
1	3	2022-03-14	9999-12-12
1	6	2022-03-14	9999-12-12
1	5	2022-03-14	9999-12-12
1	8	2022-03-14	9999-12-12
1	7	2022-03-14	9999-12-12
1	10	2022-03-14	9999-12-12
1	9	2022-03-14	9999-12-12
1	13	2022-03-14	9999-12-12
1	14	2022-03-14	9999-12-12
1	15	2022-03-14	9999-12-12
\.


--
-- Data for Name: t_cfg_coinf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_cfg_coinf (f_company, f_shortname, f_industy, f_industyseg, f_focus, f_fullname, f_href, f_logosrc) FROM stdin;
SBS	盛博	计算机	嵌入式计算机	工业计算机	盛博科技嵌入式计算机有限公司	http://www.sbs.com.cn	http://www.sbs.com.cn/App_Assets/Images/logo.jpg
GenrPro	精卓	计算机	PC	PC	安徽精卓光显技术有限责任公司	http://www.genrpro.com	http://www.genrpro.com/com_jn/images/logo.png
\.


--
-- Data for Name: t_gp_04; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_gp_04 (bokno, cncod, zqcqty, zztqty, zernam, zeerdat, zerzet, zlernam, zleerdat, zlerzet) FROM stdin;
C331022A0064	4	123	456	ZZH	2023-02-09	04:45:42	\N	\N	\N
C331022A0064	3	222	222	ZZH	2023-02-09	04:45:13	gptest	2023-02-11	01:56:20
C331022A0092	31	1	0	gptest	2023-02-13	13:51:11	\N	\N	\N
C331022A0092	1	2	3	gptest	2023-02-13	13:52:04	gptest	2023-02-13	13:52:31
C331022A0064	1	741	100	zzh	2023-02-09	03:04:00	gptest	2023-02-14	11:11:05
C331022A0064	5	3	0	gptest	2023-02-14	14:11:46	\N	\N	\N
C331022A0092	2	1	0	gptest	2023-02-15	09:40:19	\N	\N	\N
C331022A0064	2	666	456	ZZH	2023-02-09	04:45:13	gptest	2023-02-15	14:43:18
\.


--
-- Data for Name: t_odata_api; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_odata_api (master_odata, master_entity, master_field, master_slave_field, slave_odata, slave_entity, slave_field, field_id, field_desc) FROM stdin;
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SalesOrderItemText					12	规格型号
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SalesOrder					7	订单号
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	InventorySpecialStockType					14	交货单类型
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SoldToParty					5	客户
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	CreatedByUser					13	创建者
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SalesOrganization					1	销售组织
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SalesOffice					3	销售办公室
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SalesGroup					4	销售组
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	ProductAvailabilityDate					6	实际货物移动日期
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	Material					9	物料编码
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	MaterialByCustomer					10	客户物料编号
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	DeliveryDocument					8	交货单号
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	ProductDescription					11	物料描述
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	SalesOrderType					15	订单类型
/ZCDS_SBS_STATEMENT_SELECT_CDS	/ZCDS_SBS_STATEMENT_SELECT	ProductionPlant					2	工厂
\.


--
-- Data for Name: t_prog; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_prog (f_id, f_prog, f_prog_title, f_prog_type) FROM stdin;
0	createSalesOrderOR	标准订单创建	tree
1	json	prog_title_v	prog_type_v
2	createDeliveryNote	Create Delivery Note	table
3	changeDeliveryNote	Change Delivery Note	tree
4	changeSalesOrderOR	标准订单修改	tree
5	createSalesOrderCBFD	免费订单创建	tree
7	changeSalesOrderCBFD	免费订单修改	tree
8	createSalesOrderDR	创建借项订单	tree
9	createSalesOrderCR	创建贷项订单	tree
10	changeSalesOrderDR	修改借项订单	tree
6	salesOrderList	销售订单列表	table
11	createLeanReturn	退货订单创建	tree
12	customerMasterData	客户主数据	tree
13	referenceContract	参考合同制订单	tree
\.


--
-- Data for Name: t_role; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_role (f_id, f_role, f_title, f_description) FROM stdin;
0	role-sg-032	{"EN": "Han Wei", "ZH": "韩伟"}	{"EN": "Sales Group Han Wei032", "ZH": "销售员韩伟032"}
1	role-sg-033	{"EN": "Lian zechao", "ZH": "练泽超"}	{"EN": "Sales Group Lian zechao033", "ZH": "销售员练泽超033"}
2	role-sg-001	{"EN": "Huang Yongzhi", "ZH": "黄永志"}	{"EN": "Sales Group Huang yongzhi001", "ZH": "销售员黄永志001"}
4	role-sg-Z01	{"EN": "Huang Yongzhi", "ZH": "黄永志"}	{"EN": "Sales Group Huang yongzhiZ01", "ZH": "销售员黄永志Z01"}
5	role-sg-068	{"EN": "Fan Yucheng", "ZH": "樊宇城"}	{"EN": "Sales Group Fan YuCheng068", "ZH": "销售员樊宇城068"}
3	role-sg-012	{"EN": "Sun Xiaojing", "ZH": "孙晓婧"}	{"EN": "Sales Group Sun Xiaojing012", "ZH": "销售员孙晓婧012"}
6	role-sg-069	{"EN": "Wang Hongxin", "ZH": "王洪新"}	{"EN": "Sales Group Wang Hongxin069", "ZH": "销售员王洪新069"}
7	role-sg-003	{"EN": "Zhangning", "ZH": "张宁"}	{"EN": "Sales Group Zhangning003", "ZH": "销售员张宁003"}
8	role-sg-035	{"EN": "Amy Debuysere", "ZH": "Amy Debuysere"}	{"EN": "Sales Group Amy Debuysere 035", "ZH": "Amy Debuysere 035"}
9	role-sg-063	{"EN": "Zhangxiaobo", "ZH": "张晓波"}	{"EN": "Sales Group Zhangxiaobo063", "ZH": "销售员张晓波063"}
10	role-sg-031	{"EN": "Zhuxiaocui", "ZH": "朱晓翠"}	{"EN": "Sales Group Zhuxiaocui031", "ZH": "销售员朱晓翠031"}
11	role-sg-038	{"EN": "Chen Liren", "ZH": "陈立人"}	{"EN": "Sales Group Chenliren038", "ZH": "销售员陈立人038"}
12	role-sg-037	{"EN": "Cai Peirong", "ZH": "蔡佩蓉"}	{"EN": "Sales Group Caipeirong037", "ZH": "销售员蔡佩蓉037"}
13	role-sg-035	{"EN": "Amy Debuysere", "ZH": "Amy Debuysere"}	{"EN": "Sales Group Amy Debuysere035", "ZH": "销售员Amy Debuysere035"}
14	role-sg-034	{"EN": "Zhang Yini", "ZH": "张轶尼"}	{"EN": "Sales Group Zhang Yini034", "ZH": "销售员张轶尼034"}
15	role-sg-Z13	{"EN": "Yang qin", "ZH": "杨琴"}	{"EN": "Sales Group Yang QinZ13", "ZH": "销售员杨琴Z13"}
16	role-sg-Z14	{"EN": "Zou Wei", "ZH": "邹伟"}	{"EN": "Sales Group Zou WeiZ14", "ZH": "销售员邹伟Z14"}
17	role-sg-056	{"EN": "Cao Erwan", "ZH": "操二万"}	{"EN": "Sales Group Cao Erwan056", "ZH": "销售员操二万056"}
19	role-sb-user	\N	\N
18	role-sg-Z32	{"EN": "Han Wei", "ZH": "韩伟"}	{"EN": "Sales Group Han WeiZ32", "ZH": "销售员韩伟Z32"}
20	role-gp-cd	\N	\N
\.


--
-- Data for Name: t_role_auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_role_auth (f_role_id, f_auth_id, f_from, f_to) FROM stdin;
19	1	2022-03-14	9999-12-31
20	2	2022-09-01	9999-12-31
20	3	2022-09-01	9999-12-31
20	4	2022-09-01	9999-12-31
20	5	2022-09-01	9999-12-31
20	6	2022-09-01	9999-12-31
\.


--
-- Data for Name: t_role_menu; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_role_menu (f_role_id, f_prog_id, f_menu) FROM stdin;
\.


--
-- Data for Name: t_user; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_user (f_id, f_uname, f_passwd, f_group, f_status, f_bp_role, f_supplier, f_fname, f_lname, f_full_name, f_gender, f_email, f_phone, f_mobile, f_language, f_company, f_cost_center, f_start_date, f_end_date, f_sap_url, f_sap_format, f_sap_client, f_default_env, f_md5) FROM stdin;
2	test01	123456	user	\N	\N	\N	\N	\N	salesgroup001	\N	\N	\N	\N	\N	\N	\N	2019-12-31	9999-12-31	\N	\N	\N	\N	\N
1	wusm	123456	user	\N	\N	\N	\N	\N	吴仕敏	f	yedy@fibocom.com	0755-26028695	\N	\N	\N	\N	2019-12-12	9999-12-31	\N	\N	\N	\N	\N
7	wangh	123456	user	\N	\N	\N	\N	\N	王钬	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	huangdy	123456	user	\N	\N	\N	\N	\N	黄冬玉	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	tany	123456	user	\N	\N	\N	\N	\N	谭园	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	chenm	123456	user	\N	\N	\N	\N	\N	陈敏	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	sunln	123456	user	\N	\N	\N	\N	\N	孙丽娜	\N	\N	\N	\N	\N	\N	\N	2019-12-31	9999-12-31	\N	\N	\N	\N	\N
5	chency	123456	user	\N	\N	\N	\N	\N	陈采云	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
29	FD08	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
30	FD09	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
31	SF01	123456	\N	\N	\N	\N	\N	\N	上海财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
24	FD03	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
25	FD04	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
26	FD05	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
27	FD06	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
32	NF01	123456	\N	\N	\N	\N	\N	\N	南京财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
33	NF02	123456	\N	\N	\N	\N	\N	\N	南京财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
28	FD07	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	\N	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
9	SAPPP	123456789	user	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=500	\N	\N
23	FD02	123456	\N	\N	\N	\N	\N	\N	深圳财务	\N	\N	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erpdev.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
13	SD11	123456	\N	\N	\N	\N	\N	\N	SD11	\N	285316774@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
36	SD22	895206	\N	\N	\N	\N	\N	\N	SD22	\N	278503631@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	
15	SD13	123456	\N	\N	\N	\N	\N	\N	SD13	\N	3599516019@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
14	SD12	123456	\N	\N	\N	\N	\N	\N	SD12	\N	89605887@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
40	SD15	123456	\N	\N	\N	\N	\N	\N	SD15	\N	beijing@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
34	SAPLZJ	lang8346520	\N	\N	\N	\N	\N	\N	SBS_IT	\N	langzj@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	3535e423c3c0970580e8a6f044f0ccbf
41	SD18	123456	\N	\N	\N	\N	\N	\N	SD18	\N	407882100@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
10	SD01	123456	\N	\N	\N	\N	\N	\N	SD01	\N	wuyao@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
11	SD02	123456	\N	\N	\N	\N	\N	\N	SD02	\N	shenzhen@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
0	tingkai	112233	admin	\N	\N	\N	\N	\N	tingkai	\N	libero@yeah.net	\N	\N	\N	\N	\N	2019-12-31	9999-12-31	\N	\N	\N	\N	
39	SD03	123456	\N	\N	\N	\N	\N	\N	SD03	\N	liwangwang@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
12	SD06	123456	\N	\N	\N	\N	\N	\N	SD06	\N	442114874@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
35	SD07	123456	\N	\N	\N	\N	\N	\N	SD07	\N	642695916@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
17	SD19	123456	\N	\N	\N	\N	\N	\N	SD19	\N	zhaohua@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
22	SD28	123456	\N	\N	\N	\N	\N	\N	SD28	\N	kongshengnan@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
21	SD27	123456	\N	\N	\N	\N	\N	\N	SD27	\N	wangyuanyuan@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
19	SD25	123456	\N	\N	\N	\N	\N	\N	SD25	\N	954508599@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	3535e423c3c0970580e8a6f044f0ccbf
37	SD32	123456	\N	\N	\N	\N	\N	\N	SD32	\N	huangmei@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
18	SD21	008023	\N	\N	\N	\N	\N	\N	SD21	\N	shiyirong@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	
38	gptest	123456	\N	\N	\N	\N	\N	\N	精卓测试账号	\N	liaoxj@chinasofttech.com	\N	\N	\N	GenrPro	\N	2022-09-01	9999-12-31	https://223.243.99.172:39443/sap/opu/odata/sap	&$format=json	&sap-client=130	\N	
16	SD17	123456	\N	\N	\N	\N	\N	\N	SD17	\N	1131087962@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	\N
20	SD26	123456	\N	\N	\N	\N	\N	\N	SD26	\N	281115890@qq.com	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	3535e423c3c0970580e8a6f044f0ccbf
42	MM01	123456	\N	\N	\N	\N	\N	\N	柳总	\N	liuy@sbs.com.cn	\N	\N	\N	SBS	\N	2022-03-14	9999-12-31	https://erp.sbs.com.cn/sap/opu/odata/sap	&$format=json	&sap-client=400	\N	
\.


--
-- Data for Name: t_user_auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_user_auth (f_uname, f_component, f_authdata, f_default) FROM stdin;
SD19	SalesGroup	015	\N
SD19	SalesOffice	S030	\N
SD21	SalesGroup	017,018,019,020	\N
SD21	SalesOffice	S030	\N
SD19	SalesOrganization	1310,1320	\N
SD21	SalesOrganization	1310,1320	\N
SD22	SalesGroup	016,021,022	\N
SD22	SalesOffice	S030	\N
SD22	SalesOrganization	1310,1320	\N
SD07	SalesOffice	S060	\N
SD07	SalesOrganization	1310,1330	\N
SD01	SalesGroup	001,002,003,004,043	\N
SD01	SalesOffice	S010	\N
SD01	SalesOrganization	1310	\N
SD07	SalesGroup	029	\N
SD06	SalesGroup	030,031,032,033	\N
SD06	SalesOffice	S060	\N
SD06	SalesOrganization	1310,1330	\N
SD12	SalesGroup	034,035,036,037,038	\N
SD12	SalesOffice	S070	\N
SD12	SalesOrganization	1310,1330	\N
SD13	SalesGroup	034,035,036,037,038	\N
SD13	SalesOffice	S070	\N
SD13	SalesOrganization	1310,1330	\N
SD11	SalesGroup	039	\N
SD11	SalesOffice	S071	\N
SD11	SalesOrganization	1310	\N
SD03	SalesGroup	001,002,003,004,043	\N
SD03	SalesOffice	S010	\N
SD03	SalesOrganization	1310	\N
SD15	SalesGroup	005,006,007,008,009	\N
SD15	SalesOffice	S020	\N
SD15	SalesOrganization	1310	\N
SD17	SalesGroup	026,027,028	\N
SD17	SalesOffice	S050	\N
SD17	SalesOrganization	1310	\N
SD18	SalesGroup	026,027,028	\N
SD18	SalesOffice	S050	\N
SD18	SalesOrganization	1310	\N
SD25	SalesGroup	041,042	\N
SD25	SalesOffice	S090	\N
SD25	SalesOrganization	1310,1330	\N
SD26	SalesGroup	023,024,025	\N
SD26	SalesOffice	S040	\N
SD26	SalesOrganization	1310	\N
SD27	SalesGroup	010,011,012,013,014,045	\N
SD27	SalesOffice	S021	\N
SD28	SalesGroup	040,044	\N
SD28	SalesOffice	S080	\N
SD28	SalesOrganization	1310,1330	\N
SD02	SalesGroup	001,002,003,004,005,006,007,008,009,010,011,012,013,014,015,016,017,018,019,020,021,022,023,024,025,026,027,028,029,030,031,032,033,034,035,036,037,038,039,040,041,042,043,044,045	\N
SD02	SalesOrganization	1310,1320,1330	\N
SD32	SalesGroup	001,002,003,004,005,006,007,008,009,010,011,012,013,014,015,016,017,018,019,020,021,022,023,024,025,026,027,028,029,030,031,032,033,034,035,036,037,038,039,040,041,042,043,044,045	\N
SD32	SalesOffice	S010	\N
SD32	SalesOrganization	1310,1320,1330	\N
SD27	SalesOrganization	1310,1330	\N
SD02	SalesOffice	S010,S020,S021,S030,S040,S050,S060,S070,S071,S080,S090	\N
SAPLZJ	SalesOffice	S010,S020,S021,S030,S040,S050,S060,S070,S071,S080,S090	\N
SAPLZJ	SalesGroup	001,002,003,004,005,006,007,008,009,010,011,012,013,014,015,016,017,018,019,020,021,022,023,024,025,026,027,028,029,030,031,032,033,034,035,036,037,038,039,040,041,042,043,044,045	\N
SAPLZJ	SalesOrganization	1310,1320,1330	\N
MM01	SalesGroup	001,002,003,004,005,006,007,008,009,010,011,012,013,014,015,016,017,018,019,020,021,022,023,024,025,026,027,028,029,030,031,032,033,034,035,036,037,038,039,040,041,042,043,044,045	\N
MM01	SalesOrganization	1310,1320,1330	\N
MM01	SalesOffice	S010,S020,S021,S030,S040,S050,S060,S070,S071,S080,S090	\N
\.


--
-- Data for Name: t_user_role; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_user_role (f_user_id, f_role_id, f_from, f_to) FROM stdin;
1	0	2019-12-12	9999-12-31
1	1	2019-12-12	9999-12-31
2	2	2019-12-14	9999-12-31
3	3	2019-12-15	9999-12-31
2	4	2019-12-17	9999-12-31
3	5	2019-12-24	9999-12-31
3	6	2019-12-24	9999-12-31
4	7	2019-12-26	9999-12-31
4	8	2019-12-26	9999-12-31
5	9	2019-12-26	9999-12-31
5	10	2019-12-26	9999-12-31
6	11	2019-12-30	9999-12-31
6	12	2019-12-30	9999-12-31
7	13	2019-12-30	9999-12-31
7	14	2019-12-30	9999-12-31
8	15	2019-12-30	9999-12-31
8	16	2019-12-30	9999-12-31
8	17	2020-01-01	9999-12-31
1	18	2020-01-10	9999-12-31
4	4	2019-12-26	9999-12-31
4	19	2019-12-26	9999-12-31
4	2	2019-12-14	9999-12-31
9	19	2022-03-14	9999-12-12
10	19	2022-03-14	9999-12-12
11	19	2022-03-14	9999-12-12
13	19	2022-03-14	9999-12-12
12	19	2022-03-14	9999-12-12
14	19	2022-03-14	9999-12-12
15	19	2022-03-14	9999-12-12
16	19	2022-03-14	9999-12-12
17	19	2022-03-14	9999-12-12
18	19	2022-03-14	9999-12-12
19	19	2022-03-14	9999-12-12
20	19	2022-03-14	9999-12-12
21	19	2022-03-14	9999-12-12
22	19	2022-03-14	9999-12-12
23	19	2022-03-14	9999-12-12
24	19	2022-03-14	9999-12-12
25	19	2022-03-14	9999-12-12
26	19	2022-03-14	9999-12-12
27	19	2022-03-14	9999-12-12
28	19	2022-03-14	9999-12-12
29	19	2022-03-14	9999-12-12
30	19	2022-03-14	9999-12-12
31	19	2022-03-14	9999-12-12
32	19	2022-03-14	9999-12-12
33	19	2022-03-14	9999-12-12
34	19	2022-03-14	9999-12-12
35	19	2022-03-14	9999-12-12
36	19	2022-03-14	9999-12-12
37	19	2022-03-14	9999-12-12
38	20	2022-09-01	9999-12-12
39	19	2022-03-14	9999-12-12
40	19	2022-03-14	9999-12-12
41	19	2022-03-14	9999-12-12
42	19	2022-03-14	9999-12-12
\.


--
-- Name: t_prog_f_progid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_prog_f_progid_seq', 1, true);


--
-- Name: t_role_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_role_f_roleid_seq', 2, true);


--
-- Name: t_rolemenu_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_rolemenu_f_roleid_seq', 1, false);


--
-- Name: t_user_f_usrid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_user_f_usrid_seq', 1, true);


--
-- Name: t_userrole_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_userrole_f_roleid_seq', 1, false);


--
-- Name: t_userrole_f_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_userrole_f_userid_seq', 1, false);


--
-- Name: t_auth_field auth_field_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_auth_field
    ADD CONSTRAINT auth_field_key PRIMARY KEY (f_auth_id, f_field_id);


--
-- Name: t_role_auth role_auth_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_role_auth
    ADD CONSTRAINT role_auth_key PRIMARY KEY (f_role_id, f_auth_id);


--
-- Name: t_auth t_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_auth
    ADD CONSTRAINT t_auth_pkey PRIMARY KEY (f_authid);


--
-- Name: t_cfg_coinf t_cfg_coinf_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_cfg_coinf
    ADD CONSTRAINT t_cfg_coinf_pkey PRIMARY KEY (f_company);


--
-- Name: t_gp_04 t_gp_04_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_gp_04
    ADD CONSTRAINT t_gp_04_pkey PRIMARY KEY (bokno, cncod);


--
-- Name: t_odata_api t_odata_api_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_odata_api
    ADD CONSTRAINT t_odata_api_pkey PRIMARY KEY (field_id);


--
-- Name: t_prog t_prog_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_prog
    ADD CONSTRAINT t_prog_pkey PRIMARY KEY (f_id);


--
-- Name: t_role t_role_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role
    ADD CONSTRAINT t_role_pkey PRIMARY KEY (f_id);


--
-- Name: t_role_menu t_rolemenu_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role_menu
    ADD CONSTRAINT t_rolemenu_pkey PRIMARY KEY (f_role_id, f_prog_id);


--
-- Name: t_user_auth t_user_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_user_auth
    ADD CONSTRAINT t_user_auth_pkey PRIMARY KEY (f_uname, f_component);


--
-- Name: t_user t_user_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_user
    ADD CONSTRAINT t_user_pkey PRIMARY KEY (f_id);


--
-- Name: t_user_role t_userrole_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_user_role
    ADD CONSTRAINT t_userrole_pkey PRIMARY KEY (f_user_id, f_role_id);


--
-- PostgreSQL database dump complete
--

