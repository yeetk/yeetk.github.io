--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.0

-- Started on 2019-11-30 19:21:12 CST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 209 (class 1259 OID 16426)
-- Name: t_prog; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_prog (
    f_id integer NOT NULL,
    f_prog text,
    f_prog_title text,
    f_prog_type text
);


ALTER TABLE public.t_prog OWNER TO ordsys_admin;

--
-- TOC entry 210 (class 1259 OID 16432)
-- Name: t_prog_api; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_prog_api (
    f_prog_id integer NOT NULL,
    f_api_id integer NOT NULL
);


ALTER TABLE public.t_prog_api OWNER TO ordsys_admin;

--
-- TOC entry 211 (class 1259 OID 16435)
-- Name: t_prog_f_progid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_prog_f_progid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_prog_f_progid_seq OWNER TO ordsys_admin;

--
-- TOC entry 3372 (class 0 OID 0)
-- Dependencies: 211
-- Name: t_prog_f_progid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_prog_f_progid_seq OWNED BY public.t_prog.f_id;

--
-- TOC entry 213 (class 1259 OID 16440)
-- Name: t_role; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_role (
    f_id integer NOT NULL,
    f_role text,
    f_title jsonb,
    f_description jsonb
);


ALTER TABLE public.t_role OWNER TO ordsys_admin;

--
-- TOC entry 3373 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN t_role.f_title; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_role.f_title IS '{“zh”:””,”en”:””}';


--
-- TOC entry 3374 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN t_role.f_description; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_role.f_description IS '{“zh”:””,”en”:””}';


--
-- TOC entry 215 (class 1259 OID 16452)
-- Name: t_role_f_roleid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_role_f_roleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_role_f_roleid_seq OWNER TO ordsys_admin;

--
-- TOC entry 3375 (class 0 OID 0)
-- Dependencies: 215
-- Name: t_role_f_roleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_role_f_roleid_seq OWNED BY public.t_role.f_id;


--
-- TOC entry 216 (class 1259 OID 16454)
-- Name: t_role_menu; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_role_menu (
    f_role_id integer NOT NULL,
    f_prog_id integer NOT NULL,
    f_menu jsonb
);


ALTER TABLE public.t_role_menu OWNER TO ordsys_admin;

--
-- TOC entry 3376 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN t_role_menu.f_menu; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_role_menu.f_menu IS '{“zh”:””,”en”:””}';


--
-- TOC entry 219 (class 1259 OID 16468)
-- Name: t_rolemenu_f_roleid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_rolemenu_f_roleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_rolemenu_f_roleid_seq OWNER TO ordsys_admin;

--
-- TOC entry 3378 (class 0 OID 0)
-- Dependencies: 219
-- Name: t_rolemenu_f_roleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_rolemenu_f_roleid_seq OWNED BY public.t_role_menu.f_role_id;


--
-- TOC entry 225 (class 1259 OID 16496)
-- Name: t_user; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_user (
    f_id integer NOT NULL,
    f_uname text,
    f_passwd text,
    f_group text,
    f_status text,
    f_bp_role text,
    f_supplier text,
    f_fname text,
    f_lname text,
    f_full_name text,
    f_gender boolean,
    f_email text,
    f_phone text,
    f_mobile numeric(15,0),
    f_language text,
    f_company text,
    f_cost_center numeric(10,0),
    f_start_date date,
    f_end_date date
);


ALTER TABLE public.t_user OWNER TO ordsys_admin;

--
-- TOC entry 3387 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN t_user.f_language; Type: COMMENT; Schema: public; Owner: ordsys_admin
--

COMMENT ON COLUMN public.t_user.f_language IS 'zh/en';


--
-- TOC entry 226 (class 1259 OID 16502)
-- Name: t_user_f_usrid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_user_f_usrid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_user_f_usrid_seq OWNER TO ordsys_admin;

--
-- TOC entry 3388 (class 0 OID 0)
-- Dependencies: 226
-- Name: t_user_f_usrid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_user_f_usrid_seq OWNED BY public.t_user.f_id;


--
-- TOC entry 227 (class 1259 OID 16504)
-- Name: t_user_role; Type: TABLE; Schema: public; Owner: ordsys_admin
--

CREATE TABLE public.t_user_role (
    f_user_id integer NOT NULL,
    f_role_id integer NOT NULL,
    f_from time(6) without time zone,
    f_to time(6) without time zone
);


ALTER TABLE public.t_user_role OWNER TO ordsys_admin;

--
-- TOC entry 228 (class 1259 OID 16507)
-- Name: t_userrole_f_roleid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_userrole_f_roleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_userrole_f_roleid_seq OWNER TO ordsys_admin;

--
-- TOC entry 3389 (class 0 OID 0)
-- Dependencies: 228
-- Name: t_userrole_f_roleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_userrole_f_roleid_seq OWNED BY public.t_user_role.f_role_id;


--
-- TOC entry 229 (class 1259 OID 16509)
-- Name: t_userrole_f_userid_seq; Type: SEQUENCE; Schema: public; Owner: ordsys_admin
--

CREATE SEQUENCE public.t_userrole_f_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_userrole_f_userid_seq OWNER TO ordsys_admin;

--
-- TOC entry 3390 (class 0 OID 0)
-- Dependencies: 229
-- Name: t_userrole_f_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ordsys_admin
--

ALTER SEQUENCE public.t_userrole_f_userid_seq OWNED BY public.t_user_role.f_user_id;


--
-- TOC entry 3163 (class 2604 OID 16511)
-- Name: t_api f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api ALTER COLUMN f_id SET DEFAULT nextval('public.t_api_f_apiid_seq'::regclass);


--
-- TOC entry 3164 (class 2604 OID 16512)
-- Name: t_prog f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_prog ALTER COLUMN f_id SET DEFAULT nextval('public.t_prog_f_progid_seq'::regclass);


--
-- TOC entry 3165 (class 2604 OID 16513)
-- Name: t_role f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role ALTER COLUMN f_id SET DEFAULT nextval('public.t_role_f_roleid_seq'::regclass);


--
-- TOC entry 3166 (class 2604 OID 16514)
-- Name: t_section f_section_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_section ALTER COLUMN f_section_id SET DEFAULT nextval('public.t_section_f_sectionid_seq'::regclass);


--
-- TOC entry 3167 (class 2604 OID 16515)
-- Name: t_user f_id; Type: DEFAULT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_user ALTER COLUMN f_id SET DEFAULT nextval('public.t_user_f_usrid_seq'::regclass);


--
-- TOC entry 3334 (class 0 OID 16388)
-- Dependencies: 202
-- Data for Name: t_api; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_api (f_id, f_api, f_api_type, f_version) FROM stdin;
\.


--
-- TOC entry 3335 (class 0 OID 16394)
-- Dependencies: 203
-- Data for Name: t_api_call; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_api_call (f_section_id, f_component, f_sequence, f_call_api, f_call_entityset, f_entitytype) FROM stdin;
\.


--
-- TOC entry 3336 (class 0 OID 16400)
-- Dependencies: 204
-- Data for Name: t_api_entity; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_api_entity (f_api_id, f_entity, f_label, f_entity_version) FROM stdin;
\.


--
-- TOC entry 3338 (class 0 OID 16408)
-- Dependencies: 206
-- Data for Name: t_api_field; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_api_field (f_apiid, f_entity, f_property, f_type, f_key, f_nullable, f_length, f_format, f_label, f_precision, f_scale, f_unit, f_quickinfo, f_creatable, f_updatable, f_concurrencymode, f_semantics) FROM stdin;
\.


--
-- TOC entry 3339 (class 0 OID 16414)
-- Dependencies: 207
-- Data for Name: t_api_map; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_api_map (f_property, f_field_name) FROM stdin;
Name	f_property
Type	f_type
Nullable	f_nullable
MaxLength	f_length
sap:display-format	f_format
sap:label	f_label
Precision	f_precision
Scale	f_scale
sap:unit	f_unit
sap:quickinfo	f_quickinfo
sap:creatable	f_creatable
sap:updatable	f_updatable
ConcurrencyMode	f_concurrencymode
sap:semantics	f_semantics
\.


--
-- TOC entry 3340 (class 0 OID 16420)
-- Dependencies: 208
-- Data for Name: t_api_navigation; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_api_navigation (f_call_api, f_call_entityset, f_navigation, f_association, f_multiplicity) FROM stdin;
\.


--
-- TOC entry 3341 (class 0 OID 16426)
-- Dependencies: 209
-- Data for Name: t_prog; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_prog (f_id, f_prog, f_prog_title, f_prog_type) FROM stdin;
\.


--
-- TOC entry 3342 (class 0 OID 16432)
-- Dependencies: 210
-- Data for Name: t_prog_api; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_prog_api (f_prog_id, f_api_id) FROM stdin;
\.


--
-- TOC entry 3344 (class 0 OID 16437)
-- Dependencies: 212
-- Data for Name: t_prog_section; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_prog_section (f_prog_id, f_screen_id, f_section_id, f_section_sorter) FROM stdin;
\.


--
-- TOC entry 3345 (class 0 OID 16440)
-- Dependencies: 213
-- Data for Name: t_role; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_role (f_id, f_role, f_title, f_description) FROM stdin;
\.


--
-- TOC entry 3346 (class 0 OID 16446)
-- Dependencies: 214
-- Data for Name: t_role_dp; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_role_dp (f_role_id, f_prog, f_section_id, f_component, f_display) FROM stdin;
\.


--
-- TOC entry 3348 (class 0 OID 16454)
-- Dependencies: 216
-- Data for Name: t_role_menu; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_role_menu (f_role_id, f_prog_id, f_menu) FROM stdin;
\.


--
-- TOC entry 3349 (class 0 OID 16460)
-- Dependencies: 217
-- Data for Name: t_role_value; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_role_value (f_role_id, f_section_id, f_component, f_values) FROM stdin;
\.


--
-- TOC entry 3352 (class 0 OID 16470)
-- Dependencies: 220
-- Data for Name: t_screen; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_screen (f_prog_id, f_screen_id, f_screen, f_screen_title, f_screen_type) FROM stdin;
\.


--
-- TOC entry 3353 (class 0 OID 16476)
-- Dependencies: 221
-- Data for Name: t_section; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_section (f_section_id, f_section, f_section_type, f_section_title) FROM stdin;
\.


--
-- TOC entry 3354 (class 0 OID 16482)
-- Dependencies: 222
-- Data for Name: t_section_api; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_section_api (f_section_id, f_component, f_api, f_entity_type, f_property) FROM stdin;
\.


--
-- TOC entry 3356 (class 0 OID 16490)
-- Dependencies: 224
-- Data for Name: t_section_field; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_section_field (f_section_id, f_component, f_component_sorter, f_db_table, f_db_field, f_label, f_element, f_input_type, f_value, f_width, f_size, f_step, f_required, f_readonly, f_placeholder, f_pattern, f_multiple, f_min, f_max, f_maxlength, f_height, f_list, f_disabled, f_checked, f_autofocus, f_autocomplete, f_alt, f_accept, f_form, f_formaction, f_formenctype, f_formmethod, f_formtarget, f_option, f_icon, f_class, f_cdsview, f_cds_entityset, f_cds_condition, f_row, f_cell) FROM stdin;
\.


--
-- TOC entry 3357 (class 0 OID 16496)
-- Dependencies: 225
-- Data for Name: t_user; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_user (f_id, f_uname, f_passwd, f_group, f_status, f_bp_role, f_supplier, f_fname, f_lname, f_full_name, f_gender, f_email, f_phone, f_mobile, f_language, f_company, f_cost_center, f_start_date, f_end_date) FROM stdin;
\.


--
-- TOC entry 3359 (class 0 OID 16504)
-- Dependencies: 227
-- Data for Name: t_user_role; Type: TABLE DATA; Schema: public; Owner: ordsys_admin
--

COPY public.t_user_role (f_user_id, f_role_id, f_from, f_to) FROM stdin;
\.


--
-- TOC entry 3391 (class 0 OID 0)
-- Dependencies: 205
-- Name: t_api_f_apiid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_api_f_apiid_seq', 1, false);


--
-- TOC entry 3392 (class 0 OID 0)
-- Dependencies: 211
-- Name: t_prog_f_progid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_prog_f_progid_seq', 1, false);


--
-- TOC entry 3393 (class 0 OID 0)
-- Dependencies: 215
-- Name: t_role_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_role_f_roleid_seq', 1, false);


--
-- TOC entry 3394 (class 0 OID 0)
-- Dependencies: 218
-- Name: t_roledp_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_roledp_f_roleid_seq', 1, false);


--
-- TOC entry 3395 (class 0 OID 0)
-- Dependencies: 219
-- Name: t_rolemenu_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_rolemenu_f_roleid_seq', 1, false);


--
-- TOC entry 3396 (class 0 OID 0)
-- Dependencies: 223
-- Name: t_section_f_sectionid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_section_f_sectionid_seq', 1, false);


--
-- TOC entry 3397 (class 0 OID 0)
-- Dependencies: 226
-- Name: t_user_f_usrid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_user_f_usrid_seq', 1, false);


--
-- TOC entry 3398 (class 0 OID 0)
-- Dependencies: 228
-- Name: t_userrole_f_roleid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_userrole_f_roleid_seq', 1, false);


--
-- TOC entry 3399 (class 0 OID 0)
-- Dependencies: 229
-- Name: t_userrole_f_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: ordsys_admin
--

SELECT pg_catalog.setval('public.t_userrole_f_userid_seq', 1, false);


--
-- TOC entry 3169 (class 2606 OID 16517)
-- Name: t_api t_api_f_api_f_api_type_f_version_key; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api
    ADD CONSTRAINT t_api_f_api_f_api_type_f_version_key UNIQUE (f_api, f_api_type, f_version);


--
-- TOC entry 3171 (class 2606 OID 16519)
-- Name: t_api t_api_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api
    ADD CONSTRAINT t_api_pkey PRIMARY KEY (f_id);


--
-- TOC entry 3173 (class 2606 OID 16521)
-- Name: t_api_call t_apicall_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api_call
    ADD CONSTRAINT t_apicall_pkey PRIMARY KEY (f_section_id, f_component, f_sequence);


--
-- TOC entry 3175 (class 2606 OID 16523)
-- Name: t_api_entity t_apientity_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api_entity
    ADD CONSTRAINT t_apientity_pkey PRIMARY KEY (f_api_id, f_entity);


--
-- TOC entry 3177 (class 2606 OID 16525)
-- Name: t_api_field t_apifld_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api_field
    ADD CONSTRAINT t_apifld_pkey PRIMARY KEY (f_apiid, f_entity, f_property);


--
-- TOC entry 3179 (class 2606 OID 16527)
-- Name: t_api_map t_apimap_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api_map
    ADD CONSTRAINT t_apimap_pkey PRIMARY KEY (f_property);


--
-- TOC entry 3181 (class 2606 OID 16529)
-- Name: t_api_navigation t_apinav_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_api_navigation
    ADD CONSTRAINT t_apinav_pkey PRIMARY KEY (f_call_api, f_call_entityset, f_navigation);


--
-- TOC entry 3183 (class 2606 OID 16531)
-- Name: t_prog t_prog_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_prog
    ADD CONSTRAINT t_prog_pkey PRIMARY KEY (f_id);


--
-- TOC entry 3185 (class 2606 OID 16533)
-- Name: t_prog_api t_progapi_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_prog_api
    ADD CONSTRAINT t_progapi_pkey PRIMARY KEY (f_prog_id, f_api_id);


--
-- TOC entry 3187 (class 2606 OID 16535)
-- Name: t_prog_section t_progsec_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_prog_section
    ADD CONSTRAINT t_progsec_pkey PRIMARY KEY (f_prog_id, f_screen_id, f_section_id);


--
-- TOC entry 3189 (class 2606 OID 16537)
-- Name: t_role t_role_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role
    ADD CONSTRAINT t_role_pkey PRIMARY KEY (f_id);


--
-- TOC entry 3191 (class 2606 OID 16539)
-- Name: t_role_dp t_roledp_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role_dp
    ADD CONSTRAINT t_roledp_pkey PRIMARY KEY (f_role_id, f_prog, f_section_id, f_component);


--
-- TOC entry 3193 (class 2606 OID 16541)
-- Name: t_role_menu t_rolemenu_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role_menu
    ADD CONSTRAINT t_rolemenu_pkey PRIMARY KEY (f_role_id, f_prog_id);


--
-- TOC entry 3195 (class 2606 OID 16543)
-- Name: t_role_value t_roleval_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_role_value
    ADD CONSTRAINT t_roleval_pkey PRIMARY KEY (f_role_id, f_section_id, f_component);


--
-- TOC entry 3197 (class 2606 OID 16545)
-- Name: t_screen t_screen_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_screen
    ADD CONSTRAINT t_screen_pkey PRIMARY KEY (f_prog_id, f_screen_id);


--
-- TOC entry 3201 (class 2606 OID 16547)
-- Name: t_section_api t_secapi_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_section_api
    ADD CONSTRAINT t_secapi_pkey PRIMARY KEY (f_section_id, f_component, f_api, f_entity_type);


--
-- TOC entry 3203 (class 2606 OID 16549)
-- Name: t_section_field t_secfld_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_section_field
    ADD CONSTRAINT t_secfld_pkey PRIMARY KEY (f_section_id, f_component);


--
-- TOC entry 3199 (class 2606 OID 16551)
-- Name: t_section t_section_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_section
    ADD CONSTRAINT t_section_pkey PRIMARY KEY (f_section_id);


--
-- TOC entry 3205 (class 2606 OID 16553)
-- Name: t_user t_user_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_user
    ADD CONSTRAINT t_user_pkey PRIMARY KEY (f_id);


--
-- TOC entry 3207 (class 2606 OID 16555)
-- Name: t_user_role t_userrole_pkey; Type: CONSTRAINT; Schema: public; Owner: ordsys_admin
--

ALTER TABLE ONLY public.t_user_role
    ADD CONSTRAINT t_userrole_pkey PRIMARY KEY (f_user_id, f_role_id);


-- Completed on 2019-11-30 19:21:12 CST

--
-- PostgreSQL database dump complete
--

